from banking import accounts

def deposit(amount):
    accounts.balance += amount

def withdraw(amount):
    accounts.balance -= amount