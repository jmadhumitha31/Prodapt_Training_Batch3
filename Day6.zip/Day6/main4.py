from banking import accounts, transactions

transactions.deposit(500)

print("Balance:", accounts.get_balance())

transactions.withdraw(200)

print("Balance:", accounts.get_balance())