from school import students, teachers, results

students.add_student("Ravi")
students.add_student("Anu")

students.view_students()

teachers.teacher_info()

print(results.grade(90))