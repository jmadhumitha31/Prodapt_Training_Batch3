from functools import reduce

print("===== Lambda Function Examples =====")

employees = [("madh", 85), ("Bvidua", 92), ("depi", 78)]

result1 = sorted(employees, key=lambda x: x[1], reverse=True)

print("\n1. Sort Tuples by Second Element")
print(result1)

# 2. Square numbers using map()
numbers = [2, 3, 4]

result2 = list(map(lambda x: x**2, numbers))

print("\n2. Square Numbers using map()")
print(result2)

# 3. Filter odd numbers using filter()
ids = [101, 102, 103, 104, 105]

result3 = list(filter(lambda x: x % 2 != 0, ids))

print("\n3. Filter Odd Numbers")
print(result3)

# 4. Product of numbers using reduce()
values = [2, 3, 5]

result4 = reduce(lambda x, y: x * y, values)

print("\n4. Product using reduce()")
print(result4)

# 5. Sort dictionary by values
students = {
    "madh": 78,
    "Bvidua": 90,
    "depi": 65
}

result5 = sorted(students.items(), key=lambda x: x[1], reverse=True)

print("\n5. Sort Dictionary by Marks")
print(result5)