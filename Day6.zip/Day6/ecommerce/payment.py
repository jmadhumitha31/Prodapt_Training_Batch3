def pay(amount):
    print("Payment Successful")
    print("Amount Paid:", amount)