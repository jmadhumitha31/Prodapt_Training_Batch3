cart = []

def add_item(item, price):
    cart.append(price)

def total():
    return sum(cart)