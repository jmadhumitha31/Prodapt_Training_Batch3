from ecommerce import cart, payment

cart.add_item("Burger",150)
cart.add_item("Pizza",300)

bill = cart.total()

print("Total Bill:", bill)

payment.pay(bill)