def teacher_info():
    print("Teacher: Priya")
    print("Subject: Python")