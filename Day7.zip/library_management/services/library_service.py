from utils.file_handler import read_books
from utils.file_handler import write_books
from utils.file_handler import read_members
from utils.file_handler import write_members

BOOK_FILE = "data/books.csv"
MEMBER_FILE = "data/members.csv"


def view_books():

    try:
        books = read_books(BOOK_FILE)

        print("\nAvailable Books\n")

        for book in books:
            print("Book ID :", book["book_id"])
            print("Title :", book["title"])
            print("Author :", book["author"])
            print("Category :", book["category"])
            print("Status :", book["status"])
            print()

    except FileNotFoundError:
        print("Error: Data file not found")


def add_book():

    books = read_books(BOOK_FILE)

    book = {
        "book_id": input("Enter Book ID: "),
        "title": input("Enter Title: "),
        "author": input("Enter Author: "),
        "category": input("Enter Category: "),
        "status": "Available"
    }

    books.append(book)
    write_books(BOOK_FILE, books)

    print("Book added successfully.")


def register_member():

    members = read_members(MEMBER_FILE)

    member = {
        "member_id": input("Enter Member ID: "),
        "name": input("Enter Member Name: "),
        "email": input("Enter Email: "),
        "borrowed_books": ""
    }

    members.append(member)
    write_members(MEMBER_FILE, members)

    print("Member registered successfully.")


def borrow_book():

    books = read_books(BOOK_FILE)
    members = read_members(MEMBER_FILE)

    member_id = input("Enter Member ID: ")
    book_id = input("Enter Book ID: ")

    member_found = False
    book_found = False

    for member in members:

        if member["member_id"] == member_id:

            member_found = True

            for book in books:

                if book["book_id"] == book_id:

                    book_found = True

                    if book["status"] == "Available":

                        book["status"] = "Borrowed"

                        if member["borrowed_books"] == "":
                            member["borrowed_books"] = book_id
                        else:
                            member["borrowed_books"] += ";" + book_id

                        write_books(BOOK_FILE, books)
                        write_members(MEMBER_FILE, members)

                        print("Book borrowed successfully.")
                        return

                    else:
                        print("Error: Book is already borrowed.")
                        return

    if not member_found:
        print("Error: Member not found.")

    elif not book_found:
        print("Error: Book not found.")


def return_book():

    books = read_books(BOOK_FILE)
    members = read_members(MEMBER_FILE)

    member_id = input("Enter Member ID: ")
    book_id = input("Enter Book ID: ")

    for member in members:

        if member["member_id"] == member_id:

            borrowed = member["borrowed_books"].split(";") if member["borrowed_books"] else []

            if book_id in borrowed:

                borrowed.remove(book_id)
                member["borrowed_books"] = ";".join(borrowed)

                for book in books:
                    if book["book_id"] == book_id:
                        book["status"] = "Available"

                write_books(BOOK_FILE, books)
                write_members(MEMBER_FILE, members)

                print("Book returned successfully.")
                return

            else:
                print("Error: Book not borrowed by this member.")
                return

    print("Error: Member not found.")