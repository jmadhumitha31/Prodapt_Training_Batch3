import csv
import os


def read_books(file_name):

    books = []

    if not os.path.exists(file_name):
        raise FileNotFoundError("Books file not found")

    with open(file_name, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            books.append(row)

    return books


def write_books(file_name, books):

    with open(file_name, "w", newline="") as file:

        fields = ["book_id", "title", "author", "category", "status"]

        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()

        for book in books:
            writer.writerow(book)


def read_members(file_name):

    members = []

    if not os.path.exists(file_name):
        raise FileNotFoundError("Members file not found")

    with open(file_name, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            members.append(row)

    return members


def write_members(file_name, members):

    with open(file_name, "w", newline="") as file:

        fields = ["member_id", "name", "email", "borrowed_books"]

        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()

        for member in members:
            writer.writerow(member)