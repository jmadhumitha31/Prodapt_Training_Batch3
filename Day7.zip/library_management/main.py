from services import library_service

while True:

    print("\n=====Library Management System=====")
    print("1. View Books")
    print("2. Add Book")
    print("3. Register Member")
    print("4. Borrow Book")
    print("5. Return Book")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        library_service.view_books()

    elif choice == "2":
        library_service.add_book()

    elif choice == "3":
        library_service.register_member()

    elif choice == "4":
        library_service.borrow_book()

    elif choice == "5":
        library_service.return_book()

    elif choice == "6":
        print("Thank you for using the Library Management System.")
        break

    else:
        print("Invalid Choice")