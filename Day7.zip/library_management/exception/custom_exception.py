class BookNotFoundException(Exception):

    def __init__(self, message="Book not found"):
        super().__init__(message)


class BookAlreadyBorrowedException(Exception):

    def __init__(self, message="Book is already borrowed"):
        super().__init__(message)


class MemberNotFoundException(Exception):

    def __init__(self, message="Member not found"):
        super().__init__(message)


class FileDataNotFoundException(Exception):

    def __init__(self, message="Data file not found"):
        super().__init__(message)