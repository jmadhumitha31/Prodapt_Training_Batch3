# Library Management System

## Project Overview

The Library Management System is developed using Python and Object-Oriented Programming concepts.

The system allows users to:
- View books
- Add books
- Register members
- Borrow books
- Return books
- Store records using CSV files

## Project Structure

```
library_management_system/
│
├── main.py
│
├── models/
│   ├── book.py
│   └── member.py
│
├── services/
│   └── library_service.py
│
├── utils/
│   └── file_handler.py
│
├── exceptions/
│   └── custom_exceptions.py
│
├── data/
│   ├── books.csv
│   └── members.csv
│
├── tests/
│   └── test_library.py
│
└── README.md
```

## Features

- View Books
- Add Book
- Register Member
- Borrow Book
- Return Book
- File Handling
- Exception Handling

## Technologies Used

- Python
- Object-Oriented Programming
- CSV File Handling

## How to Run

```
python main.py
```

## How to Run Tests

```
python tests/test_library.py
```