class Member:

    def __init__(self, member_id, name, email, borrowed_books=""):
        self.member_id = member_id
        self.name = name
        self.email = email

        if borrowed_books == "":
            self.borrowed_books = []
        else:
            self.borrowed_books = borrowed_books.split(";")

    def borrow_book(self, book_id):
        if book_id not in self.borrowed_books:
            self.borrowed_books.append(book_id)

    def return_book(self, book_id):
        if book_id in self.borrowed_books:
            self.borrowed_books.remove(book_id)

    def display(self):
        print("Member ID :", self.member_id)
        print("Name :", self.name)
        print("Email :", self.email)
        print("Borrowed Books :", self.borrowed_books)