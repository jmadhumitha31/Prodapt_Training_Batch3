class Book:

    def __init__(self, book_id, title, author, category, status):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.category = category
        self.status = status

    def display(self):
        print("Book ID :", self.book_id)
        print("Title :", self.title)
        print("Author :", self.author)
        print("Category :", self.category)
        print("Status :", self.status)