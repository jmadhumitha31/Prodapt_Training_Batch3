# Online Shopping Cart System
## Project Overview

The Online Shopping Cart System is developed using Python and Object-Oriented Programming concepts.

The system allows users to:
- View products
- Add products to cart
- Remove products from cart
- View cart
- Checkout
- Save order history to a file

## Project Structure

```
online_shopping_cart/
│
├── main.py
├── README.md
│
├── models/
│   ├── __init__.py
│   ├── product.py
│   ├── cart.py
│   ├── user.py
│   └── premium_user.py
│
├── services/
│   ├── __init__.py
│   ├── cart_service.py
│   └── store_service.py
│
├── exceptions/
│   ├── __init__.py
│   └── cart_exceptions.py
│
├── utils/
│   ├── __init__.py
│   └── file_handler.py
│
├── data/
│   └── order_history.txt
│
└── tests/
    ├── __init__.py
    └── test_cart.py
```

## Features

- Product Management
- Shopping Cart
- User and Premium User
- Checkout
- Order History
- Exception Handling
- Unit Testing

## Technologies Used

- Python
- Object-Oriented Programming
- File Handling
- Unit Testing

## How to Run

```
python main.py
```
## How to Run Tests

```
python tests/test_cart.py
```