def save_order(cart):

    file = open("data/order_history.txt", "a")

    file.write("Order:\n")

    for item in cart.items:
        product = item["product"]
        quantity = item["quantity"]
        file.write(product.name + " x" + str(quantity) + "\n")

    file.write("\n")
    file.close()