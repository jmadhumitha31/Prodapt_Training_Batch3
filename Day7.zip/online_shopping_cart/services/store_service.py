from models.product import Product

class StoreService:

    def __init__(self):
        self.products = []

    def add_product(self, name, price, quantity):
        product = Product(name, price, quantity)
        self.products.append(product)
        print("Product added successfully.")

    def view_products(self):
        if len(self.products) == 0:
            print("No products available.")
            return

        for product in self.products:
            product.display()
            print()

    def get_product(self, name):
        for product in self.products:
            if product.name.lower() == name.lower():
                return product
        return None