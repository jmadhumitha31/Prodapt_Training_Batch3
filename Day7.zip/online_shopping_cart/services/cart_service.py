from utils.file_handler import save_order

class CartService:

    def checkout(self, user):

        if len(user.cart.items) == 0:
            print("Cart is empty.")
            return

        user.cart.view_cart()
        save_order(user.cart)
        print("Order placed successfully.")