from models.user import User
from models.premium_user import PremiumUser
from services.store_service import StoreService
from services.cart_service import CartService

store = StoreService()
cart_service = CartService()

store.add_product("Laptop", 1000, 5)
store.add_product("Mouse", 500, 10)
store.add_product("Keyboard", 800, 8)

name = input("Enter User Name: ")
user_type = input("Premium User (yes/no): ")

if user_type.lower() == "yes":
    discount = float(input("Enter Discount: "))
    user = PremiumUser(name, discount)
else:
    user = User(name)

while True:
    print("\n1. View Products")
    print("2. Add Product to Cart")
    print("3. Remove Product from Cart")
    print("4. View Cart")
    print("5. Checkout")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        store.view_products()

    elif choice == "2":
        product_name = input("Enter Product Name: ")
        quantity = int(input("Enter Quantity: "))
        product = store.get_product(product_name)

        if product:
            user.cart.add_product(product, quantity)
        else:
            print("Product not found.")

    elif choice == "3":
        product_name = input("Enter Product Name: ")
        user.cart.remove_product(product_name)

    elif choice == "4":
        user.cart.view_cart()

    elif choice == "5":
        cart_service.checkout(user)

    elif choice == "6":
        print("Thank You")
        break

    else:
        print("Invalid Choice")