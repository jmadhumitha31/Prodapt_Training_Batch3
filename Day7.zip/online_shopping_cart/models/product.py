class Product:

    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity

    def display(self):
        print("Product Name :", self.name)
        print("Price :", self.price)
        print("Quantity :", self.quantity)