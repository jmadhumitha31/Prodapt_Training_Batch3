class Cart:

    def __init__(self):

        self.items = []

    def add_product(self, product, quantity):

        if quantity <= product.quantity:

            self.items.append({
                "product": product,
                "quantity": quantity
            })
            product.quantity = product.quantity - quantity
            print("Product added to cart.")

        else:
            print("Product is out of stock.")

    def remove_product(self, product_name):
        for item in self.items:
            if item["product"].name == product_name:
                item["product"].quantity = (
                    item["product"].quantity + item["quantity"]
                )
                self.items.remove(item)

                print("Product removed from cart.")
                return

        print("Product not found in cart.")

    def view_cart(self):

        if len(self.items) == 0:

            print("Cart is empty.")
            return

        total = 0

        print("\n-----Shopping Cart-----")
        for item in self.items:

            product = item["product"]
            quantity = item["quantity"]
            amount = product.price * quantity
            total = total + amount

            print(product.name)
            print("Price :", product.price)
            print("Quantity :", quantity)
            print("Amount :", amount)
            print("----------------------")
        print("Total Bill :", total)