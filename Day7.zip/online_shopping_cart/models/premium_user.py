from models.user import User

class PremiumUser(User):

    def __init__(self, name, discount):
        super().__init__(name)
        self.discount = discount

    def display(self):
        print("User Name:", self.name)
        print("Discount:", self.discount, "%")