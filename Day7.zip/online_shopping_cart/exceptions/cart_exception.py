class OutOfStockError(Exception):

    def __init__(self, message="Product is out of stock"):
        super().__init__(message)


class ProductNotFoundError(Exception):

    def __init__(self, message="Product not found"):
        super().__init__(message)