import unittest
from models.product import Product
from models.cart import Cart

class TestCart(unittest.TestCase):

    def test_add_product(self):
        cart = Cart()
        laptop = Product("Laptop", 1000, 5)
        cart.add_product(laptop, 1)
        self.assertEqual(len(cart.items), 1)

    def test_remove_product(self):
        cart = Cart()
        mouse = Product("Mouse", 500, 5)
        cart.add_product(mouse, 1)
        cart.remove_product("Mouse")
        self.assertEqual(len(cart.items), 0)

if __name__ == "__main__":
    unittest.main()