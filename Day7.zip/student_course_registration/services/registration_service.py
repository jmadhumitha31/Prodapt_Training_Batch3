from utils.file_handler import read_courses
from utils.file_handler import read_students
from utils.file_handler import write_courses
from utils.file_handler import write_students

COURSE_FILE = "data/courses.csv"
STUDENT_FILE = "data/students.csv"

def view_courses():
    try:
        courses = read_courses(COURSE_FILE)
        print("\n=========Available Courses========")

        for course in courses:

            print("Course ID :", course["course_id"])
            print("Course Name :", course["course_name"])
            print("Instructor :", course["instructor"])
            print("Seats Available :", course["seats_available"])
            print("============================================")
    except FileNotFoundError:
        print("Error: Course data file not found")


def add_course():
    courses = read_courses(COURSE_FILE)

    course_id = input("Enter Course ID: ")
    course_name = input("Enter Course Name: ")
    instructor = input("Enter Instructor Name: ")
    seats = input("Enter Available Seats: ")
    course = {
        "course_id": course_id,
        "course_name": course_name,
        "instructor": instructor,
        "seats_available": seats
    }

    courses.append(course)
    write_courses(COURSE_FILE, courses)
    print("Course added successfully.")

def register_student():
    students = read_students(STUDENT_FILE)
    student_id = input("Enter Student ID: ")
    name = input("Enter Student Name: ")
    email = input("Enter Email: ")
    student = {
        "student_id": student_id,
        "name": name,
        "email": email,
        "enrolled_courses": ""
    }
    students.append(student)
    write_students(STUDENT_FILE, students)
    print("Student registered successfully.")

def enroll_course():
    students = read_students(STUDENT_FILE)
    courses = read_courses(COURSE_FILE)

    student_id = input("Enter Student ID: ")
    course_id = input("Enter Course ID: ")

    student_found = False
    course_found = False

    for student in students:
        if student["student_id"] == student_id:
            student_found = True
            for course in courses:
                if course["course_id"] == course_id:
                    course_found = True
                    if int(course["seats_available"]) > 0:
                        if student["enrolled_courses"] == "":
                            student["enrolled_courses"] = course_id
                        else:
                            student["enrolled_courses"] = (
                                student["enrolled_courses"] + ";" + course_id
                            )

                        course["seats_available"] = str(
                            int(course["seats_available"]) - 1
                        )

                        write_students(STUDENT_FILE, students)
                        write_courses(COURSE_FILE, courses)
                        print("Course enrollment successful")
                    else:
                        print("Error: No seats available for this course")

    if not student_found:
        print("Error: Student not found")

    if not course_found:
        print("Error: Course not found")

def drop_course():
    students = read_students(STUDENT_FILE)
    courses = read_courses(COURSE_FILE)

    student_id = input("Enter Student ID: ")
    course_id = input("Enter Course ID: ")

    for student in students:

        if student["student_id"] == student_id:

            course_list = student["enrolled_courses"].split(";")
            if course_id in course_list:

                course_list.remove(course_id)
                student["enrolled_courses"] = ";".join(course_list)

                for course in courses:
                    if course["course_id"] == course_id:
                        course["seats_available"] = str(
                            int(course["seats_available"]) + 1
                        )

                write_students(STUDENT_FILE, students)
                write_courses(COURSE_FILE, courses)

                print("Course dropped successfully")
                return

    print("Student or Course not found")