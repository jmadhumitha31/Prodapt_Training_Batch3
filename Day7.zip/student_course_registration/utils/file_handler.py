import csv
import os

def read_courses(file_name):
    
    course_list = []
    if not os.path.exists(file_name):
        raise FileNotFoundError("Course data file not found")
    file = open(file_name, "r")
    reader = csv.DictReader(file)
    for row in reader:
        course_list.append(row)
    file.close()
    return course_list

def read_students(file_name):
    student_list = []
    if not os.path.exists(file_name):
        raise FileNotFoundError("Student data file not found")
    file = open(file_name, "r")
    reader = csv.DictReader(file)
    for row in reader:
        student_list.append(row)

    file.close()
    return student_list

def write_courses(file_name, course_list):
    file = open(file_name, "w", newline="")
    field_names = [
        "course_id",
        "course_name",
        "instructor",
        "seats_available"
    ]

    writer = csv.DictWriter(file, fieldnames=field_names)
    writer.writeheader()
    for course in course_list:
        writer.writerow(course)
    
    file.close()

def write_students(file_name, student_list):
    file = open(file_name, "w", newline="")
    field_names = [
        "student_id",
        "name",
        "email",
        "enrolled_courses"
    ]
    
    writer = csv.DictWriter(file, fieldnames=field_names)
    writer.writeheader()
    for student in student_list:
        writer.writerow(student)
    file.close()