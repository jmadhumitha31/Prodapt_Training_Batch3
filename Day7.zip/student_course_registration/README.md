# Student Course Registration System
# Project Objective

The Student Course Registration System is a Python-based application that manages students and courses.

The system allows users to:
- View available courses
- Add new courses
- Register students
- Enroll students in courses
- Drop enrolled courses
- Store and retrieve data using CSV files

---
## Project Structure
course_registration_system/
│
├── main.py
│
├── models
│   ├── course.py
│   └── student.py
│
├── services
│   └── registration_service.py
│
├── utils
│   └── file_handler.py
│
├── exceptions
│   └── custom_exceptions.py
│
├── data
│   ├── courses.csv
│   └── students.csv
│
├── tests
│   └── test_registration.py
│
└── README.md
```

---

# Features

- View Courses
- Add Course
- Register Student
- Enroll Course
- Drop Course
- Store course details in CSV files
- Store student details in CSV files
- Exception Handling

---

# Technologies Used

- Python
- CSV File Handling
- Object Oriented Programming (OOP)
- Exception Handling

# How to Run

1. Open the project in VS Code.
2. Run the following command:

python main.py
3. Select the required menu option.