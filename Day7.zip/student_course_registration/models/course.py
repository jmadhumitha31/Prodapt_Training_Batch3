class Course:

    def __init__(self, course_id, course_name, instructor, seats_available):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.seats_available = int(seats_available)

    def display(self):
        print("Course ID :", self.course_id)
        print("Course Name :", self.course_name)
        print("Instructor :", self.instructor)
        print("Seats Available :", self.seats_available)
