class Student:

    def __init__(self, student_id, name, email, enrolled_courses=""):
        self.student_id = student_id
        self.name = name
        self.email = email

        if enrolled_courses == "":
            self.enrolled_courses = []
        else:
            self.enrolled_courses = enrolled_courses.split(";")

    def enroll_course(self, course_id):
        if course_id not in self.enrolled_courses:
            self.enrolled_courses.append(course_id)

    def drop_course(self, course_id):
        if course_id in self.enrolled_courses:
            self.enrolled_courses.remove(course_id)

    def display(self):
        print("Student ID :", self.student_id)
        print("Name :", self.name)
        print("Email :", self.email)
        print("Enrolled Courses :", self.enrolled_courses)
