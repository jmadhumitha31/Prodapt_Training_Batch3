from services import registration_service

while True:

    print("\n=====Student Course Registration System=====")
    print("1. View Courses")
    print("2. Add Course")
    print("3. Register Student")
    print("4. Enroll Course")
    print("5. Drop Course")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        registration_service.view_courses()
    elif choice == "2":
        registration_service.add_course()
    elif choice == "3":
        registration_service.register_student()
    elif choice == "4":
        registration_service.enroll_course()
    elif choice == "5":
        registration_service.drop_course()
    elif choice == "6":
        print("\nThank you for using Student Course Registration System.")
        break
    else:
        print("Invalid Choice. Please try again.")