class CourseNotFoundException(Exception):
    def __init__(self, message="Course not found"):
        super().__init__(message)

class StudentNotFoundException(Exception):
    def __init__(self, message="Student not found"):
        super().__init__(message)

class CourseFullException(Exception):
    def __init__(self, message="No seats available for this course"):
        super().__init__(message)

class FileDataNotFoundException(Exception):
    def __init__(self, message="Course data file not found"):
        super().__init__(message)