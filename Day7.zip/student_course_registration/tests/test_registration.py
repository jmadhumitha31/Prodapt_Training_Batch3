# test_registration.py

from services import registration_service


def test_view_courses():
    print("\n----- Test: View Courses -----")
    registration_service.view_courses()


def test_add_course():
    print("\n----- Test: Add Course -----")
    registration_service.add_course()


def test_register_student():
    print("\n----- Test: Register Student -----")
    registration_service.register_student()


def test_enroll_course():
    print("\n----- Test: Enroll Course -----")
    registration_service.enroll_course()


def test_drop_course():
    print("\n----- Test: Drop Course -----")
    registration_service.drop_course()


if __name__ == "__main__":

    while True:

        print("\n===== Test Registration =====")
        print("1. Test View Courses")
        print("2. Test Add Course")
        print("3. Test Register Student")
        print("4. Test Enroll Course")
        print("5. Test Drop Course")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            test_view_courses()
        elif choice == "2":
            test_add_course()
        elif choice == "3":
            test_register_student()
        elif choice == "4":
            test_enroll_course()
        elif choice == "5":
            test_drop_course()
        elif choice == "6":
            print("Exiting Test...")
            break
        else:
            print("Invalid Choice")