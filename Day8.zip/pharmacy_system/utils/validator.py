from asssignments.D8.pharmacy_system.data.datastore import customers
from asssignments.D8.pharmacy_system.data.datastore import medicines


def validate_customer(customer_id):

    if customer_id in customers:
        return True

    return False


def validate_medicine(medicine_id):

    if medicine_id in medicines:
        return True

    return False


def check_stock(medicine_id, quantity):

    if medicine_id not in medicines:
        return False

    if medicines[medicine_id].quantity >= quantity:
        return True

    return False


def validate_age(age):

    if age > 0:
        return True

    return False