from asssignments.D8.pharmacy_system.models.sale import Sale
from asssignments.D8.pharmacy_system.data.datastore import sales
from asssignments.D8.pharmacy_system.data.datastore import customers
from asssignments.D8.pharmacy_system.data.datastore import medicines


class SaleService:

    def create_sale(self, sale_id, customer_id, medicine_id, date, quantity):

        if customer_id not in customers:
            print("Customer not found.")
            return

        if medicine_id not in medicines:
            print("Medicine not found.")
            return

        medicine = medicines[medicine_id]

        if medicine.quantity < quantity:
            print("Insufficient stock.")
            return

        customer = customers[customer_id]

        medicine.quantity -= quantity

        total_amount = medicine.price * quantity

        sale = Sale(sale_id, customer, medicine, date, total_amount)

        sales[sale_id] = sale

        print("Sale created successfully.")

    def get_sale(self, sale_id):

        if sale_id in sales:
            return sales[sale_id]

        print("Sale not found.")
        return None

    def delete_sale(self, sale_id):

        if sale_id in sales:
            del sales[sale_id]
            print("Sale deleted successfully.")
        else:
            print("Sale not found.")

    def view_sales(self):

        if len(sales) == 0:
            print("No sales available.")
        else:
            for sale in sales.values():
                sale.display()
                print()