from asssignments.D8.pharmacy_system.models.customer import Customer
from asssignments.D8.pharmacy_system.data.datastore import customers


class CustomerService:

    def add_customer(self, customer_id, name, age, prescription):

        customer = Customer(customer_id, name, age, prescription)
        customers[customer_id] = customer

        print("Customer added successfully.")

    def get_customer(self, customer_id):

        if customer_id in customers:
            return customers[customer_id]

        print("Customer not found.")
        return None

    def update_prescription(self, customer_id, prescription):

        if customer_id in customers:
            customers[customer_id].prescription = prescription
            print("Prescription updated successfully.")
        else:
            print("Customer not found.")

    def delete_customer(self, customer_id):

        if customer_id in customers:
            del customers[customer_id]
            print("Customer deleted successfully.")
        else:
            print("Customer not found.")

    def view_customers(self):

        if len(customers) == 0:
            print("No customers found.")
        else:
            for customer in customers.values():
                customer.display()
                print()