from asssignments.D8.pharmacy_system.models.medicine import Medicine
from asssignments.D8.pharmacy_system.data.datastore import medicines


class MedicineService:

    def add_medicine(self, medicine_id, name, medicine_type, price, quantity):

        medicine = Medicine(medicine_id, name, medicine_type, price, quantity)
        medicines[medicine_id] = medicine

        print("Medicine added successfully.")

    def get_medicine(self, medicine_id):

        if medicine_id in medicines:
            return medicines[medicine_id]

        print("Medicine not found.")
        return None

    def update_medicine(self, medicine_id, price, quantity):

        if medicine_id in medicines:
            medicines[medicine_id].price = price
            medicines[medicine_id].quantity = quantity
            print("Medicine updated successfully.")
        else:
            print("Medicine not found.")

    def delete_medicine(self, medicine_id):

        if medicine_id in medicines:
            del medicines[medicine_id]
            print("Medicine deleted successfully.")
        else:
            print("Medicine not found.")

    def view_medicines(self):

        if len(medicines) == 0:
            print("No medicines available.")
        else:
            for medicine in medicines.values():
                medicine.display()
                print()