from asssignments.D8.pharmacy_system.services.customer_service import CustomerService
from asssignments.D8.pharmacy_system.services.medicine_service import MedicineService
from asssignments.D8.pharmacy_system.services.sale_service import SaleService


class PharmacySystem:

    def __init__(self):
        self.customer_service = CustomerService()
        self.medicine_service = MedicineService()
        self.sale_service = SaleService()

    def add_customer(self, customer_id, name, age, prescription):
        self.customer_service.add_customer(
            customer_id, name, age, prescription
        )

    def view_customers(self):
        self.customer_service.view_customers()

    def update_prescription(self, customer_id, prescription):
        self.customer_service.update_prescription(
            customer_id, prescription
        )

    def delete_customer(self, customer_id):
        self.customer_service.delete_customer(customer_id)

    def add_medicine(self, medicine_id, name, medicine_type, price, quantity):
        self.medicine_service.add_medicine(
            medicine_id,
            name,
            medicine_type,
            price,
            quantity
        )

    def view_medicines(self):
        self.medicine_service.view_medicines()

    def update_medicine(self, medicine_id, price, quantity):
        self.medicine_service.update_medicine(
            medicine_id,
            price,
            quantity
        )

    def delete_medicine(self, medicine_id):
        self.medicine_service.delete_medicine(medicine_id)

    def create_sale(self, sale_id, customer_id, medicine_id, date, quantity):
        self.sale_service.create_sale(
            sale_id,
            customer_id,
            medicine_id,
            date,
            quantity
        )

    def view_sales(self):
        self.sale_service.view_sales()

    def delete_sale(self, sale_id):
        self.sale_service.delete_sale(sale_id)