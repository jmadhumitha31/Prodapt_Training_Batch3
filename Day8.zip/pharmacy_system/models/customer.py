from asssignments.D8.pharmacy_system.models.person import Person


class Customer(Person):

    def __init__(self, customer_id, name, age, prescription):
        super().__init__(customer_id, name, age)
        self.prescription = prescription

    def display(self):
        super().display()
        print("Prescription :", self.prescription)