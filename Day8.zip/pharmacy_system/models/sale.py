class Sale:

    def __init__(self, sale_id, customer, medicine, date, total_amount):
        self.sale_id = sale_id
        self.customer = customer
        self.medicine = medicine
        self.date = date
        self.total_amount = total_amount

    def display(self):
        print("Sale ID :", self.sale_id)
        print("Customer :", self.customer.name)
        print("Medicine :", self.medicine.name)
        print("Date :", self.date)
        print("Total Amount :", self.total_amount)