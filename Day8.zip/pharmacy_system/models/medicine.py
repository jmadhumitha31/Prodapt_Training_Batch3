class Medicine:

    def __init__(self, medicine_id, name, medicine_type, price, quantity):
        self.medicine_id = medicine_id
        self.name = name
        self.medicine_type = medicine_type
        self.price = price
        self.quantity = quantity

    def display(self):
        print("Medicine ID :", self.medicine_id)
        print("Name :", self.name)
        print("Type :", self.medicine_type)
        print("Price :", self.price)
        print("Quantity :", self.quantity)