customers = {}
medicines = {}
sales = {}