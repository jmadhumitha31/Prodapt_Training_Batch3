import unittest
from asssignments.D8.pharmacy_system.services.medicine_service import MedicineService


class TestMedicine(unittest.TestCase):

    def test_medicine(self):

        service = MedicineService()

        service.add_medicine("M101", "Dolo", "Tablet", 20, 100)

        medicine = service.get_medicine("M101")

        self.assertEqual(medicine.name, "Dolo")
        self.assertEqual(medicine.quantity, 100)


if __name__ == "__main__":
    unittest.main()