import unittest
from asssignments.D8.pharmacy_system.services.customer_service import CustomerService


class TestCustomer(unittest.TestCase):

    def test_customer(self):

        service = CustomerService()

        service.add_customer("C101", "Rahul", 25, "Paracetamol")

        customer = service.get_customer("C101")

        self.assertEqual(customer.name, "Rahul")
        self.assertEqual(customer.prescription, "Paracetamol")


if __name__ == "__main__":
    unittest.main()