import unittest
from asssignments.D8.pharmacy_system.services.customer_service import CustomerService
from asssignments.D8.pharmacy_system.services.medicine_service import MedicineService
from asssignments.D8.pharmacy_system.services.sale_service import SaleService


class TestSale(unittest.TestCase):

    def test_sale(self):

        customer_service = CustomerService()
        medicine_service = MedicineService()
        sale_service = SaleService()

        customer_service.add_customer("C201", "Kiran", 30, "Antibiotic")
        medicine_service.add_medicine("M201", "Azithromycin", "Tablet", 50, 20)

        sale_service.create_sale("S101", "C201", "M201", "17-07-2026", 2)

        sale = sale_service.get_sale("S101")

        self.assertEqual(sale.total_amount, 100)


if __name__ == "__main__":
    unittest.main()