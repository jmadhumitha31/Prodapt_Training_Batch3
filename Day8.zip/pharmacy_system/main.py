from asssignments.D8.pharmacy_system.services.pharmacy_system import PharmacySystem

system = PharmacySystem()
system.add_customer("C101", "Rahul", 25, "Paracetamol")
system.add_medicine("M101", "Dolo", "Tablet", 20, 100)
system.create_sale("S101", "C101", "M101", "17-07-2026", 2)

print("\nCustomers")
system.view_customers()
print("\nMedicines")
system.view_medicines()
print("\nSales")
system.view_sales()