from services.library_system import LibrarySystem


system = LibrarySystem()

system.add_member("M101", "Rahul", 22, "Regular")

system.add_book(
    "B101",
    "Python Programming",
    "Guido van Rossum",
    "Programming",
    True
)

system.create_borrow(
    "BR101",
    "M101",
    "B101",
    "17-07-2026",
    "24-07-2026"
)

print("\nMembers")
system.view_members()

print("\nBooks")
system.view_books()

print("\nBorrow Records")
system.view_borrows()