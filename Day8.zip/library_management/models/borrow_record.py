class BorrowRecord:

    def __init__(self, borrow_id, member, book, borrow_date, return_date):
        self.borrow_id = borrow_id
        self.member = member
        self.book = book
        self.borrow_date = borrow_date
        self.return_date = return_date

    def display(self):
        print("Borrow ID :", self.borrow_id)
        print("Member :", self.member.name)
        print("Book :", self.book.title)
        print("Borrow Date :", self.borrow_date)
        print("Return Date :", self.return_date)