class Book:

    def __init__(self, book_id, title, author, genre, is_available):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.is_available = is_available

    def display(self):
        print("Book ID :", self.book_id)
        print("Title :", self.title)
        print("Author :", self.author)
        print("Genre :", self.genre)
        print("Available :", self.is_available)