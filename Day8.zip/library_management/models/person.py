class Person:

    def __init__(self, person_id, name, age):
        self.person_id = person_id
        self.name = name
        self.age = age

    def display(self):
        print("ID :", self.person_id)
        print("Name :", self.name)
        print("Age :", self.age)