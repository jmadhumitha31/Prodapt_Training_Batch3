from models.person import Person


class Member(Person):

    def __init__(self, member_id, name, age, membership_type):
        super().__init__(member_id, name, age)
        self.membership_type = membership_type

    def display(self):
        super().display()
        print("Membership Type :", self.membership_type)