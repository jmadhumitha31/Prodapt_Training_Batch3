from data.datastore import members
from data.datastore import books

def validate_member(member_id):

    if member_id in members:
        return True
    return False

def validate_book(book_id):

    if book_id in books:
        return True

    return False


def check_book_availability(book_id):

    if book_id not in books:
        return False

    return books[book_id].is_available


def validate_membership(membership_type):

    if membership_type.lower() in ["regular", "premium"]:
        return True

    return False