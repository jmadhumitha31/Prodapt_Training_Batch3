from models.borrow_record import BorrowRecord
from data.datastore import borrows
from data.datastore import members
from data.datastore import books


class BorrowService:

    def create_borrow(self, borrow_id, member_id, book_id, borrow_date, return_date):

        if member_id not in members:
            print("Member not found.")
            return

        if book_id not in books:
            print("Book not found.")
            return

        member = members[member_id]
        book = books[book_id]

        if not book.is_available:
            print("Book is not available.")
            return

        book.is_available = False

        borrow = BorrowRecord(
            borrow_id,
            member,
            book,
            borrow_date,
            return_date
        )

        borrows[borrow_id] = borrow

        print("Borrow record created successfully.")

    def get_borrow(self, borrow_id):

        if borrow_id in borrows:
            return borrows[borrow_id]

        print("Borrow record not found.")
        return None

    def mark_return(self, borrow_id):

        if borrow_id in borrows:
            borrow = borrows[borrow_id]
            borrow.book.is_available = True
            print("Book returned successfully.")
        else:
            print("Borrow record not found.")

    def delete_borrow(self, borrow_id):

        if borrow_id in borrows:
            del borrows[borrow_id]
            print("Borrow record deleted successfully.")
        else:
            print("Borrow record not found.")

    def view_borrows(self):

        if len(borrows) == 0:
            print("No borrow records found.")
        else:
            for borrow in borrows.values():
                borrow.display()
                print()