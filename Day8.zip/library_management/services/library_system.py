from services.member_service import MemberService
from services.book_service import BookService
from services.borrow_service import BorrowService


class LibrarySystem:

    def __init__(self):
        self.member_service = MemberService()
        self.book_service = BookService()
        self.borrow_service = BorrowService()

    def add_member(self, member_id, name, age, membership_type):
        self.member_service.add_member(
            member_id,
            name,
            age,
            membership_type
        )

    def view_members(self):
        self.member_service.view_members()

    def update_membership(self, member_id, membership_type):
        self.member_service.update_membership(
            member_id,
            membership_type
        )

    def delete_member(self, member_id):
        self.member_service.delete_member(member_id)

    def add_book(self, book_id, title, author, genre, is_available):
        self.book_service.add_book(
            book_id,
            title,
            author,
            genre,
            is_available
        )

    def view_books(self):
        self.book_service.view_books()

    def update_availability(self, book_id, is_available):
        self.book_service.update_availability(
            book_id,
            is_available
        )

    def delete_book(self, book_id):
        self.book_service.delete_book(book_id)

    def create_borrow(self, borrow_id, member_id, book_id, borrow_date, return_date):
        self.borrow_service.create_borrow(
            borrow_id,
            member_id,
            book_id,
            borrow_date,
            return_date
        )

    def mark_return(self, borrow_id):
        self.borrow_service.mark_return(borrow_id)

    def view_borrows(self):
        self.borrow_service.view_borrows()

    def delete_borrow(self, borrow_id):
        self.borrow_service.delete_borrow(borrow_id)