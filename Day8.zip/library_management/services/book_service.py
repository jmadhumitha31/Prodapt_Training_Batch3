from models.book import Book
from data.datastore import books


class BookService:

    def add_book(self, book_id, title, author, genre, is_available):

        book = Book(book_id, title, author, genre, is_available)
        books[book_id] = book

        print("Book added successfully.")

    def get_book(self, book_id):

        if book_id in books:
            return books[book_id]

        print("Book not found.")
        return None

    def update_availability(self, book_id, is_available):

        if book_id in books:
            books[book_id].is_available = is_available
            print("Book availability updated successfully.")
        else:
            print("Book not found.")

    def delete_book(self, book_id):

        if book_id in books:
            del books[book_id]
            print("Book deleted successfully.")
        else:
            print("Book not found.")

    def view_books(self):

        if len(books) == 0:
            print("No books available.")
        else:
            for book in books.values():
                book.display()
                print()