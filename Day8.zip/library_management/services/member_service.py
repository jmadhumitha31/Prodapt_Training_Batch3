from models.member import Member
from data.datastore import members


class MemberService:

    def add_member(self, member_id, name, age, membership_type):

        member = Member(member_id, name, age, membership_type)
        members[member_id] = member

        print("Member added successfully.")

    def get_member(self, member_id):

        if member_id in members:
            return members[member_id]

        print("Member not found.")
        return None

    def update_membership(self, member_id, membership_type):

        if member_id in members:
            members[member_id].membership_type = membership_type
            print("Membership updated successfully.")
        else:
            print("Member not found.")

    def delete_member(self, member_id):

        if member_id in members:
            del members[member_id]
            print("Member deleted successfully.")
        else:
            print("Member not found.")

    def view_members(self):

        if len(members) == 0:
            print("No members found.")
        else:
            for member in members.values():
                member.display()
                print()