import unittest
from services.member_service import MemberService


class TestMember(unittest.TestCase):

    def test_member(self):

        service = MemberService()

        service.add_member("M101", "Rahul", 22, "Regular")

        member = service.get_member("M101")

        self.assertEqual(member.name, "Rahul")
        self.assertEqual(member.membership_type, "Regular")


if __name__ == "__main__":
    unittest.main()