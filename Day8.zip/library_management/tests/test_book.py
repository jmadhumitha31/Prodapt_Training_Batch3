import unittest
from services.book_service import BookService


class TestBook(unittest.TestCase):

    def test_book(self):

        service = BookService()

        service.add_book("B101", "Python", "Guido", "Programming", True)

        book = service.get_book("B101")

        self.assertEqual(book.title, "Python")
        self.assertTrue(book.is_available)


if __name__ == "__main__":
    unittest.main()