import unittest
from services.member_service import MemberService
from services.book_service import BookService
from services.borrow_service import BorrowService


class TestBorrow(unittest.TestCase):

    def test_borrow(self):

        member_service = MemberService()
        book_service = BookService()
        borrow_service = BorrowService()

        member_service.add_member("M201", "Kiran", 24, "Premium")
        book_service.add_book("B201", "Java", "James", "Programming", True)

        borrow_service.create_borrow(
            "BR101",
            "M201",
            "B201",
            "17-07-2026",
            "24-07-2026"
        )

        borrow = borrow_service.get_borrow("BR101")

        self.assertEqual(borrow.member.name, "Kiran")
        self.assertEqual(borrow.book.title, "Java")


if __name__ == "__main__":
    unittest.main()