import unittest
from models.plan import Prepaid, Postpaid, DataPack


class TestPlan(unittest.TestCase):

    def test_prepaid_bill(self):
        p = Prepaid("Smart", "1GB", 200)
        self.assertEqual(p.bill(2), 400)

    def test_postpaid_bill(self):
        p = Postpaid("Business", "2GB", 500)
        self.assertEqual(p.bill(1), 590)

    def test_datapack_bill(self):
        p = DataPack("Net", "2GB", 300)
        self.assertEqual(p.bill(1), 350)