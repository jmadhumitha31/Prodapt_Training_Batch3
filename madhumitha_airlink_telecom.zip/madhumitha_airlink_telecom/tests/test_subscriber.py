import unittest
from models.subscriber import Subscriber


class TestSubscriber(unittest.TestCase):

    def test_recharge(self):
        s = Subscriber(
            "S101",
            "John",
            25,
            "9876543210",
            "9876543210",
            "AAD123",
            500
        )

        s.recharge(200)

        self.assertEqual(s.balance, 700)

    def test_deduct(self):
        s = Subscriber(
            "S102",
            "David",
            28,
            "9999999999",
            "9999999999",
            "AAD456",
            1000
        )

        result = s.deduct(300)

        self.assertTrue(result)
        self.assertEqual(s.balance, 700)

    def test_insufficient_balance(self):
        s = Subscriber(
            "S103",
            "Sam",
            30,
            "8888888888",
            "8888888888",
            "AAD789",
            100
        )

        result = s.deduct(500)

        self.assertFalse(result)