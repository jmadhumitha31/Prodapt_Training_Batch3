from data.datastore import DATASTORE


def positive_int(value):
    return value > 0


def is_eligible(subscriber):

    if subscriber.age >= 18 and subscriber.id_proof != "":
        return True

    return False


def has_active_connection(subscriber):

    for connection in DATASTORE["connections"].values():

        if (connection.subscriber.person_id == subscriber.person_id
                and connection.status == "ACTIVE"):
            return True

    return False
