from models.person import Person


class Subscriber(Person):

    def __init__(self, person_id, name, age, phone, mobile_no, id_proof, balance):
        super().__init__(person_id, name, age, phone)
        self.mobile_no = mobile_no
        self.id_proof = id_proof
        self.__balance = balance

    @property
    def balance(self):
        return self.__balance

    def recharge(self, amount):
        self.__balance += amount

    def deduct(self, amount):
        if amount <= self.__balance:
            self.__balance -= amount
            return True
        return False

    def __str__(self):
        return f"{self.name} | {self.mobile_no} | Balance: {self.balance}"
