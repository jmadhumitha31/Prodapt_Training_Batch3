class Connection:

    counter = 9000

    def __init__(self, subscriber, plan, months, amount_paid):
        Connection.counter += 1

        self.connection_id = Connection.counter
        self.subscriber = subscriber
        self.plan = plan
        self.months = months
        self.amount_paid = amount_paid
        self.status = "ACTIVE"

    def __str__(self):
        return (f"Connection ID: {self.connection_id}\n"
                f"Subscriber: {self.subscriber.name}\n"
                f"Plan: {self.plan.name}\n"
                f"Amount Paid: {self.amount_paid}\n"
                f"Status: {self.status}")

    def __del__(self):
        print(f"[ARCHIVE] Connection {self.connection_id} closed")