class Plan:

    company = "AirLink"
    id_prefix = "PLAN-"
    activation_fee = 0
    counter = 100

    def __init__(self, name, data_per_day, monthly_price):
        Plan.counter += 1
        self.plan_id = self.id_prefix + str(Plan.counter)
        self.name = name
        self.data_per_day = data_per_day
        self.monthly_price = monthly_price

    @property
    def monthly_price(self):
        return self.__monthly_price

    @monthly_price.setter
    def monthly_price(self, price):
        if price <= 0:
            raise ValueError("Price must be greater than zero")
        self.__monthly_price = price

    def bill(self, months):
        return self.monthly_price * months

    def __eq__(self, other):
        return self.monthly_price == other.monthly_price

    def __lt__(self, other):
        return self.monthly_price < other.monthly_price

    def __str__(self):
        return f"{self.plan_id} {self.name} ₹{self.monthly_price}"


class Prepaid(Plan):
    id_prefix = "PRE-"
    activation_fee = 0

    def bill(self, months):
        return self.monthly_price * months


class Postpaid(Plan):
    id_prefix = "POST-"
    activation_fee = 100

    def bill(self, months):
        return self.monthly_price * months * 1.18


class DataPack(Plan):
    id_prefix = "DATA-"
    activation_fee = 50

    def bill(self, months):
        return self.monthly_price * months + 50
