from data.seed_data import load_seed_data
from services.subscriber_service import SubscriberService
from services.plan_service import PlanService
from services.connection_service import ConnectionService

load_seed_data()

subscriber_service = SubscriberService()
plan_service = PlanService()
connection_service = ConnectionService()

while True:

    print("\n===== AIRLINK TELECOM =====")
    print("1. Add Subscriber")
    print("2. View Subscribers")
    print("3. Add Plan")
    print("4. View Plans")
    print("5. Create Connection")
    print("6. View Connections")
    print("7. Delete Subscriber")
    print("8. Exit")

    choice = int(input("Enter Choice: "))

    if choice == 1:
        subscriber_service.add_subscriber()

    elif choice == 2:
        subscriber_service.view_subscribers()

    elif choice == 3:
        plan_service.add_plan()

    elif choice == 4:
        plan_service.view_plans()

    elif choice == 5:
        connection_service.create_connection()

    elif choice == 6:
        connection_service.view_connections()

    elif choice == 7:
        sid = input("Enter Subscriber ID: ")
        subscriber_service.delete_subscriber(sid)

    elif choice == 8:
        print("Thank You!")
        break

    else:
        print("Invalid Choice")