from data.datastore import DATASTORE
from models.plan import Prepaid, Postpaid, DataPack


class PlanService:

    def add_plan(self):

        print("1.Prepaid")
        print("2.Postpaid")
        print("3.DataPack")

        choice = int(input("Choose Plan Type: "))

        name = input("Plan Name: ")
        data = input("Data Per Day: ")
        price = float(input("Monthly Price: "))

        if choice == 1:
            plan = Prepaid(name, data, price)

        elif choice == 2:
            plan = Postpaid(name, data, price)

        else:
            plan = DataPack(name, data, price)

        DATASTORE["plans"][plan.plan_id] = plan

        print("Plan Added Successfully")

    def view_plans(self):

        for plan in DATASTORE["plans"].values():
            print(plan)