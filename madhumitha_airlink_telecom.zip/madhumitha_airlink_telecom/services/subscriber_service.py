from data.datastore import DATASTORE
from models.subscriber import Subscriber


class SubscriberService:

    def add_subscriber(self):
        person_id = input("Subscriber ID: ")
        name = input("Name: ")
        age = int(input("Age: "))
        phone = input("Phone: ")
        mobile = input("Mobile No: ")
        id_proof = input("ID Proof: ")
        balance = float(input("Balance: "))

        sub = Subscriber(person_id, name, age, phone,
                         mobile, id_proof, balance)

        DATASTORE["subscribers"][person_id] = sub
        print("Subscriber Added Successfully.")

    def view_subscribers(self):
        for sub in DATASTORE["subscribers"].values():
            print(sub)

    def search_subscriber(self, sid):
        return DATASTORE["subscribers"].get(sid)

    def delete_subscriber(self, sid):
        if sid in DATASTORE["subscribers"]:
            del DATASTORE["subscribers"][sid]
            print("Subscriber Deleted")
        else:
            print("Subscriber Not Found")