
from data.datastore import DATASTORE
from models.connection import Connection
from utils.validator import is_eligible


class ConnectionService:

    def create_connection(self):

        sid = input("Subscriber ID: ")

        subscriber = DATASTORE["subscribers"].get(sid)

        if subscriber is None:
            print("Subscriber Not Found")
            return

        if not is_eligible(subscriber):
            print("Subscriber Not Eligible")
            return

        print("\nAvailable Plans")

        for pid, plan in DATASTORE["plans"].items():
            print(pid, plan)

        pid = input("Enter Plan ID: ")

        plan = DATASTORE["plans"].get(pid)

        if plan is None:
            print("Invalid Plan")
            return

        months = int(input("Months: "))

        amount = plan.bill(months)

        if subscriber.deduct(amount):

            connection = Connection(
                subscriber,
                plan,
                months,
                amount
            )

            DATASTORE["connections"][connection.connection_id] = connection

            print("Connection Created")
            print(connection)

        else:
            print("Insufficient Balance")

    def view_connections(self):

        for con in DATASTORE["connections"].values():
            print(con)
            print("-" * 40)


