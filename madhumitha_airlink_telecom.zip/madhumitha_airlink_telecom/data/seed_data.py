from models.subscriber import Subscriber
from models.plan import Prepaid, Postpaid, DataPack
from data.datastore import DATASTORE


def load_seed_data():

    # Subscribers
    s1 = Subscriber(
        "SUB01",
        "Karthik",
        26,
        "9876543210",
        "9876543210",
        "AAD-4821-9034",
        2000
    )

    s2 = Subscriber(
        "SUB02",
        "Divya",
        34,
        "9876543211",
        "9876543211",
        "AAD-7733-1268",
        5000
    )

    s3 = Subscriber(
        "SUB03",
        "Vimal",
        16,
        "9876543212",
        "9876543212",
        "",
        500
    )

    DATASTORE["subscribers"][s1.person_id] = s1
    DATASTORE["subscribers"][s2.person_id] = s2
    DATASTORE["subscribers"][s3.person_id] = s3

    # Plans
    p1 = Prepaid("Smart Saver", "1GB/day", 200)
    p2 = Postpaid("Business Pro", "2GB/day", 500)
    p3 = DataPack("NetMax", "2GB/day", 300)

    DATASTORE["plans"][p1.plan_id] = p1
    DATASTORE["plans"][p2.plan_id] = p2
    DATASTORE["plans"][p3.plan_id] = p3


