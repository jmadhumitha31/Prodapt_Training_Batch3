DATASTORE = {
    "subscribers": {},
    "plans": {},
    "connections": {}
}
