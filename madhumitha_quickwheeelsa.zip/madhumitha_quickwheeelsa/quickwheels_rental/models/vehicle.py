class Vehicle:
    company = "QuickWheels"
    id_prefix = ""
    deposit_days = 0
    auto_id_counter = 101

    def __init__(self, name, daily_rate, vehicle_id=None):
        if vehicle_id:
            self.vehicle_id = vehicle_id
        else:
            self.vehicle_id = f"{self.id_prefix}{self.__class__.auto_id_counter}"
            self.__class__.auto_id_counter += 1
        self.name = name
        self.available = True
        self.daily_rate = daily_rate

    @property
    def daily_rate(self):
        return self._daily_rate

    @daily_rate.setter
    def daily_rate(self, value):
        if value <= 0:
            raise ValueError()
        self._daily_rate = value

    def rental_cost(self, days):
        pass

    def __eq__(self, other):
        if isinstance(other, Vehicle):
            return self.daily_rate == other.daily_rate
        return False

    def __lt__(self, other):
        if isinstance(other, Vehicle):
            return self.daily_rate < other.daily_rate
        return NotImplemented

    def __str__(self):
        return f"{self.vehicle_id} - {self.name}"

class Bike(Vehicle):
    id_prefix = "B-"
    deposit_days = 1

    def rental_cost(self, days):
        return self.daily_rate * days

class Car(Vehicle):
    id_prefix = "C-"
    deposit_days = 2

    def rental_cost(self, days):
        return self.daily_rate * days * 1.05

class SUV(Vehicle):
    id_prefix = "S-"
    deposit_days = 3

    def rental_cost(self, days):
        return (self.daily_rate * days) + 500