class Rental:
    auto_id_counter = 5001

    def __init__(self, customer, vehicle, planned_days, amount_paid, deposit):
        self.rental_id = self.__class__.auto_id_counter
        self.__class__.auto_id_counter += 1
        self.customer = customer
        self.vehicle = vehicle
        self.planned_days = planned_days
        self.amount_paid = amount_paid
        self.deposit = deposit
        self.status = "ACTIVE"

    def __del__(self):
        damage_note = getattr(self, "damage_note", "")
        print(f"[ARCHIVE] Rental Invoice {self.rental_id} closed {damage_note}".strip())

    def __str__(self):
        return f"Rental {self.rental_id}: {self.customer.name} rented {self.vehicle.vehicle_id}"