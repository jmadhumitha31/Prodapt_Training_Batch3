import pytest
from data.datastore import DATASTORE
from models.vehicle import Bike, Car, SUV

@pytest.fixture(autouse=True)
def setup_teardown():
    DATASTORE["customers"].clear()
    DATASTORE["vehicles"].clear()
    DATASTORE["rentals"].clear()

def test_rental_cost_overriding():
    b = Bike("Bike1", 400)
    c = Car("Car1", 1800)
    s = SUV("SUV1", 3500)
    assert b.rental_cost(2) == 800
    assert c.rental_cost(2) == 3780
    assert s.rental_cost(2) == 7500

def test_rate_validation():
    with pytest.raises(ValueError):
        Bike("Bike2", 0)
    with pytest.raises(ValueError):
        Car("Car2", -50)