import pytest
from data.datastore import DATASTORE
from models.customer import Customer
from models.vehicle import Bike
from services.rental_service import RentalService
from services.customer_service import CustomerService
from services.vehicle_service import VehicleService

@pytest.fixture(autouse=True)
def setup_teardown():
    DATASTORE["customers"].clear()
    DATASTORE["vehicles"].clear()
    DATASTORE["rentals"].clear()

def test_rent_success():
    cs = CustomerService()
    vs = VehicleService()
    rs = RentalService()
    
    c = Customer("C1", "Test Cust", 25, "123", "LIC1", 1500)
    v = Bike("Honda", 400, "B-101")
    cs.add(c)
    vs.add(v)
    
    rental = rs.rent("C1", "B-101", 2)
    
    assert rental is not None
    assert rental.rental_id in DATASTORE["rentals"]
    assert v.available is False
    assert c.balance == 300

def test_ineligible_blocked():
    cs = CustomerService()
    vs = VehicleService()
    rs = RentalService()
    
    c = Customer("CU03", "Rahul", 17, "111", None, 2000)
    v = Bike("Honda", 400, "B-101")
    cs.add(c)
    vs.add(v)
    
    rental = rs.rent("CU03", "B-101", 2)
    
    assert rental is None
    assert len(DATASTORE["rentals"]) == 0
    assert v.available is True
    assert c.balance == 2000