def is_eligible(customer):
    return customer.age >= 18 and bool(customer.license_no)

def is_available(vehicle):
    return vehicle.available

def positive_int(value):
    try:
        val = int(value)
        return val > 0
    except ValueError:
        return False