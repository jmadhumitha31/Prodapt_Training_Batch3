from services.customer_service import CustomerService
from services.vehicle_service import VehicleService
from services.rental_service import RentalService

class RentalSystem:
    def __init__(self):
        self.customer_service = CustomerService()
        self.vehicle_service = VehicleService()
        self.rental_service = RentalService()
