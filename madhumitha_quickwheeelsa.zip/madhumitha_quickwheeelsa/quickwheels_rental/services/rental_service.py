from data.datastore import DATASTORE
from models.rental import Rental
from utils.validator import is_eligible, is_available

class RentalService:
    def rent(self, cust_id, veh_id, days):
        customer = DATASTORE["customers"].get(cust_id)
        vehicle = DATASTORE["vehicles"].get(veh_id)

        if not customer or not vehicle:
            return None

        if not is_eligible(customer) or not is_available(vehicle):
            return None

        cost = vehicle.rental_cost(days)
        offer = getattr(vehicle, "festival_offer", 0)
        if offer > 0:
            cost -= cost * (offer / 100)

        deposit = vehicle.daily_rate * vehicle.deposit_days
        total = cost + deposit

        if customer.pay(total):
            vehicle.available = False
            rental = Rental(customer, vehicle, days, cost, deposit)
            DATASTORE["rentals"][rental.rental_id] = rental
            return rental
        return None

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        rental = self.get(rental_id)
        if not rental or rental.status == "CLOSED":
            return False

        extra_days = actual_days - rental.planned_days
        late_fee = 0
        if extra_days > 0:
            late_fee = extra_days * rental.vehicle.daily_rate * 1.5

        damage_fine = 1000 if damage_note else 0
        charges = late_fee + damage_fine

        refund = max(0, rental.deposit - charges)
        rental.customer.add_money(refund)
        
        if damage_note:
            setattr(rental, "damage_note", damage_note)

        rental.vehicle.available = True
        rental.status = "CLOSED"
        return True

    def get(self, rental_id):
        return DATASTORE["rentals"].get(rental_id)

    def list(self):
        return list(DATASTORE["rentals"].values())

    def delete(self, rental_id):
        if rental_id in DATASTORE["rentals"]:
            del DATASTORE["rentals"][rental_id]