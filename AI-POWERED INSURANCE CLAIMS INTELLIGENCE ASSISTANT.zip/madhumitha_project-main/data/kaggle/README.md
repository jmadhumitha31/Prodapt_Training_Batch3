# Kaggle / External Insurance Claims Dataset Directory

Drop your Kaggle insurance dataset into this folder:
`c:\Users\sai.chaithanya\Downloads\Madhumitha\data\kaggle\`

## 1. Supported File Formats & Names
You can place any of the following in this folder:
- **`insurance_claims.csv`** (Default standard Kaggle Auto Insurance Claims Fraud dataset)
- **`claims.csv`**, **`test_claims.csv`**, or **any `.csv` file**
- **`claims.json`** or **any `.json` file**

## 2. Standard Kaggle Columns Automatically Mapped
The parser automatically normalizes common Kaggle column names:
- **Claim ID**: `claim_id`, `claim_number`, `policy_number`, or auto-generated `CLM-KAGGLE-{i}`
- **Loss / Claim Amount**: `total_claim_amount`, `claim_amount`, `amount`, `total_loss`
- **Inception / Bind Date**: `policy_bind_date`, `policy_inception_date`, `inception_date`, or `months_as_customer`
- **Incident Date**: `incident_date`, `loss_date`, `accident_date`
- **Documentation**: `police_report_available` ('YES'/'NO'), `police_report_filed` (bool/int)
- **Witnesses**: `witnesses`, `witness_present`
- **Claim Line / Type**: `incident_type`, `collision_type`, `claim_type`
- **Severity**: `incident_severity`, `severity` (e.g. Major Damage, Minor Damage, Total Loss)
- **Policyholder Profile**: `insured_occupation`, `insured_education_level`, `insured_sex`, `age`, `policy_annual_premium`, `policy_deductable`, `umbrella_limit`
- **Fraud Ground Truth**: `fraud_reported` ('Y'/'N'), `fraud`, `is_fraud` (0 or 1)
- **Narrative**: `claim_description`, `description`, or auto-synthesized from collision details

## 3. How to Trigger Ingestion
The server provides two ways to load this dataset:
1. **Automatic on Server Startup / Rebuild**:
   If a file is present in `data/kaggle/`, the server automatically detects it, parses it, runs the 4-pillar risk calibration, fits the 9-D Isolation Forest, generates SHAP attributions, computes live embeddings, and serves it.
2. **Instant Live Ingestion via API (No server restart required)**:
   Make a POST request to:
   ```bash
   curl -X POST http://127.0.0.1:8000/api/dataset/load-kaggle
   ```
   Or check status via:
   ```bash
   curl http://127.0.0.1:8000/api/dataset/status
   ```
