import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

from backend.analytics import analytics_engine
from backend.llm_client import llm_client

logger = logging.getLogger("MultiAgentWorkflow")
logging.basicConfig(level=logging.INFO)

class BaseAgent:
    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role

class ClaimsRetrievalAgent(BaseAgent):
    def __init__(self):
        super().__init__("RetrievalAgent", "Precedent & Similarity Analyst")

    def run(self, claim: Dict[str, Any]) -> Dict[str, Any]:
        sim_data = analytics_engine.find_similar_claims(claim["claim_id"], top_k=3)
        sim_claims = sim_data.get("similar_historical_claims", [])

        # Formulate agent analysis using NVIDIA NIM
        prompt = (
            f"You are the Claims Retrieval Agent. Analyze these similar historical claims for target claim {claim['claim_id']} ({claim['claim_type']}, ${claim['claim_amount']:,.2f}):\n"
            f"{json.dumps(sim_claims[:2], indent=2)}\n\n"
            f"Provide a 2-3 sentence analysis of historical precedent patterns, shared risk traits, and prior fraud outcomes. "
            f"Always include explicit citations like [Ref: similar_claim=ID, outcome=X]."
        )
        messages = [
            {"role": "system", "content": "You are an expert insurance fraud precedent retrieval analyst. Ground all claims in provided evidence."},
            {"role": "user", "content": prompt}
        ]
        llm_reply = llm_client.chat_completion(messages, temperature=0.15, max_tokens=300)

        return {
            "agent": self.name,
            "role": self.role,
            "similar_claims": sim_claims,
            "analysis": llm_reply,
            "citations": [f"[Ref: similar_claim={c['claim_id']}, sim={c['overall_similarity']}, outcome='{c['historical_outcome']}']" for c in sim_claims]
        }

class ClaimsRiskAnalysisAgent(BaseAgent):
    def __init__(self):
        super().__init__("RiskAnalysisAgent", "Policy & Customer Exposure Analyst")

    def run(self, claim: Dict[str, Any]) -> Dict[str, Any]:
        prof = claim["customer_profile"]
        risk_scores = claim.get("risk_factor_scores", {})
        
        prompt = (
            f"You are the Claims Risk Analysis Agent. Assess policy and socioeconomic risk for claim {claim['claim_id']}:\n"
            f"- Customer Subtype: {prof['subtype_label']} (COIL row #{claim['coil_row_id']})\n"
            f"- Income Bracket: {prof['income_category']} (Approx ${prof['approx_income']:,})\n"
            f"- Policy Limits: ${claim['policy_limit']:,}, Deductible: ${claim['deductible']}\n"
            f"- Claim Amount: ${claim['claim_amount']:,.2f} ({claim['amount_to_income_ratio']}x annual household income)\n"
            f"- Risk Scores: Loss={risk_scores.get('loss_magnitude')}, Velocity={risk_scores.get('velocity_timing')}\n\n"
            f"Provide a 2-3 sentence risk assessment evaluating coverage exposure and policyholder profile. Cite source fields like [Ref: coil_row_id={claim['coil_row_id']}, amount_to_income={claim['amount_to_income_ratio']}x]."
        )
        messages = [
            {"role": "system", "content": "You are a senior insurance risk underwriter and coverage analyst."},
            {"role": "user", "content": prompt}
        ]
        llm_reply = llm_client.chat_completion(messages, temperature=0.15, max_tokens=300)

        return {
            "agent": self.name,
            "role": self.role,
            "analysis": llm_reply,
            "citations": [
                f"[Ref: coil_row_id={claim['coil_row_id']}]",
                f"[Ref: amount_to_income={claim['amount_to_income_ratio']}x]",
                f"[Ref: policy_limit=${claim['policy_limit']:,}]"
            ]
        }

class AnomalyDetectionAgent(BaseAgent):
    def __init__(self):
        super().__init__("AnomalyAgent", "Statistical & Velocity Anomaly Investigator")

    def run(self, claim: Dict[str, Any]) -> Dict[str, Any]:
        iso_score = claim.get("isolation_forest_anomaly_score", 50)
        z_score = claim.get("amount_zscore", 0.0)
        days_inc = claim.get("days_since_inception", 0)
        days_rep = claim.get("days_to_report", 0)

        prompt = (
            f"You are the Anomaly Detection Agent. Investigate unusual statistical and chronological patterns for claim {claim['claim_id']}:\n"
            f"- Inception-to-loss velocity: {days_inc} days (Policy incepted {claim['policy_inception_date']})\n"
            f"- Reporting latency: {days_rep} days post incident\n"
            f"- Peer Group Z-Score: {z_score} standard deviations for {claim['claim_type']}\n"
            f"- ML Isolation Forest Score: {iso_score}/100\n"
            f"- Police report filed: {claim['police_report_filed']}, Witness present: {claim['witness_present']}\n\n"
            f"Highlight whether this claim exhibits early-inception shock loss, excessive reporting delay, or statistical outlier anomalies. Cite evidence."
        )
        messages = [
            {"role": "system", "content": "You are an expert fraud detection data scientist and forensic claims auditor."},
            {"role": "user", "content": prompt}
        ]
        llm_reply = llm_client.chat_completion(messages, temperature=0.15, max_tokens=300)

        return {
            "agent": self.name,
            "role": self.role,
            "analysis": llm_reply,
            "citations": [
                f"[Ref: days_since_inception={days_inc}]",
                f"[Ref: amount_zscore=+{z_score}σ]",
                f"[Ref: isolation_forest_score={iso_score}]",
                f"[Ref: police_report_filed={claim['police_report_filed']}]"
            ]
        }

class ClaimsSummarizationAgent(BaseAgent):
    def __init__(self):
        super().__init__("SummarizationAgent", "Claims Dossier Synthesizer")

    def run(self, claim: Dict[str, Any]) -> Dict[str, Any]:
        prompt = (
            f"You are the Claims Summarization Agent. Prepare a concise, objective 3-bullet executive summary of claim {claim['claim_id']} for an insurance claims reviewer:\n"
            f"- Type: {claim['claim_type']}, Amount: ${claim['claim_amount']:,.2f}, Severity: {claim['incident_severity']}\n"
            f"- Incident Date: {claim['incident_date']}, Location: {claim['incident_city']}, {claim['incident_state']}\n"
            f"- Description: {claim['claim_description']}\n"
            f"- Police Report: {claim['police_report_filed']}, Witness: {claim['witness_present']}\n"
            f"- Prior Claims: {claim['prior_claims_count']}\n\n"
            f"Format as 3 crisp bullet points: 1) Incident Overview, 2) Key Discrepancies/Risk Indicators, 3) File Status."
        )
        messages = [
            {"role": "system", "content": "You are a professional insurance adjuster supervisor preparing executive claim briefs."},
            {"role": "user", "content": prompt}
        ]
        llm_reply = llm_client.chat_completion(messages, temperature=0.15, max_tokens=350)

        return {
            "agent": self.name,
            "role": self.role,
            "summary": llm_reply,
            "citations": [
                f"[Ref: claim_id={claim['claim_id']}]",
                f"[Ref: incident_date={claim['incident_date']}]",
                f"[Ref: claim_amount=${claim['claim_amount']:,.2f}]"
            ]
        }

class InvestigationSupportAgent(BaseAgent):
    def __init__(self):
        super().__init__("InvestigationSupportAgent", "SIU Decision Support & Triage Lead")

    def run_investigation(self, claim: Dict[str, Any]) -> Dict[str, Any]:
        """Execute full multi-agent orchestration, A2A communication, handoffs, and final decision support."""
        a2a_log = []
        now_str = datetime.now().strftime("%H:%M:%S")

        # Step 1: Retrieval Agent
        retrieval_agent = ClaimsRetrievalAgent()
        retrieval_result = retrieval_agent.run(claim)
        a2a_log.append({
            "timestamp": now_str,
            "from_agent": "RetrievalAgent",
            "to_agent": "InvestigationSupportAgent",
            "event_type": "A2A_BROADCAST",
            "message": f"Retrieved {len(retrieval_result['similar_claims'])} similar historical precedents. Top match sim: {retrieval_result['similar_claims'][0]['overall_similarity'] if retrieval_result['similar_claims'] else 'N/A'}.",
            "citations": retrieval_result["citations"][:2]
        })

        # Step 2: Risk Analysis Agent
        risk_agent = ClaimsRiskAnalysisAgent()
        risk_result = risk_agent.run(claim)
        a2a_log.append({
            "timestamp": now_str,
            "from_agent": "RiskAnalysisAgent",
            "to_agent": "InvestigationSupportAgent",
            "event_type": "A2A_BROADCAST",
            "message": f"Socioeconomic & coverage analysis complete for COIL customer #{claim['coil_row_id']}. Amount/income ratio: {claim['amount_to_income_ratio']}x.",
            "citations": risk_result["citations"][:2]
        })

        # Step 3: Anomaly Detection Agent
        anomaly_agent = AnomalyDetectionAgent()
        anomaly_result = anomaly_agent.run(claim)
        a2a_log.append({
            "timestamp": now_str,
            "from_agent": "AnomalyAgent",
            "to_agent": "InvestigationSupportAgent",
            "event_type": "A2A_BROADCAST",
            "message": f"Multivariate outlier score: {claim.get('isolation_forest_anomaly_score', 0)}/100. Inception-to-loss velocity: {claim['days_since_inception']} days.",
            "citations": anomaly_result["citations"][:2]
        })

        # Step 4: Inter-Agent A2A Query (Anomaly Agent queries Risk Agent)
        if claim["days_since_inception"] <= 30:
            a2a_log.append({
                "timestamp": now_str,
                "from_agent": "AnomalyAgent",
                "to_agent": "RiskAnalysisAgent",
                "event_type": "A2A_QUERY",
                "message": f"Inception alert: loss occurred {claim['days_since_inception']} days after inception. Did policyholder recently modify endorsements or coverage limits?",
                "citations": [f"[Ref: days_since_inception={claim['days_since_inception']}]"]
            })
            a2a_log.append({
                "timestamp": now_str,
                "from_agent": "RiskAnalysisAgent",
                "to_agent": "AnomalyAgent",
                "event_type": "A2A_REPLY",
                "message": f"Confirmed. Policy was initiated on {claim['policy_inception_date']} with maximum limits (${claim['policy_limit']:,}) and standard deductible.",
                "citations": [f"[Ref: policy_inception_date={claim['policy_inception_date']}]"]
            })

        # Step 5: Summarization Agent
        summary_agent = ClaimsSummarizationAgent()
        summary_result = summary_agent.run(claim)
        a2a_log.append({
            "timestamp": now_str,
            "from_agent": "SummarizationAgent",
            "to_agent": "InvestigationSupportAgent",
            "event_type": "A2A_BROADCAST",
            "message": "Executive 3-point briefing synthesized with evidence grounding.",
            "citations": summary_result["citations"][:2]
        })

        # Step 6: Agent Handoff (If High/Critical Risk)
        is_complex = claim["composite_risk_score"] >= 65
        handoff_memo = None
        if is_complex:
            handoff_memo = (
                f"ESCALATION MEMO: Claim {claim['claim_id']} risk score ({claim['composite_risk_score']}/100 - {claim['risk_level']}) "
                f"exceeds standard adjudication threshold. Formal handoff from Automated Triage to Special Investigation Unit (SIU) Lead Agent initiated."
            )
            a2a_log.append({
                "timestamp": now_str,
                "from_agent": "RiskAnalysisAgent",
                "to_agent": "InvestigationSupportAgent",
                "event_type": "AGENT_HANDOFF",
                "message": handoff_memo,
                "citations": [f"[Ref: composite_risk_score={claim['composite_risk_score']}]", f"[Ref: risk_level='{claim['risk_level']}']"]
            })

        # Step 7: Investigation Support Synthesis & Targeted Questions
        rec_action = claim["priority_action"]
        synth_prompt = (
            f"You are the Investigation Support Agent (SIU Lead). Consolidate these multi-agent findings for claim {claim['claim_id']}:\n"
            f"- Risk Level: {claim['risk_level']} (Score: {claim['composite_risk_score']}/100)\n"
            f"- Retrieval Precedents: {retrieval_result['analysis']}\n"
            f"- Risk Profile: {risk_result['analysis']}\n"
            f"- Anomaly Findings: {anomaly_result['analysis']}\n\n"
            f"Provide:\n"
            f"1) Consolidated Decision Support Assessment (2 sentences)\n"
            f"2) 3 Targeted Interview Questions for the Claimant / Witnesses\n"
            f"3) 2 Specific Evidence Items to Request (e.g. dashcam, phone records, forensic repair estimate)\n"
            f"Note: This is human decision support for insurance reviewers, not an automatic binding denial."
        )
        synth_messages = [
            {"role": "system", "content": "You are a Special Investigation Unit (SIU) Director assisting claims reviewers."},
            {"role": "user", "content": synth_prompt}
        ]
        synthesis_text = llm_client.chat_completion(synth_messages, temperature=0.15, max_tokens=450)

        return {
            "claim_id": claim["claim_id"],
            "orchestration_timestamp": datetime.now().isoformat(),
            "composite_risk_score": claim["composite_risk_score"],
            "risk_level": claim["risk_level"],
            "recommended_action": rec_action,
            "is_agent_handoff_triggered": is_complex,
            "handoff_memo": handoff_memo,
            "agent_findings": {
                "retrieval_agent": retrieval_result,
                "risk_agent": risk_result,
                "anomaly_agent": anomaly_result,
                "summarization_agent": summary_result
            },
            "investigation_synthesis": synthesis_text,
            "a2a_communication_log": a2a_log,
            "human_in_the_loop_controls": {
                "allowed_actions": ["Approve Fast-Track", "Request Additional Evidence", "Refer to SIU Investigation", "Reject Claim"],
                "requires_human_signoff": True,
                "note": "AI provides decision support and evidence tracing. Final adjudication requires certified insurance adjuster authorization."
            }
        }

# Singleton instance
investigation_support_agent = InvestigationSupportAgent()
