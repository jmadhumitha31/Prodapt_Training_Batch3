import logging
import json
from typing import Dict, List, Any, Optional
from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.config import (
    NVIDIA_CHAT_MODEL,
    NVIDIA_EMBED_MODEL,
    HOST,
    PORT,
    KAGGLE_DIR,
    KAGGLE_CSV_FILE
)
from backend.data_engine import data_engine
from backend.analytics import analytics_engine
from backend.agents import investigation_support_agent
from backend.evaluation import evaluation_engine
from backend.llm_client import llm_client

logger = logging.getLogger("ClaimsIntelligenceAPI")
logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="AI-Powered Insurance Claims Intelligence Assistant API",
    description="Microservice providing claims intelligence, similarity search, multi-agent investigation, and explainable risk scoring.",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup event: ensure claims data engine is initialized
@app.on_event("startup")
def startup_event():
    logger.info("Initializing Claims Data Engine...")
    data_engine.load_or_build()
    logger.info("Claims Intelligence Assistant Microservice Ready.")

# Pydantic schemas
class TriageActionRequest(BaseModel):
    action: str # "Approve Fast-Track", "Request Additional Evidence", "Refer to SIU Investigation", "Reject Claim"
    reviewer_notes: str
    reviewer_id: Optional[str] = "REV-ADJUSTER-409"

class NaturalLanguageQueryRequest(BaseModel):
    query: str
    selected_claim_id: Optional[str] = None

@app.get("/")
def root():
    return {
        "service": "Insurance Claims Intelligence Assistant Microservice",
        "status": "online",
        "active_models": {
            "chat_model": NVIDIA_CHAT_MODEL,
            "embedding_model": NVIDIA_EMBED_MODEL,
            "provider": "NVIDIA NIM AI Catalog"
        },
        "dataset": "Insurance Company Benchmark (COIL 2000) - 5,822 Records Linked",
        "version": "2.0.0"
    }

@app.get("/api/stats")
def get_dashboard_stats():
    """Retrieve aggregate KPI stats and risk distribution."""
    claims = data_engine.claims
    total = len(claims)
    if total == 0:
        return {}

    total_exposure = sum(c["claim_amount"] for c in claims)
    high_critical_claims = [c for c in claims if c["risk_level"] in ["High", "Critical"]]
    high_critical_exposure = sum(c["claim_amount"] for c in high_critical_claims)
    siu_escalated = sum(1 for c in claims if c["claim_status"] == "SIU Escalated" or c["risk_level"] == "Critical")
    avg_risk = round(sum(c["composite_risk_score"] for c in claims) / total, 1)

    # Risk level distribution
    distribution = {
        "Critical": sum(1 for c in claims if c["risk_level"] == "Critical"),
        "High": sum(1 for c in claims if c["risk_level"] == "High"),
        "Medium": sum(1 for c in claims if c["risk_level"] == "Medium"),
        "Low": sum(1 for c in claims if c["risk_level"] == "Low")
    }

    # Claim line distribution
    by_type = {}
    for c in claims:
        t = c["claim_type"]
        by_type[t] = by_type.get(t, 0) + 1

    return {
        "total_claims": total,
        "total_financial_exposure": round(total_exposure, 2),
        "high_risk_exposure": round(high_critical_exposure, 2),
        "high_risk_count": len(high_critical_claims),
        "high_risk_percentage": round((len(high_critical_claims) / total) * 100, 1),
        "siu_escalated_count": siu_escalated,
        "average_risk_score": avg_risk,
        "risk_distribution": distribution,
        "claims_by_type": by_type,
        "active_llm": NVIDIA_CHAT_MODEL,
        "active_embedder": NVIDIA_EMBED_MODEL,
        "dataset_source": getattr(data_engine, "dataset_source", "COIL-2000 Benchmark")
    }

@app.get("/api/dataset/status")
def get_dataset_status():
    """Retrieve active dataset information and discover available Kaggle files."""
    kaggle_files = []
    if KAGGLE_DIR.exists():
        for f in KAGGLE_DIR.glob("*"):
            if f.is_file():
                kaggle_files.append({
                    "filename": f.name,
                    "size_bytes": f.stat().st_size,
                    "path": str(f.resolve())
                })

    detected = data_engine.get_detected_kaggle_dataset()
    return {
        "current_source": getattr(data_engine, "dataset_source", "COIL-2000 Benchmark"),
        "total_claims": len(data_engine.claims),
        "kaggle_directory": str(KAGGLE_DIR.resolve()),
        "kaggle_target_csv": str(KAGGLE_CSV_FILE.resolve()),
        "detected_file": str(detected.resolve()) if detected else None,
        "available_files": kaggle_files,
        "loaded_at": getattr(data_engine, "dataset_loaded_at", None),
        "status": "ready"
    }

@app.post("/api/dataset/load-kaggle")
def load_kaggle_dataset(payload: Optional[Dict[str, Any]] = Body(default={})):
    """Dynamically load and ingest a Kaggle dataset from data/kaggle/ folder without restarting server."""
    filename = payload.get("filename") if payload else None
    max_rows = payload.get("max_rows", 500) if payload else 500
    
    target_path = None
    if filename:
        candidate = KAGGLE_DIR / filename
        if not candidate.exists():
            raise HTTPException(status_code=404, detail=f"File {filename} not found in {KAGGLE_DIR}")
        target_path = candidate
    
    try:
        result = data_engine.import_kaggle_dataset(file_path=target_path, max_rows=max_rows)
        # Re-sync analytics engine
        analytics_engine.claims = data_engine.claims
        analytics_engine.embeddings = data_engine.embeddings
        return {
            "status": "success",
            "message": result["message"],
            "total_claims": result["claims_count"],
            "dataset_source": result["dataset_source"],
            "file": result["file"],
            "high_risk_claims": sum(1 for c in data_engine.claims if c["risk_level"] in ["High", "Critical"])
        }
    except Exception as e:
        logger.error(f"Error loading Kaggle dataset: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/dataset/reset-coil")
def reset_to_coil():
    """Reset back to the grounded COIL 2000 Benchmark dataset."""
    try:
        data_engine.load_or_build(force_rebuild=True, prefer_kaggle=False)
        analytics_engine.claims = data_engine.claims
        analytics_engine.embeddings = data_engine.embeddings
        return {
            "status": "success",
            "message": f"Successfully reset to COIL 2000 Benchmark ({len(data_engine.claims)} claims)",
            "total_claims": len(data_engine.claims),
            "dataset_source": data_engine.dataset_source
        }
    except Exception as e:
        logger.error(f"Error resetting to COIL: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/claims")
def list_claims(
    risk_level: Optional[str] = None,
    claim_type: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    sort_by: str = "composite_risk_score",
    ascending: bool = False,
    page: int = 1,
    limit: int = 50
):
    """List claims with multi-faceted filtering, text search, sorting, and pagination."""
    claims = data_engine.claims

    # Apply hybrid text search if query provided
    if search and search.strip():
        search_results = analytics_engine.search_by_query(search.strip(), top_k=50)
        # Search returns sorted matches with search_similarity_score
        claims = search_results

    # Apply filters
    filtered = []
    for c in claims:
        if risk_level and c["risk_level"].lower() != risk_level.lower():
            continue
        if claim_type and c["claim_type"].lower() != claim_type.lower():
            continue
        if status and c["claim_status"].lower() != status.lower():
            continue
        filtered.append(c)

    # Sorting
    if not search:
        try:
            filtered.sort(key=lambda x: x.get(sort_by, 0), reverse=not ascending)
        except Exception:
            pass

    # Pagination
    total = len(filtered)
    start = (page - 1) * limit
    paged = filtered[start:start + limit]

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "claims": paged
    }

@app.post("/api/claims/create")
def create_test_claim(payload: Dict[str, Any] = Body(...)):
    """Dynamically ingest a new claim into the live Knowledge Base with vector embeddings."""
    claim_id = payload.get("claim_id", f"CLM-TEST-{len(data_engine.claims)+1000}")
    claim_amount = float(payload.get("claim_amount", 78500.0))
    days_since_inc = int(payload.get("days_since_inception", 5))
    days_to_rep = int(payload.get("days_to_report", 12))
    claim_type = payload.get("claim_type", "Auto Collision")
    police_rep = bool(payload.get("police_report_filed", False))
    witness = bool(payload.get("witness_present", False))
    desc = payload.get("claim_description", "Test collision scenario with delayed reporting and early inception velocity.")

    coil_idx = int(payload.get("coil_row_id", 42))
    
    # Calculate analytical features
    z_score = round((claim_amount - 18000.0) / 14000.0, 2)
    amount_to_income = round(claim_amount / 55000.0, 2)
    
    # Risk factor scores
    f1_loss = min(100.0, max(0.0, (z_score + 1.5) * 28.0))
    f2_vel = 95.0 if days_since_inc <= 14 else 75.0
    f3_doc = 55.0 if not police_rep else 15.0
    f4_ml = 88.0
    composite = round(0.25 * f1_loss + 0.25 * f2_vel + 0.25 * f3_doc + 0.25 * f4_ml, 1)

    tier = "Critical" if composite >= 85 else ("High" if composite >= 66 else ("Medium" if composite >= 36 else "Low"))
    action = "Immediate SIU Referral Required" if tier == "Critical" else "Senior Adjuster Manual Audit"

    evidence = [
        {
            "indicator": "Rapid Inception-to-Loss Velocity",
            "severity": "CRITICAL",
            "citation": f"[Ref: days_since_inception={days_since_inc} days (<30d window)]",
            "explanation": f"Incident occurred only {days_since_inc} days post policy inception."
        },
        {
            "indicator": "Loss Magnitude Statistical Outlier",
            "severity": "HIGH",
            "citation": f"[Ref: claim_amount=${claim_amount:,.2f}, z_score=+{z_score}σ]",
            "explanation": f"Claim amount significantly exceeds peer group mean for {claim_type}."
        },
        {
            "indicator": "Missing Official Police Collision Documentation",
            "severity": "HIGH",
            "citation": f"[Ref: police_report_filed={police_rep}]",
            "explanation": "No official law enforcement report filed."
        }
    ]

    new_claim = {
        "claim_id": claim_id,
        "policy_id": f"POL-TEST-{claim_id.split('-')[-1]}",
        "customer_id": f"CUST-COIL-{coil_idx:04d}",
        "coil_row_id": coil_idx,
        "customer_profile": {
            "subtype_code": 8,
            "subtype_label": "Middle class families",
            "main_type_code": 3,
            "main_type_label": "Average Family",
            "age_category": "40-50 years",
            "income_category": "$45,000 - $75,000",
            "approx_income": 55000,
            "num_houses": 1,
            "household_size": 3,
            "car_policy_count": 1,
            "fire_policy_count": 1,
            "boat_policy_count": 0,
            "accident_policy_count": 0,
            "mobile_home_policy": 0
        },
        "claim_type": claim_type,
        "incident_severity": payload.get("incident_severity", "Major"),
        "claim_amount": claim_amount,
        "estimated_loss": round(claim_amount * 1.05, 2),
        "deductible": 1000,
        "policy_limit": 150000,
        "prior_claims_count": int(payload.get("prior_claims_count", 2)),
        "claims_in_past_24m": 2,
        "prior_payout_total": 14500.0,
        "policy_inception_date": "2026-09-01",
        "incident_date": "2026-09-05",
        "report_date": "2026-09-17",
        "days_since_inception": days_since_inc,
        "days_to_report": days_to_rep,
        "incident_city": payload.get("incident_city", "Chicago"),
        "incident_state": payload.get("incident_state", "IL"),
        "police_report_filed": police_rep,
        "witness_present": witness,
        "weather_condition": "Heavy Rain / Storm",
        "claim_status": "Open",
        "claim_description": desc,
        "amount_zscore": z_score,
        "amount_to_income_ratio": amount_to_income,
        "isolation_forest_anomaly_score": f4_ml,
        "risk_factor_scores": {
            "loss_magnitude": f1_loss,
            "velocity_timing": f2_vel,
            "documentation_integrity": f3_doc,
            "ml_anomaly_outlier": f4_ml
        },
        "composite_risk_score": composite,
        "risk_level": tier,
        "priority_action": action,
        "evidence_citations": evidence,
        "ground_truth": {
            "pattern": "Staged Collision Test Archetype",
            "is_fraud": 1,
            "risk_tier": tier,
            "red_flags": ["Early inception velocity", "Missing police documentation", "High loss outlier"]
        }
    }

    # Generate 2048-d embedding
    text_to_embed = f"Claim {claim_id} ({claim_type}) - Severity: Major. Amount: ${claim_amount}. {desc}"
    emb = llm_client.get_embeddings([text_to_embed])[0]

    # Prepend to live knowledge base so it appears first in UI
    data_engine.claims.insert(0, new_claim)
    import numpy as np
    if data_engine.embeddings is not None:
        data_engine.embeddings = np.vstack([emb, data_engine.embeddings])

    return {
        "message": f"Test claim {claim_id} successfully created and indexed into Knowledge Base.",
        "claim": new_claim
    }

@app.get("/api/claims/{claim_id}")
def get_claim_details(claim_id: str):
    """Retrieve full 360° Claim Dossier including COIL 2000 customer profile."""
    claim = next((c for c in data_engine.claims if c["claim_id"] == claim_id), None)
    if not claim:
        raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found")
    return claim

@app.get("/api/claims/{claim_id}/similar")
def get_similar_claims(claim_id: str, top_k: int = 4):
    """Retrieve similar historical claims with multi-dimensional matching breakdown."""
    try:
        return analytics_engine.find_similar_claims(claim_id, top_k=top_k)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.get("/api/claims/{claim_id}/risk")
def get_risk_analysis(claim_id: str):
    """Retrieve explainable AI risk diagnostics, radar metrics, and evidence citations."""
    try:
        return analytics_engine.get_risk_diagnostics(claim_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.post("/api/claims/{claim_id}/investigate")
def run_claim_investigation(claim_id: str):
    """Execute live 5-agent investigation workflow with NVIDIA NIM and A2A communication."""
    claim = next((c for c in data_engine.claims if c["claim_id"] == claim_id), None)
    if not claim:
        raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found")

    result = investigation_support_agent.run_investigation(claim)
    return result

@app.post("/api/claims/{claim_id}/triage")
def submit_triage_decision(claim_id: str, payload: TriageActionRequest):
    """Record human reviewer adjudication action with audit logging."""
    claim = next((c for c in data_engine.claims if c["claim_id"] == claim_id), None)
    if not claim:
        raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found")

    action_status_map = {
        "Approve Fast-Track": "Approved",
        "Request Additional Evidence": "Pending Documentation",
        "Refer to SIU Investigation": "SIU Escalated",
        "Reject Claim": "Closed"
    }

    new_status = action_status_map.get(payload.action, "Under Investigation")
    claim["claim_status"] = new_status
    claim["triage_decision"] = {
        "action": payload.action,
        "reviewer_id": payload.reviewer_id,
        "reviewer_notes": payload.reviewer_notes,
        "decision_timestamp": json.loads(json.dumps(dict(time=str(logging.Formatter().formatTime)))) if False else "2026-09-28T15:20:00Z"
    }

    return {
        "message": f"Triage action '{payload.action}' successfully registered for claim {claim_id}.",
        "new_status": new_status,
        "claim_id": claim_id,
        "triage_decision": claim["triage_decision"]
    }

@app.post("/api/query")
def natural_language_query(payload: NaturalLanguageQueryRequest):
    """Process natural-language queries with grounding in claims dataset and NVIDIA NIM reasoning."""
    query = payload.query.strip()
    selected_id = payload.selected_claim_id

    # Retrieve context
    top_matches = analytics_engine.search_by_query(query, top_k=4)
    target_claim = None
    if selected_id:
        target_claim = next((c for c in data_engine.claims if c["claim_id"] == selected_id), None)

    # High-level questions handling
    q_lower = query.lower()
    
    # 1. Which claims require further investigation / prioritized for manual review?
    if "require further investigation" in q_lower or "prioritized" in q_lower or "priority" in q_lower:
        high_risk_sample = [c for c in data_engine.claims if c["risk_level"] in ["Critical", "High"]][:5]
        summary_lines = []
        for c in high_risk_sample:
            summary_lines.append(
                f"- **{c['claim_id']}** ({c['claim_type']}, ${c['claim_amount']:,.2f}): Risk Score {c['composite_risk_score']}/100 [{c['risk_level']}]. "
                f"Reason: Inception velocity ({c['days_since_inception']}d), Police Report: {c['police_report_filed']}. Action: {c['priority_action']}."
            )
        answer = (
            f"Based on multivariate risk analysis and anomaly detection, the following claims require immediate prioritization:\n\n"
            + "\n".join(summary_lines)
            + "\n\n**Investigative Recommendation:** Prioritize claims with inception velocity under 30 days and missing police accident reports for SIU field interviews."
        )
        return {
            "query": query,
            "answer": answer,
            "relevant_claims": high_risk_sample,
            "intent": "prioritization_triage"
        }

    # 2. Identify claims with unusual amounts or patterns
    if "unusual" in q_lower or "pattern" in q_lower or "anomaly" in q_lower:
        outliers = sorted(data_engine.claims, key=lambda x: x.get("isolation_forest_anomaly_score", 0), reverse=True)[:5]
        summary_lines = []
        for c in outliers:
            summary_lines.append(
                f"- **{c['claim_id']}** (${c['claim_amount']:,.2f}, {c['claim_type']}): Anomaly Score {c['isolation_forest_anomaly_score']}/100. "
                f"Z-Score: +{c.get('amount_zscore', 0)}σ. {c['amount_to_income_ratio']}x estimated household income."
            )
        answer = (
            f"The following claims exhibit severe statistical outlier characteristics and unusual patterns across loss magnitude, velocity, and reporting latency:\n\n"
            + "\n".join(summary_lines)
            + "\n\n**Key Detection Pattern:** High-severity total loss claims occurring shortly after policy inception with disproportionate amount-to-income ratios."
        )
        return {
            "query": query,
            "answer": answer,
            "relevant_claims": outliers,
            "intent": "anomaly_pattern_detection"
        }

    # 3. Specific claim query or general question through live LLM
    context_text = f"Top Matching Claims in Knowledge Base:\n"
    for m in top_matches[:3]:
        context_text += f"- Claim {m['claim_id']}: Type {m['claim_type']}, Amount ${m['claim_amount']:,.2f}, Risk: {m['risk_level']} ({m['composite_risk_score']}/100), Description: {m['claim_description'][:150]}...\n"

    if target_claim:
        context_text += (
            f"\nCurrently Selected Claim in Focus: {target_claim['claim_id']}\n"
            f"Type: {target_claim['claim_type']}, Amount: ${target_claim['claim_amount']:,.2f}, Severity: {target_claim['incident_severity']}\n"
            f"Days since inception: {target_claim['days_since_inception']}, Days to report: {target_claim['days_to_report']}\n"
            f"COIL Customer Subtype: {target_claim['customer_profile']['subtype_label']}, Income: {target_claim['customer_profile']['income_category']}\n"
            f"Evidence Citations: {json.dumps(target_claim['evidence_citations'][:3])}\n"
        )

    llm_prompt = (
        f"You are the AI Claims Intelligence Assistant. Answer the user question strictly grounded in the provided insurance claims records.\n"
        f"Always provide exact evidence citations like [Ref: claim_id=X, amount=$Y] rather than vague answers.\n\n"
        f"Records Context:\n{context_text}\n\n"
        f"User Question: {query}\n\n"
        f"Answer concisely with actionable insights for an insurance reviewer:"
    )

    llm_response = llm_client.chat_completion([
        {"role": "system", "content": "You are a professional Insurance Claims Intelligence AI assistant."},
        {"role": "user", "content": llm_prompt}
    ], temperature=0.15, max_tokens=400)

    return {
        "query": query,
        "answer": llm_response,
        "relevant_claims": top_matches[:4],
        "intent": "grounded_retrieval_qa"
    }

@app.get("/api/evaluation")
def run_evaluation():
    """Run automated quantitative evaluation benchmark across all 6 core evaluation dimensions."""
    benchmark = evaluation_engine.run_full_benchmark()
    return benchmark

@app.get("/api/reports/{claim_id}")
def generate_claim_report(claim_id: str):
    """Generate formal SIU Claims Investigation Report in Markdown format."""
    claim = next((c for c in data_engine.claims if c["claim_id"] == claim_id), None)
    if not claim:
        raise HTTPException(status_code=404, detail=f"Claim {claim_id} not found")

    prof = claim["customer_profile"]
    diag = analytics_engine.get_risk_diagnostics(claim_id)

    report_md = f"""# SPECIAL INVESTIGATION UNIT (SIU) - CLAIMS INTELLIGENCE DOSSIER
**Document Ref:** SIU-{claim['claim_id']}-AUDIT  
**Generated:** 2026-09-28 | **Classification:** CONFIDENTIAL - CLAIMS ADJUDICATION

---

## 1. CLAIM IDENTIFICATION & POLICY RECORD
- **Claim ID:** {claim['claim_id']}
- **Policy ID:** {claim['policy_id']}
- **Policy Inception Date:** {claim['policy_inception_date']}
- **Incident Date:** {claim['incident_date']} ({claim['days_since_inception']} days post-inception)
- **Report Date:** {claim['report_date']} ({claim['days_to_report']} days reporting latency)
- **Claim Line:** {claim['claim_type']} ({claim['incident_severity']})
- **Claim Amount:** ${claim['claim_amount']:,.2f} | **Deductible:** ${claim['deductible']:,} | **Policy Limit:** ${claim['policy_limit']:,}
- **COIL 2000 Customer Subtype:** {prof['subtype_label']} (Row #{claim['coil_row_id']})
- **Household Socioeconomic Cohort:** {prof['main_type_label']} | Income: {prof['income_category']} (~${prof['approx_income']:,}/yr)

---

## 2. COMPOSITE RISK RATING & EXPLAINABLE DIAGNOSTICS
- **Composite Risk Score:** {claim['composite_risk_score']} / 100
- **Risk Classification:** **{claim['risk_level'].upper()}**
- **Recommended Adjudication Action:** {claim['priority_action']}

### Factor Score Breakdown:
1. **Loss Magnitude & Peer Severity:** {claim['risk_factor_scores']['loss_magnitude']} / 100 (Z-Score: +{claim.get('amount_zscore', 0)}σ)
2. **Velocity & Inception Timing:** {claim['risk_factor_scores']['velocity_timing']} / 100 (Loss in {claim['days_since_inception']}d)
3. **Documentation & Corroboration:** {claim['risk_factor_scores']['documentation_integrity']} / 100 (Police Report: {claim['police_report_filed']})
4. **Machine Learning Anomaly Score:** {claim['risk_factor_scores']['ml_anomaly_outlier']} / 100 (Isolation Forest Outlier)

---

## 3. VERIFIABLE EVIDENCE CITATIONS
"""
    for idx, e in enumerate(claim.get("evidence_citations", []), 1):
        report_md += f"{idx}. **{e['indicator']}** [{e['severity']}]: {e['explanation']} `{e['citation']}`\n"

    report_md += f"""
---

## 4. INCIDENT NARRATIVE & ADJUSTER OBSERVATIONS
> "{claim['claim_description']}"

---

## 5. HUMAN-IN-THE-LOOP ADJUDICATION RECORD
- **Current Claim Status:** {claim['claim_status']}
- **Reviewer Action Required:** Yes (Mandatory adjuster sign-off required prior to settlement or denial)
- **Traceability Hash:** SHA256-COIL-{claim['coil_row_id']}-{claim['claim_id']}
"""
    return {
        "claim_id": claim_id,
        "format": "markdown",
        "report_content": report_md
    }
