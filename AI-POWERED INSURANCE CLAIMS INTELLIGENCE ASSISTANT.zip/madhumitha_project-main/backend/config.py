import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# Dataset paths
COIL_DATA_FILE = BASE_DIR / "ticdata2000.txt"
COIL_DICT_FILE = BASE_DIR / "dictionary.txt"
CLAIMS_CACHE_FILE = DATA_DIR / "insurance_claims_kb.json"
EMBEDDINGS_CACHE_FILE = DATA_DIR / "claims_embeddings.npy"

# Kaggle / External Dataset paths
KAGGLE_DIR = DATA_DIR / "kaggle"
KAGGLE_DIR.mkdir(exist_ok=True)
KAGGLE_CSV_FILE = KAGGLE_DIR / "insurance_claims.csv"

# NVIDIA AI NIM API Configuration
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY", "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")
NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1"
NVIDIA_CHAT_MODEL = os.getenv("NVIDIA_CHAT_MODEL", "meta/llama-3.2-11b-vision-instruct")
NVIDIA_REASONING_MODEL = os.getenv("NVIDIA_REASONING_MODEL", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning")
NVIDIA_EMBED_MODEL = os.getenv("NVIDIA_EMBED_MODEL", "nvidia/nemotron-3-embed-1b")

# Risk Thresholds
RISK_LOW_MAX = 35
RISK_MED_MAX = 65
RISK_HIGH_MAX = 84
# 85+ is CRITICAL

# Server Configuration
HOST = "0.0.0.0"
PORT = 8000
