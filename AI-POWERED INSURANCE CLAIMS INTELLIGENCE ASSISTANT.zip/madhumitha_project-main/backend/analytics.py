import logging
import re
from typing import Dict, List, Any, Optional, Tuple
import numpy as np

from backend.data_engine import data_engine
from backend.llm_client import llm_client

logger = logging.getLogger("AnalyticsEngine")
logging.basicConfig(level=logging.INFO)

class AnalyticsEngine:
    def __init__(self):
        self.data_engine = data_engine

    def search_by_query(self, query: str, top_k: int = 6) -> List[Dict[str, Any]]:
        """Hybrid semantic vector search + lexical keyword matching for natural-language claims queries."""
        claims = self.data_engine.claims
        embeddings = self.data_engine.embeddings

        if not claims or embeddings is None:
            claims = self.data_engine.load_or_build()
            embeddings = self.data_engine.embeddings

        # Compute query vector via NVIDIA Embeddings
        query_vec = llm_client.get_embeddings([query])[0]
        query_norm = np.linalg.norm(query_vec) + 1e-9

        # Cosine similarity
        emb_norms = np.linalg.norm(embeddings, axis=1) + 1e-9
        cosine_sims = np.dot(embeddings, query_vec) / (emb_norms * query_norm)

        # Lexical token matching score
        query_tokens = set(re.findall(r"\w+", query.lower()))
        lexical_scores = []
        for c in claims:
            desc_tokens = set(re.findall(r"\w+", (c["claim_description"] + " " + c["claim_type"]).lower()))
            overlap = len(query_tokens.intersection(desc_tokens))
            score = overlap / max(len(query_tokens), 1)
            lexical_scores.append(score)
        lexical_scores = np.array(lexical_scores)

        # Hybrid score: 75% semantic vector + 25% lexical keyword
        hybrid_scores = 0.75 * cosine_sims + 0.25 * lexical_scores
        top_indices = np.argsort(hybrid_scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            c = claims[idx].copy()
            sim_score = float(hybrid_scores[idx])
            c["search_similarity_score"] = round(max(0.0, min(1.0, (sim_score + 1.0) / 2.0 if sim_score < 0 else sim_score)), 3)
            # Find matched keywords
            matched_terms = list(query_tokens.intersection(set(re.findall(r"\w+", c["claim_description"].lower()))))
            c["matched_keywords"] = matched_terms[:5]
            results.append(c)

        return results

    def find_similar_claims(self, target_claim_id: str, top_k: int = 4) -> Dict[str, Any]:
        """Multi-dimensional similarity matching across Semantic, Financial Loss, and COIL Demographics."""
        claims = self.data_engine.claims
        embeddings = self.data_engine.embeddings

        # Locate target claim
        target_idx = None
        for i, c in enumerate(claims):
            if c["claim_id"] == target_claim_id:
                target_idx = i
                break

        if target_idx is None:
            raise ValueError(f"Claim ID '{target_claim_id}' not found in Knowledge Base.")

        target_claim = claims[target_idx]
        target_emb = embeddings[target_idx]
        target_norm = np.linalg.norm(target_emb) + 1e-9

        # 1. Semantic Similarity
        emb_norms = np.linalg.norm(embeddings, axis=1) + 1e-9
        semantic_sims = np.dot(embeddings, target_emb) / (emb_norms * target_norm)
        # Normalize to 0-1
        semantic_sims = (semantic_sims + 1.0) / 2.0

        # 2. Financial / Loss Profile Similarity
        target_amt = target_claim["claim_amount"]
        loss_sims = []
        for c in claims:
            amt_diff = abs(c["claim_amount"] - target_amt) / max(target_amt, c["claim_amount"], 1.0)
            sev_match = 1.0 if c["incident_severity"] == target_claim["incident_severity"] else 0.5
            type_match = 1.0 if c["claim_type"] == target_claim["claim_type"] else 0.3
            loss_score = 0.4 * (1.0 - min(1.0, amt_diff)) + 0.3 * sev_match + 0.3 * type_match
            loss_sims.append(loss_score)
        loss_sims = np.array(loss_sims)

        # 3. Policyholder Demographic Similarity (COIL 2000 attributes)
        target_prof = target_claim["customer_profile"]
        demo_sims = []
        for c in claims:
            prof = c["customer_profile"]
            sub_match = 1.0 if prof["subtype_code"] == target_prof["subtype_code"] else 0.4
            inc_match = 1.0 if prof["income_category"] == target_prof["income_category"] else 0.5
            car_match = 1.0 - min(1.0, abs(prof["car_policy_count"] - target_prof["car_policy_count"]) / 3.0)
            demo_score = 0.4 * sub_match + 0.3 * inc_match + 0.3 * car_match
            demo_sims.append(demo_score)
        demo_sims = np.array(demo_sims)

        # Composite Multi-Dimensional Similarity: 50% Semantic, 30% Loss Profile, 20% Demographics
        composite_sims = 0.50 * semantic_sims + 0.30 * loss_sims + 0.20 * demo_sims

        # Exclude self
        composite_sims[target_idx] = -1.0
        top_indices = np.argsort(composite_sims)[::-1][:top_k]

        similar_claims = []
        for idx in top_indices:
            c = claims[idx]
            match_score = round(float(composite_sims[idx]), 3)
            
            # Shared risk traits
            shared_traits = []
            if c["claim_type"] == target_claim["claim_type"]:
                shared_traits.append(f"Same Claim Line ({c['claim_type']})")
            if c["incident_severity"] == target_claim["incident_severity"]:
                shared_traits.append(f"Matching Severity ({c['incident_severity']})")
            if abs(c["days_since_inception"] - target_claim["days_since_inception"]) <= 10:
                shared_traits.append("Similar Early Policy Inception Window")
            if not c["police_report_filed"] and not target_claim["police_report_filed"]:
                shared_traits.append("Missing Police Accident Documentation")
            if c["customer_profile"]["income_category"] == target_claim["customer_profile"]["income_category"]:
                shared_traits.append("Same Policyholder Income Cohort")

            historical_outcome = "Settled - Legitimate Loss"
            if c["ground_truth"]["is_fraud"] == 1:
                historical_outcome = "Referred to SIU - Fraud Confirmed / Denied"

            similar_claims.append({
                "claim_id": c["claim_id"],
                "policy_id": c["policy_id"],
                "claim_type": c["claim_type"],
                "incident_severity": c["incident_severity"],
                "claim_amount": c["claim_amount"],
                "days_since_inception": c["days_since_inception"],
                "police_report_filed": c["police_report_filed"],
                "risk_level": c["risk_level"],
                "composite_risk_score": c["composite_risk_score"],
                "overall_similarity": match_score,
                "similarity_breakdown": {
                    "semantic_similarity": round(float(semantic_sims[idx]), 3),
                    "loss_profile_similarity": round(float(loss_sims[idx]), 3),
                    "demographic_similarity": round(float(demo_sims[idx]), 3)
                },
                "shared_risk_traits": shared_traits,
                "historical_outcome": historical_outcome,
                "claim_description": c["claim_description"]
            })

        return {
            "target_claim_id": target_claim_id,
            "target_claim_summary": {
                "claim_type": target_claim["claim_type"],
                "claim_amount": target_claim["claim_amount"],
                "incident_severity": target_claim["incident_severity"],
                "risk_level": target_claim["risk_level"],
                "composite_risk_score": target_claim["composite_risk_score"]
            },
            "similar_historical_claims": similar_claims
        }

    def get_risk_diagnostics(self, claim_id: str) -> Dict[str, Any]:
        """Explainable AI Risk Breakdown, SHAP-style feature contributions, and audit evidence."""
        claims = self.data_engine.claims
        claim = next((c for c in claims if c["claim_id"] == claim_id), None)
        if not claim:
            raise ValueError(f"Claim '{claim_id}' not found.")

        # SHAP-style Waterfall drivers (+ increases risk, - decreases risk)
        waterfall = []
        base_risk = 25.0 # Population baseline risk
        waterfall.append({"feature": "Population Baseline Risk", "impact": base_risk, "type": "baseline"})

        # Inception timing
        if claim["days_since_inception"] <= 14:
            waterfall.append({"feature": "Ultra-Fast Inception-to-Loss (<=14 days)", "impact": +26.5, "type": "risk_increase"})
        elif claim["days_since_inception"] <= 30:
            waterfall.append({"feature": "Early Policy Inception Window (<=30 days)", "impact": +18.0, "type": "risk_increase"})
        else:
            waterfall.append({"feature": "Matured Policy Inception (>60 days)", "impact": -8.5, "type": "risk_decrease"})

        # Amount Z-score
        z = claim.get("amount_zscore", 0.0)
        if z > 1.8:
            waterfall.append({"feature": f"Peer Group Loss Outlier (+{z}σ)", "impact": +22.0, "type": "risk_increase"})
        elif z > 0.5:
            waterfall.append({"feature": f"Above Average Claim Amount (+{z}σ)", "impact": +10.0, "type": "risk_increase"})
        else:
            waterfall.append({"feature": "Standard Loss Distribution", "impact": -5.0, "type": "risk_decrease"})

        # Police documentation
        if not claim["police_report_filed"] and claim["claim_amount"] > 12000:
            waterfall.append({"feature": "Uncorroborated Police Documentation", "impact": +15.0, "type": "risk_increase"})
        elif claim["police_report_filed"]:
            waterfall.append({"feature": "Official Police Incident Report On-File", "impact": -12.0, "type": "risk_decrease"})

        # Prior claim history
        priors = claim.get("prior_claims_count", 0)
        if priors >= 2:
            waterfall.append({"feature": f"Recurring Prior Claim History ({priors} losses)", "impact": +14.0, "type": "risk_increase"})
        elif priors == 0:
            waterfall.append({"feature": "Clean Historical Loss Record (0 priors)", "impact": -9.0, "type": "risk_decrease"})

        # Machine Learning Isolation Forest
        iso_score = claim.get("isolation_forest_anomaly_score", 50.0)
        if iso_score >= 70:
            waterfall.append({"feature": f"ML Isolation Forest Anomaly Score ({iso_score}/100)", "impact": +16.0, "type": "risk_increase"})
        else:
            waterfall.append({"feature": "Conforms with Multivariate Cohort Baseline", "impact": -6.0, "type": "risk_decrease"})

        return {
            "claim_id": claim_id,
            "composite_risk_score": claim["composite_risk_score"],
            "risk_level": claim["risk_level"],
            "priority_action": claim["priority_action"],
            "radar_dimensions": [
                {"dimension": "Loss Magnitude", "score": claim["risk_factor_scores"]["loss_magnitude"], "max": 100},
                {"dimension": "Velocity / Inception", "score": claim["risk_factor_scores"]["velocity_timing"], "max": 100},
                {"dimension": "Documentation Integrity", "score": claim["risk_factor_scores"]["documentation_integrity"], "max": 100},
                {"dimension": "ML Outlier Anomaly", "score": claim["risk_factor_scores"]["ml_anomaly_outlier"], "max": 100},
                {"dimension": "History Frequency", "score": min(100.0, claim["prior_claims_count"] * 33.3), "max": 100}
            ],
            "shap_waterfall": waterfall,
            "evidence_citations": claim["evidence_citations"],
            "underlying_record_trace": {
                "coil_row_id": claim["coil_row_id"],
                "customer_subtype": claim["customer_profile"]["subtype_label"],
                "income_class": claim["customer_profile"]["income_category"],
                "days_since_inception": claim["days_since_inception"],
                "days_to_report": claim["days_to_report"],
                "claim_amount": claim["claim_amount"],
                "police_report_filed": claim["police_report_filed"]
            }
        }

# Singleton analytics engine
analytics_engine = AnalyticsEngine()
