@echo off
setlocal enabledelayedexpansion
title ClaimsIntel AI Assistant - System Launcher

echo ==============================================================================
echo       AI-POWERED INSURANCE CLAIMS INTELLIGENCE ASSISTANT
echo            System Initialization & Microservices Launcher
echo ==============================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: ----------------------------------------------------------------------------
:: 0. Environment PATH Auto-Discovery (Python 3.11 + Node.js fallback)
:: ----------------------------------------------------------------------------
where python >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts;!PATH!"
    )
)

where npm >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "%LOCALAPPDATA%\Programs\nodejs\npm.cmd" (
        set "PATH=%LOCALAPPDATA%\Programs\nodejs;!PATH!"
    )
)

:: Validate Python
where python >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found in system PATH.
    echo Please install Python 3.10+ or add it to PATH.
    pause
    exit /b 1
)

:: ----------------------------------------------------------------------------
:: 1. Backend Virtual Environment (venv) Setup
:: ----------------------------------------------------------------------------
echo [1/4] Checking Python virtual environment (venv)...
if not exist "venv" (
    echo [1/4] Creating new virtual environment in .\venv...
    python -m venv venv
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Failed to create virtual environment!
        pause
        exit /b 1
    )
    echo [1/4] Virtual environment created successfully.
) else (
    echo [1/4] Python virtual environment exists.
)

:: Activate venv
call venv\Scripts\activate.bat

:: Install / Verify backend dependencies
echo [2/4] Verifying backend Python dependencies from requirements.txt...
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Encountered notice during quiet install; checking packages...
    pip install -r requirements.txt
)
echo [2/4] Backend dependencies verified.

:: ----------------------------------------------------------------------------
:: 2. Frontend Node Modules Setup
:: ----------------------------------------------------------------------------
echo [3/4] Checking UI frontend dependencies...
if not exist "frontend\node_modules" (
    echo [3/4] Installing frontend node_modules (npm install)...
    cd frontend
    call npm install
    cd ..
    echo [3/4] Frontend dependencies installed successfully.
) else (
    echo [3/4] Frontend node_modules already installed.
)

:: ----------------------------------------------------------------------------
:: 3. Dataset Verification and Generation (COIL 2000 UCIMLRepo Benchmark)
:: ----------------------------------------------------------------------------
echo [4/4] Verifying claims knowledge base dataset...
if not exist "data\insurance_claims_kb.json" (
    echo [4/4] Dataset not found! Generating claims knowledge base using UCIMLRepo (id=125)...
    python generate_dataset.py
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Dataset generation encountered an issue.
        pause
        exit /b 1
    )
) else (
    echo [4/4] Grounded claims knowledge base verified (data\insurance_claims_kb.json).
)

echo.
echo ==============================================================================
echo   All components ready!
echo   Launching Backend API (FastAPI) and Frontend Dashboard (React Vite)...
echo ==============================================================================
echo.

:: ----------------------------------------------------------------------------
:: 4. Launch Backend and Frontend Microservices
:: ----------------------------------------------------------------------------
start "ClaimsIntel - Backend API (Port 8000)" cmd /k "cd /d "%ROOT_DIR%" && call venv\Scripts\activate.bat && python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000"

start "ClaimsIntel - Frontend Dashboard (Port 5173)" cmd /k "cd /d "%ROOT_DIR%\frontend" && npm run dev -- --host 127.0.0.1 --port 5173"

echo [SUCCESS] Microservices launched:
echo  - Backend API:       http://127.0.0.1:8000  (Docs: http://127.0.0.1:8000/docs)
echo  - Frontend UI:        http://127.0.0.1:5173
echo.
echo Note: The Kaggle dataset path (data\kaggle\) is kept dormant as requested;
echo the grounded COIL 2000 UCIMLRepo claims dataset is the active primary engine.
echo.
timeout /t 6 >nul
