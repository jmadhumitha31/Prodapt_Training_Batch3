import React, { useState } from 'react';
import { 
  GitFork, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  Sliders, 
  Layers, 
  Sparkles,
  ExternalLink,
  SplitSquareVertical
} from 'lucide-react';

export default function SimilarityExplorer({ 
  selectedClaim, 
  similarityData, 
  loading, 
  onSelectClaim 
}) {
  const [comparisonTarget, setComparisonTarget] = useState(null);

  if (!selectedClaim) {
    return (
      <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl">
        <GitFork className="w-10 h-10 text-slate-600 mx-auto mb-2" />
        <h3 className="text-sm font-semibold text-slate-300">No Claim Selected for Similarity Matching</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
          Select any claim from the Workbench to compute multi-dimensional similarity against historical precedent claims.
        </p>
      </div>
    );
  }

  const similarList = similarityData?.similar_historical_claims || [];

  return (
    <div className="space-y-6">
      {/* Target Claim Summary Header */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                ACTIVE FOCUS TARGET
              </span>
              <h2 className="text-lg font-black font-mono text-slate-100">
                {selectedClaim.claim_id}
              </h2>
              <span className="text-xs text-slate-400 font-medium">
                • {selectedClaim.claim_type} ({selectedClaim.incident_severity})
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-3xl line-clamp-1 italic">
              "{selectedClaim.claim_description}"
            </p>
          </div>

          <div className="flex items-center space-x-3 text-right shrink-0">
            <div>
              <div className="text-xs text-slate-400">Claim Amount</div>
              <div className="text-base font-bold font-mono text-slate-100">
                ${selectedClaim.claim_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <div className="text-xs text-slate-400">Risk Rating</div>
              <div className="text-base font-bold font-mono text-rose-400">
                {selectedClaim.composite_risk_score} / 100
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Side-by-Side Comparison Diff Modal / Drawer (if selected) */}
      {comparisonTarget && (
        <div className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/40 shadow-2xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <SplitSquareVertical className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-bold text-slate-100">
                Side-by-Side Precedent Comparison: {selectedClaim.claim_id} vs {comparisonTarget.claim_id}
              </h3>
            </div>
            <button
              onClick={() => setComparisonTarget(null)}
              className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1 rounded bg-slate-900 border border-slate-800 cursor-pointer"
            >
              Close Diff
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs font-mono">
            {/* Target Column */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-cyan-400 font-sans block">
                Target Claim: {selectedClaim.claim_id}
              </span>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Claim Line:</span>
                <span className="text-slate-200">{selectedClaim.claim_type}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Amount:</span>
                <span className="text-slate-100 font-bold">${selectedClaim.claim_amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Inception Velocity:</span>
                <span className="text-slate-200">{selectedClaim.days_since_inception} days</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Police Report:</span>
                <span className={selectedClaim.police_report_filed ? 'text-emerald-400' : 'text-rose-400'}>
                  {selectedClaim.police_report_filed ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400 font-sans">Risk Score:</span>
                <span className="text-rose-400 font-bold">{selectedClaim.composite_risk_score}</span>
              </div>
            </div>

            {/* Precedent Column */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-indigo-400 font-sans block">
                Historical Precedent: {comparisonTarget.claim_id}
              </span>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Claim Line:</span>
                <span className="text-slate-200">{comparisonTarget.claim_type}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Amount:</span>
                <span className="text-slate-100 font-bold">${comparisonTarget.claim_amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Inception Velocity:</span>
                <span className="text-slate-200">{comparisonTarget.days_since_inception} days</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400 font-sans">Police Report:</span>
                <span className={comparisonTarget.police_report_filed ? 'text-emerald-400' : 'text-rose-400'}>
                  {comparisonTarget.police_report_filed ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400 font-sans">Precedent Outcome:</span>
                <span className="text-amber-400 font-bold">{comparisonTarget.historical_outcome}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Similar Claims Precedent Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <GitFork className="w-4 h-4 text-cyan-400" />
              <span>Top Historical Precedent Matches</span>
            </h3>
            <p className="text-xs text-slate-400">
              Ranked by composite multi-dimensional distance: 50% Semantic Incident Narrative, 30% Financial Loss Profile, 20% COIL Demographics.
            </p>
          </div>
          {loading && (
            <span className="text-xs text-cyan-400 flex items-center space-x-1.5 animate-pulse">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Computing embeddings...</span>
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {similarList.map((sim, idx) => {
            const isFraudOutcome = sim.historical_outcome.includes('SIU') || sim.historical_outcome.includes('Denied');
            return (
              <div
                key={sim.claim_id}
                className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 shadow-lg space-y-3 transition-all"
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold text-slate-200">
                        {sim.claim_id}
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {sim.claim_type}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      Amount: ${sim.claim_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  {/* Similarity Badge */}
                  <div className="text-right">
                    <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800 shadow-sm shadow-cyan-900/30">
                      {(sim.overall_similarity * 100).toFixed(1)}% Match
                    </span>
                  </div>
                </div>

                {/* Similarity Breakdown Meters */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Semantic Incident Match:</span>
                    <span className="font-mono text-slate-200">{Math.round((sim.similarity_breakdown?.semantic_similarity || 0) * 100)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-cyan-500 rounded-full" 
                      style={{ width: `${(sim.similarity_breakdown?.semantic_similarity || 0) * 100}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Loss Profile Match:</span>
                    <span className="font-mono text-slate-200">{Math.round((sim.similarity_breakdown?.loss_profile_similarity || 0) * 100)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-500 rounded-full" 
                      style={{ width: `${(sim.similarity_breakdown?.loss_profile_similarity || 0) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Shared Risk Traits */}
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase tracking-wider">
                    Shared Characteristics:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {sim.shared_risk_traits.map((trait, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-slate-300"
                      >
                        {trait}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Precedent Outcome Banner */}
                <div className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                  isFraudOutcome
                    ? 'bg-rose-950/40 border-rose-800 text-rose-300'
                    : 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                }`}>
                  <span className="font-medium">{sim.historical_outcome}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/40">
                    Score: {sim.composite_risk_score}
                  </span>
                </div>

                {/* Compare Diff Button */}
                <div className="pt-1 flex items-center justify-between">
                  <button
                    onClick={() => setComparisonTarget(sim)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 cursor-pointer font-medium"
                  >
                    <SplitSquareVertical className="w-3.5 h-3.5" />
                    <span>Side-by-Side Diff</span>
                  </button>

                  <button
                    onClick={() => onSelectClaim(sim)}
                    className="text-xs text-slate-400 hover:text-slate-200 flex items-center space-x-1 cursor-pointer"
                  >
                    <span>View Dossier</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
