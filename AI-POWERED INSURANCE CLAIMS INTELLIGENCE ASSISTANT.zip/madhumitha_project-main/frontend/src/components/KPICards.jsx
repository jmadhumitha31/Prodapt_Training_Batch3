import React from 'react';
import { 
  FileText, 
  DollarSign, 
  Flame, 
  TrendingUp, 
  ShieldCheck,
  Activity
} from 'lucide-react';

export default function KPICards({ stats }) {
  if (!stats) return null;

  const totalClaims = stats.total_claims || 120;
  const exposureM = ((stats.total_financial_exposure || 0) / 1000000).toFixed(2);
  const highRiskExposureK = Math.round((stats.high_risk_exposure || 0) / 1000);
  const criticalCount = stats.risk_distribution?.Critical || 0;
  const highCount = stats.risk_distribution?.High || 0;
  const avgRisk = stats.average_risk_score || 0;

  return (
    <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800/80 rounded-2xl shadow-sm overflow-hidden">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 divide-y md:divide-y-0 md:divide-x divide-slate-800/70">
        
        {/* Metric 1: Total Ingestion */}
        <div className="p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Claims Ingested</span>
            <FileText className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div>
            <div className="text-2xl font-black font-mono text-slate-100 tracking-tight">
              {totalClaims}
            </div>
            <div className="flex items-center space-x-1.5 mt-1 text-[11px] text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
              <span>COIL 2000 Grounded</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Financial Exposure */}
        <div className="p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Exposure</span>
            <DollarSign className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div>
            <div className="text-2xl font-black font-mono text-slate-100 tracking-tight">
              ${exposureM}M
            </div>
            <div className="flex items-center space-x-1.5 mt-1 text-[11px] text-slate-400">
              <span className="text-amber-400/90 font-mono">${highRiskExposureK}k</span>
              <span>at elevated risk</span>
            </div>
          </div>
        </div>

        {/* Metric 3: Priority Review Queue */}
        <div className="p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Review Queue</span>
            <Flame className="w-3.5 h-3.5 text-rose-400/70" />
          </div>
          <div>
            <div className="text-2xl font-black font-mono text-slate-100 tracking-tight">
              {stats.high_risk_count || 0}
            </div>
            <div className="flex items-center space-x-1.5 mt-1 text-[11px] text-slate-400">
              <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-rose-500/10 text-rose-400 border border-rose-500/20">
                {criticalCount} Critical
              </span>
              <span>•</span>
              <span className="text-slate-400">{highCount} High</span>
            </div>
          </div>
        </div>

        {/* Metric 4: Portfolio Risk Index */}
        <div className="p-4 flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Portfolio Risk Index</span>
            <Activity className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div>
            <div className="text-2xl font-black font-mono text-slate-100 tracking-tight">
              {avgRisk}<span className="text-xs text-slate-500 font-sans font-normal ml-0.5">/ 100</span>
            </div>
            <div className="mt-1 text-[11px] text-slate-400 truncate">
              Calibrated 4-Pillar Score
            </div>
          </div>
        </div>

        {/* Metric 5: Multi-Agent System */}
        <div className="p-4 flex flex-col justify-between space-y-2 col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider">AI Agent Network</span>
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400/70" />
          </div>
          <div>
            <div className="text-2xl font-black font-mono text-slate-100 tracking-tight">
              5 Agents
            </div>
            <div className="flex items-center space-x-1.5 mt-1 text-[11px] text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse inline-block" />
              <span>NVIDIA NIM Live</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
