import React, { useState } from 'react';
import { 
  BarChart3, 
  CheckCircle2, 
  ShieldCheck, 
  RefreshCw, 
  Layers, 
  Zap, 
  Target,
  FileCheck,
  TrendingUp,
  Cpu,
  Loader2,
  Database,
  FolderDown,
  FileSpreadsheet
} from 'lucide-react';

export default function EvaluationDashboard({ evaluationData, loading, onRunEvaluation, onDatasetChanged }) {
  const [ingesting, setIngesting] = useState(false);
  const [datasetMsg, setDatasetMsg] = useState(null);

  const handleLoadKaggle = async () => {
    setIngesting(true);
    setDatasetMsg(null);
    try {
      const resp = await fetch('/api/dataset/load-kaggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await resp.json();
      if (resp.ok) {
        setDatasetMsg({ type: 'success', text: data.message });
        if (onDatasetChanged) onDatasetChanged();
      } else {
        setDatasetMsg({ type: 'error', text: data.detail || 'Failed to ingest Kaggle dataset' });
      }
    } catch (e) {
      setDatasetMsg({ type: 'error', text: e.message });
    } finally {
      setIngesting(false);
    }
  };

  const handleResetCOIL = async () => {
    setIngesting(true);
    setDatasetMsg(null);
    try {
      const resp = await fetch('/api/dataset/reset-coil', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await resp.json();
      if (resp.ok) {
        setDatasetMsg({ type: 'success', text: data.message });
        if (onDatasetChanged) onDatasetChanged();
      } else {
        setDatasetMsg({ type: 'error', text: data.detail || 'Failed to reset COIL dataset' });
      }
    } catch (e) {
      setDatasetMsg({ type: 'error', text: e.message });
    } finally {
      setIngesting(false);
    }
  };

  if (!evaluationData) {
    return (
      <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl">
        <BarChart3 className="w-10 h-10 text-slate-600 mx-auto mb-2" />
        <h3 className="text-sm font-semibold text-slate-300">Loading Evaluation Benchmarks...</h3>
      </div>
    );
  }

  const risk = evaluationData.risk_anomaly_detection || {};
  const retrieval = evaluationData.retrieval_relevance || {};
  const grounding = evaluationData.evidence_grounding || {};
  const summary = evaluationData.summary_quality || {};
  const nlq = evaluationData.natural_language_query || {};
  const cm = risk.confusion_matrix || {};

  return (
    <div className="space-y-6">
      {/* Top Banner & Health Score */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/60 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              BENCHMARK SUITE v2.0
            </span>
            <h2 className="text-lg font-black font-mono text-slate-100">
              Autonomous Intelligence Evaluation Framework
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Quantitative evaluation across retrieval relevance (Precision@K, MRR), anomaly detection (F1, ROC-AUC), evidence grounding, and query intent accuracy.
          </p>
        </div>

        <div className="flex items-center space-x-4">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block font-mono">OVERALL HEALTH SCORE</span>
            <span className="text-2xl font-black font-mono text-emerald-400">
              {evaluationData.overall_health_score} / 100
            </span>
          </div>

          <button
            onClick={onRunEvaluation}
            disabled={loading}
            className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold flex items-center space-x-2 shadow-lg shadow-cyan-600/20 cursor-pointer disabled:opacity-50 transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Running Suite...</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4" />
                <span>Re-Run Benchmark</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Dataset Source & Live Ingestion Card */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
            <Database className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-slate-200">Kaggle / External Dataset Integration Path:</span>
              <code className="text-[11px] font-mono bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-cyan-300">
                data/kaggle/insurance_claims.csv
              </code>
            </div>
            <p className="text-[11px] text-slate-400">
              Drop any Kaggle auto/property claims CSV or JSON into the <span className="font-mono text-slate-300">data/kaggle/</span> folder. The system parses all features, executes 9-D Isolation Forest, recalculates 4-pillar risk calibration, and generates NIM vector embeddings.
            </p>
            {datasetMsg && (
              <div className={`text-[11px] font-mono px-2 py-1 rounded inline-block ${datasetMsg.type === 'success' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800' : 'bg-rose-950/80 text-rose-300 border border-rose-800'}`}>
                {datasetMsg.text}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleLoadKaggle}
            disabled={ingesting}
            className="px-3 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-medium cursor-pointer transition-all flex items-center space-x-1.5 disabled:opacity-50"
          >
            {ingesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FolderDown className="w-3.5 h-3.5" />}
            <span>Ingest Kaggle Dataset</span>
          </button>

          <button
            onClick={handleResetCOIL}
            disabled={ingesting}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-xs font-medium cursor-pointer transition-all flex items-center space-x-1.5 disabled:opacity-50"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset COIL Benchmark</span>
          </button>
        </div>
      </div>

      {/* 4 Core Quantitative Metric Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Retrieval MRR & Precision */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Retrieval Precision@4</span>
            <Target className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-100">
            {Math.round((retrieval.precision_at_k || 0) * 100)}%
          </div>
          <div className="text-[11px] text-slate-400 flex justify-between">
            <span>MRR: <strong className="text-slate-200">{retrieval.mrr}</strong></span>
            <span>NDCG@4: <strong className="text-slate-200">{retrieval.ndcg_at_k}</strong></span>
          </div>
        </div>

        {/* Card 2: Risk F1 & ROC-AUC */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Risk Detection F1-Score</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-100">
            {risk.f1_score}
          </div>
          <div className="text-[11px] text-slate-400 flex justify-between">
            <span>ROC-AUC: <strong className="text-slate-200">{risk.roc_auc}</strong></span>
            <span>Precision: <strong className="text-slate-200">{risk.precision}</strong></span>
          </div>
        </div>

        {/* Card 3: Evidence Grounding */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Evidence Grounding</span>
            <ShieldCheck className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400">
            {grounding.grounding_accuracy_pct}%
          </div>
          <div className="text-[11px] text-slate-400 flex justify-between">
            <span>Hallucination Rate: <strong className="text-slate-200">{grounding.hallucination_rate_pct}%</strong></span>
            <span>Verified Citations</span>
          </div>
        </div>

        {/* Card 4: NLQ Intent Accuracy */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">NL Query Accuracy</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-100">
            {nlq.query_intent_accuracy_pct}%
          </div>
          <div className="text-[11px] text-slate-400 flex justify-between">
            <span>Faithfulness: <strong className="text-slate-200">{Math.round((summary.faithfulness_score || 0) * 100)}%</strong></span>
            <span>6 Core Benchmarks</span>
          </div>
        </div>
      </div>

      {/* 2-Column: Confusion Matrix + Benchmark Test Cases */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Confusion Matrix Visualizer */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center space-x-1.5">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Fraud Risk Confusion Matrix (Binary Threshold &ge; 65)</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500">120 Cohort Claims</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            {/* TP */}
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 space-y-1">
              <span className="text-[10px] font-bold uppercase text-emerald-400 tracking-wider">
                True Positives (TP)
              </span>
              <div className="text-2xl font-black font-mono text-emerald-300">
                {cm.true_positive || 0}
              </div>
              <span className="text-[10px] text-slate-400">High-Risk Correctly Flagged</span>
            </div>

            {/* FP */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                False Positives (FP)
              </span>
              <div className="text-2xl font-black font-mono text-slate-300">
                {cm.false_positive || 0}
              </div>
              <span className="text-[10px] text-slate-500">Over-Flagged Legitimate</span>
            </div>

            {/* FN */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                False Negatives (FN)
              </span>
              <div className="text-2xl font-black font-mono text-slate-300">
                {cm.false_negative || 0}
              </div>
              <span className="text-[10px] text-slate-500">Missed Suspicious Losses</span>
            </div>

            {/* TN */}
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 space-y-1">
              <span className="text-[10px] font-bold uppercase text-emerald-400 tracking-wider">
                True Negatives (TN)
              </span>
              <div className="text-2xl font-black font-mono text-emerald-300">
                {cm.true_negative || 0}
              </div>
              <span className="text-[10px] text-slate-400">Clean Legitimate Cleared</span>
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed italic">
            "{risk.interpretation}"
          </p>
        </div>

        {/* Natural Language Query Benchmarks */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Core Natural-Language Query Evaluation Suite</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">{nlq.query_intent_accuracy_pct}% Accuracy</span>
          </div>

          <div className="space-y-2">
            {(nlq.benchmark_cases || []).map((b, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <div className="space-y-0.5 max-w-sm">
                  <div className="text-slate-200 font-medium truncate" title={b.query}>
                    "{b.query}"
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">
                    Intent: {b.expected_intent}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {Math.round(b.accuracy * 100)}% Pass
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
