import React from 'react';
import { 
  ShieldAlert, 
  Layers, 
  GitFork, 
  Radar, 
  Bot, 
  MessageSquareCode, 
  BarChart3,
  Sparkles,
  Lightbulb
} from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, stats, onOpenCopilot }) {
  const tabs = [
    { id: 'workbench', label: 'Claims Workbench', icon: Layers },
    { id: 'explainability', label: 'Explainability & XAI', icon: Lightbulb },
    { id: 'similarity', label: 'Similarity & Precedents', icon: GitFork },
    { id: 'risk_radar', label: 'Risk & Anomaly Radar', icon: Radar },
    { id: 'multi_agent', label: 'Multi-Agent War Room', icon: Bot },
    { id: 'copilot', label: 'AI Claims Copilot', icon: MessageSquareCode },
    { id: 'evaluation', label: 'Evaluation & Benchmarks', icon: BarChart3 },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#090d16]/95 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-[1720px] mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-14">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700/80 flex items-center justify-center text-cyan-400 shadow-sm">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-sm tracking-wide text-slate-100 font-mono">
                  Claims<span className="text-cyan-400 font-black">Intel</span>
                </span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-medium bg-slate-800 text-slate-400 border border-slate-700/60 font-mono">
                  v2.0 PRO
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Tabs (Linear-Style Pill Navigation) */}
          <nav className="hidden xl:flex items-center space-x-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-slate-800 text-slate-100 font-semibold border border-slate-700 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 font-normal'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Telemetry & Action */}
          <div className="flex items-center space-x-2.5">
            {/* Unified Telemetry Chip */}
            <div className="hidden lg:flex items-center space-x-2 px-2.5 py-1 bg-slate-900/60 border border-slate-800/80 rounded-lg text-[11px] text-slate-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
              <span>NIM: <strong className="text-slate-200 font-medium font-mono">Llama-3.2-11B</strong></span>
              <span className="text-slate-600">•</span>
              <span>Dataset: <strong className="text-cyan-400 font-medium font-mono">{stats?.dataset_source?.includes('Kaggle') ? 'Kaggle Dataset' : 'COIL 2000'}</strong> ({stats?.total_claims || 0} Claims)</span>
            </div>

            {/* Quick Copilot Trigger Button */}
            <button
              onClick={() => setActiveTab('copilot')}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 rounded-lg text-xs font-medium cursor-pointer transition-all shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ask Copilot</span>
            </button>
          </div>
        </div>

        {/* Mobile/Tablet Sub-Nav Bar */}
        <div className="flex xl:hidden overflow-x-auto py-1.5 space-x-1 border-t border-slate-800/60 no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-1.5 px-2.5 py-1 whitespace-nowrap rounded-md text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-slate-800 text-slate-100 border border-slate-700'
                    : 'text-slate-400 hover:bg-slate-800/30'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
