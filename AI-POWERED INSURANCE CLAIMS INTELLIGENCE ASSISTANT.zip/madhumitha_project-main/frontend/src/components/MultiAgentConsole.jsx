import React, { useState } from 'react';
import { 
  Bot, 
  Sparkles, 
  GitPullRequest, 
  MessageSquare, 
  ShieldAlert, 
  FileCheck2, 
  CheckCircle, 
  AlertOctagon, 
  HelpCircle,
  FileQuestion,
  Layers,
  ArrowRight,
  ShieldCheck,
  Send,
  Loader2
} from 'lucide-react';

export default function MultiAgentConsole({ 
  selectedClaim, 
  investigationResult, 
  loading, 
  onRunInvestigation,
  onOpenTriageModal 
}) {
  const [activeSubTab, setActiveSubTab] = useState('synthesis'); // 'synthesis', 'a2a_log', 'agents'

  if (!selectedClaim) {
    return (
      <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl">
        <Bot className="w-10 h-10 text-slate-600 mx-auto mb-2" />
        <h3 className="text-sm font-semibold text-slate-300">No Claim Selected for Multi-Agent Analysis</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
          Select a claim from the Workbench and click "Run 5-Agent Investigation" to orchestrate the multi-agent investigation workflow.
        </p>
      </div>
    );
  }

  const agents = [
    { name: 'Claims Retrieval Agent', role: 'Precedent & Similarity Analyst', color: 'text-cyan-400', border: 'border-cyan-800' },
    { name: 'Claims Risk Analysis Agent', role: 'Policy & Customer Exposure Analyst', color: 'text-indigo-400', border: 'border-indigo-800' },
    { name: 'Anomaly Detection Agent', role: 'Statistical & Velocity Anomaly Investigator', color: 'text-rose-400', border: 'border-rose-800' },
    { name: 'Claims Summarization Agent', role: 'Claims Dossier Synthesizer', color: 'text-emerald-400', border: 'border-emerald-800' },
    { name: 'Investigation Support Agent', role: 'SIU Decision Support & Triage Lead', color: 'text-amber-400', border: 'border-amber-800' }
  ];

  const a2aLog = investigationResult?.a2a_communication_log || [];
  const findings = investigationResult?.agent_findings || {};
  const isHandoff = investigationResult?.is_agent_handoff_triggered;

  return (
    <div className="space-y-6">
      {/* Top Controller Header */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/50 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
              MULTI-AGENT WAR ROOM
            </span>
            <h2 className="text-lg font-black font-mono text-slate-100">
              {selectedClaim.claim_id}
            </h2>
            <span className="text-xs text-slate-400 font-medium">
              • {selectedClaim.claim_type} (${selectedClaim.claim_amount.toLocaleString()})
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Autonomous collaborative team of 5 specialized agents utilizing NVIDIA NIM for forensic investigation.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => onRunInvestigation(selectedClaim)}
            disabled={loading}
            className="px-4 py-2 bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold flex items-center space-x-2 shadow-lg shadow-cyan-600/20 cursor-pointer disabled:opacity-50 transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Orchestrating 5 Agents...</span>
              </>
            ) : (
              <>
                <Bot className="w-4 h-4" />
                <span>Re-Run Investigation</span>
              </>
            )}
          </button>

          <button
            onClick={() => onOpenTriageModal(selectedClaim)}
            className="px-3 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold flex items-center space-x-1.5 cursor-pointer shadow-md shadow-emerald-700/20"
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Adjudicate</span>
          </button>
        </div>
      </div>

      {/* Agent Handoff Escalation Memo Banner (if triggered) */}
      {isHandoff && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-700 shadow-xl flex items-start space-x-3 animate-in fade-in">
          <AlertOctagon className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black font-mono text-rose-300 uppercase tracking-wider">
                FORMAL AGENT HANDOFF: AUTOMATED TRIAGE &rarr; SPECIAL INVESTIGATION UNIT (SIU)
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 text-rose-300 border border-rose-800">
                Trigger: Risk Score &ge; 65
              </span>
            </div>
            <p className="text-xs text-rose-200 mt-1 leading-relaxed">
              {investigationResult?.handoff_memo || "Claim complexity exceeds standard straight-through threshold. Risk Analysis and Anomaly agents have formally escalated this dossier to the Investigation Support Agent for targeted investigator inquiry."}
            </p>
          </div>
        </div>
      )}

      {/* 5 Agent Roster Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {agents.map((ag, idx) => (
          <div
            key={idx}
            className={`p-3 rounded-xl bg-slate-900/80 border ${ag.border} shadow-sm space-y-1`}
          >
            <div className="flex items-center justify-between">
              <Bot className={`w-4 h-4 ${ag.color}`} />
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-950 text-slate-400">
                Agent #{idx + 1}
              </span>
            </div>
            <div className="text-xs font-bold text-slate-200 truncate" title={ag.name}>
              {ag.name}
            </div>
            <div className="text-[10px] text-slate-400 truncate">
              {ag.role}
            </div>
          </div>
        ))}
      </div>

      {/* Sub Tabs: Synthesis, A2A Communication Log, Individual Findings */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="flex items-center space-x-2 p-3 border-b border-slate-800 bg-slate-950/60">
          <button
            onClick={() => setActiveSubTab('synthesis')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeSubTab === 'synthesis'
                ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-500/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Investigation Synthesis & Questioning
          </button>
          <button
            onClick={() => setActiveSubTab('a2a_log')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center space-x-1.5 ${
              activeSubTab === 'a2a_log'
                ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-500/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>A2A Message Passing Log</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300">
              {a2aLog.length}
            </span>
          </button>
          <button
            onClick={() => setActiveSubTab('agents')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeSubTab === 'agents'
                ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-500/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Specialized Agent Findings
          </button>
        </div>

        <div className="p-5">
          {/* SubTab 1: Synthesis & Human Decision Support */}
          {activeSubTab === 'synthesis' && (
            <div className="space-y-5">
              {investigationResult?.investigation_synthesis ? (
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line space-y-3">
                  <div className="flex items-center space-x-2 text-cyan-400 font-bold border-b border-slate-800 pb-2">
                    <FileCheck2 className="w-4 h-4" />
                    <span>CONSOLIDATED SPECIAL INVESTIGATION UNIT (SIU) ADVISORY</span>
                  </div>
                  {investigationResult.investigation_synthesis}
                </div>
              ) : (
                <div className="p-6 text-center text-slate-500 text-xs">
                  Click "Run 5-Agent Investigation" above to execute the collaborative multi-agent workflow.
                </div>
              )}

              {/* Human-in-the-Loop Decision Notice */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <span className="font-semibold text-slate-200 flex items-center space-x-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Human-in-the-Loop Reviewer Gate</span>
                  </span>
                  <p className="text-[11px] text-slate-400">
                    The assistant generates recommendations and audit evidence. Certified insurance adjusters retain final authority.
                  </p>
                </div>
                <button
                  onClick={() => onOpenTriageModal(selectedClaim)}
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold cursor-pointer shrink-0"
                >
                  Record Decision
                </button>
              </div>
            </div>
          )}

          {/* SubTab 2: Real-time A2A Message Passing Log */}
          {activeSubTab === 'a2a_log' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Verifiable event trace of structured Agent-to-Agent (A2A) queries, broadcasts, and escalation handoffs:
              </p>

              <div className="space-y-2.5">
                {a2aLog.map((log, idx) => {
                  const isHandoffEvent = log.event_type === 'AGENT_HANDOFF';
                  const isQueryEvent = log.event_type === 'A2A_QUERY';
                  const isReplyEvent = log.event_type === 'A2A_REPLY';

                  return (
                    <div
                      key={idx}
                      className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                        isHandoffEvent
                          ? 'bg-rose-950/30 border-rose-800'
                          : isQueryEvent || isReplyEvent
                          ? 'bg-indigo-950/30 border-indigo-800'
                          : 'bg-slate-950/70 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-[10px] text-slate-500">{log.timestamp}</span>
                          <span className="font-bold text-cyan-300 font-mono text-[11px]">{log.from_agent}</span>
                          <ArrowRight className="w-3 h-3 text-slate-600" />
                          <span className="font-bold text-indigo-300 font-mono text-[11px]">{log.to_agent}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          isHandoffEvent ? 'bg-rose-900/60 text-rose-300' : 'bg-slate-800 text-slate-300'
                        }`}>
                          {log.event_type}
                        </span>
                      </div>

                      <p className="text-slate-300 pl-1 leading-relaxed">
                        {log.message}
                      </p>

                      {log.citations && log.citations.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1 pl-1">
                          {log.citations.map((c, cIdx) => (
                            <code key={cIdx} className="text-[10px] text-cyan-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                              {c}
                            </code>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* SubTab 3: Specialized Agent Findings */}
          {activeSubTab === 'agents' && (
            <div className="space-y-4">
              {Object.keys(findings).length === 0 ? (
                <div className="p-6 text-center text-slate-500 text-xs">
                  Run investigation to view individual agent dossiers.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(findings).map(([key, f], idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <span className="text-xs font-bold text-slate-200">{f.agent}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{f.role}</span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {f.analysis || f.summary}
                      </p>
                      <div className="flex flex-wrap gap-1 pt-1">
                        {(f.citations || []).map((cite, cIdx) => (
                          <span key={cIdx} className="text-[10px] font-mono text-cyan-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                            {cite}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
