import React, { useState } from 'react';
import { 
  Lightbulb, 
  ShieldCheck, 
  Layers, 
  ArrowUpRight, 
  ArrowDownRight, 
  Database, 
  Link2, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  FileSearch, 
  Sliders, 
  RotateCcw,
  Sparkles,
  Info,
  Scale
} from 'lucide-react';

export default function ExplainabilityScreen({ 
  selectedClaim, 
  claims, 
  riskData, 
  onSelectClaim 
}) {
  // What-If Simulation State
  const [simPoliceReport, setSimPoliceReport] = useState(null);
  const [simDaysSinceInception, setSimDaysSinceInception] = useState(null);
  const [simClaimAmount, setSimClaimAmount] = useState(null);

  if (!selectedClaim) {
    return (
      <div className="p-12 text-center bg-slate-900/60 border border-slate-800 rounded-3xl max-w-xl mx-auto my-12 shadow-2xl">
        <Lightbulb className="w-12 h-12 text-amber-400 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-200">No Claim Selected for Explainability Audit</h3>
        <p className="text-xs text-slate-400 mt-1">
          Select any claim from the dropdown below or the Claims Workbench to inspect its explainable AI risk drivers, SHAP waterfall, and verifiable source citations.
        </p>
        {claims && claims.length > 0 && (
          <div className="mt-4">
            <select
              onChange={(e) => {
                const found = claims.find((c) => c.claim_id === e.target.value);
                if (found) onSelectClaim(found);
              }}
              className="bg-slate-950 text-slate-200 border border-slate-700 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-cyan-500 font-mono"
            >
              <option value="">Select a Claim to Inspect...</option>
              {claims.slice(0, 15).map((c) => (
                <option key={c.claim_id} value={c.claim_id}>
                  {c.claim_id} - {c.claim_type} (${c.claim_amount?.toLocaleString()}) - {c.risk_level} ({c.composite_risk_score}/100)
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
    );
  }

  const prof = selectedClaim.customer_profile || {};
  const waterfall = riskData?.shap_waterfall || [];
  const citations = selectedClaim.evidence_citations || [];
  const baseScore = selectedClaim.composite_risk_score;

  // Active or Simulated values
  const activePoliceReport = simPoliceReport !== null ? simPoliceReport : selectedClaim.police_report_filed;
  const activeDaysInception = simDaysSinceInception !== null ? simDaysSinceInception : selectedClaim.days_since_inception;
  const activeAmount = simClaimAmount !== null ? simClaimAmount : selectedClaim.claim_amount;

  // Dynamic Simulated Score Calculation
  let simulatedScore = baseScore;
  if (simPoliceReport !== null) {
    if (simPoliceReport && !selectedClaim.police_report_filed) simulatedScore -= 18.0;
    if (!simPoliceReport && selectedClaim.police_report_filed) simulatedScore += 18.0;
  }
  if (simDaysSinceInception !== null) {
    if (simDaysSinceInception > 60 && selectedClaim.days_since_inception <= 30) simulatedScore -= 24.0;
    if (simDaysSinceInception <= 14 && selectedClaim.days_since_inception > 30) simulatedScore += 24.0;
  }
  if (simClaimAmount !== null) {
    const amtDelta = (simClaimAmount - selectedClaim.claim_amount) / selectedClaim.claim_amount;
    simulatedScore += amtDelta * 20.0;
  }
  simulatedScore = Math.round(Math.min(100.0, Math.max(0.0, simulatedScore)) * 10) / 10;

  const simulatedLevel = simulatedScore >= 85 ? 'Critical' : simulatedScore >= 66 ? 'High' : simulatedScore >= 36 ? 'Medium' : 'Low';
  const isSimulationActive = simPoliceReport !== null || simDaysSinceInception !== null || simClaimAmount !== null;

  const resetSimulation = () => {
    setSimPoliceReport(null);
    setSimDaysSinceInception(null);
    setSimClaimAmount(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/60 border border-slate-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-amber-950/80 text-amber-300 border border-amber-700/80 flex items-center space-x-1">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>EXPLAINABLE AI (XAI) STUDIO</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>100% Grounded Traceability</span>
            </span>
          </div>
          <div className="flex items-center space-x-3 pt-1">
            <h1 className="text-xl font-black font-mono text-slate-100">
              {selectedClaim.claim_id}
            </h1>
            <span className="text-xs text-slate-400 font-mono">
              (Policy: {selectedClaim.policy_id})
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-semibold border border-slate-700">
              {selectedClaim.claim_type}
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl">
            COIL 2000 Demographic Grounding: <strong>{prof.subtype_label}</strong> (Row #{selectedClaim.coil_row_id}) • Income Group: <strong>{prof.income_category}</strong>
          </p>
        </div>

        {/* Claim Selector & Score Dial */}
        <div className="flex items-center space-x-5 shrink-0">
          {/* Quick claim switch dropdown */}
          <div className="space-y-1 text-right hidden sm:block">
            <span className="text-[10px] text-slate-400 block font-mono">SWITCH TARGET CLAIM</span>
            <select
              value={selectedClaim.claim_id}
              onChange={(e) => {
                const found = claims.find((c) => c.claim_id === e.target.value);
                if (found) {
                  onSelectClaim(found);
                  resetSimulation();
                }
              }}
              className="bg-slate-900 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-500 font-mono"
            >
              {claims.map((c) => (
                <option key={c.claim_id} value={c.claim_id}>
                  {c.claim_id} - {c.claim_type} ({c.risk_level})
                </option>
              ))}
            </select>
          </div>

          <div className="h-10 w-px bg-slate-800 hidden sm:block" />

          {/* Composite Score Pill */}
          <div className="text-right">
            <span className="text-[10px] font-mono text-slate-400 block">COMPOSITE RISK</span>
            <div className="flex items-baseline space-x-1.5 justify-end">
              <span className={`text-2xl font-black font-mono ${
                selectedClaim.risk_level === 'Critical' ? 'text-rose-400' : selectedClaim.risk_level === 'High' ? 'text-orange-400' : selectedClaim.risk_level === 'Medium' ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {selectedClaim.composite_risk_score}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ 100</span>
            </div>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              selectedClaim.risk_level === 'Critical' ? 'bg-rose-950 text-rose-300 border border-rose-800' : selectedClaim.risk_level === 'High' ? 'bg-orange-950 text-orange-300 border border-orange-800' : 'bg-slate-800 text-slate-300'
            }`}>
              {selectedClaim.risk_level.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* 4-Pillar Calibrated Weights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Pillar 1 */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">1. Loss Magnitude</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              Weight: 25%
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-slate-100">
              {Math.round(selectedClaim.risk_factor_scores?.loss_magnitude || 0)} / 100
            </span>
            <span className="text-[11px] font-mono text-amber-400">
              +{selectedClaim.amount_zscore}σ Z-Score
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-cyan-500 rounded-full" 
              style={{ width: `${Math.min(100, selectedClaim.risk_factor_scores?.loss_magnitude || 0)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Peer loss deviation relative to historical claims in {selectedClaim.claim_type}.
          </p>
        </div>

        {/* Pillar 2 */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">2. Inception Velocity</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
              Weight: 25%
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-slate-100">
              {Math.round(selectedClaim.risk_factor_scores?.velocity_timing || 0)} / 100
            </span>
            <span className={`text-[11px] font-mono font-bold ${selectedClaim.days_since_inception <= 30 ? 'text-rose-400' : 'text-slate-300'}`}>
              {selectedClaim.days_since_inception} Days Incept
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-500 rounded-full" 
              style={{ width: `${Math.min(100, selectedClaim.risk_factor_scores?.velocity_timing || 0)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Velocity between policy inception ({selectedClaim.policy_inception_date}) and loss event.
          </p>
        </div>

        {/* Pillar 3 */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">3. Documentation Integrity</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
              Weight: 25%
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-slate-100">
              {Math.round(selectedClaim.risk_factor_scores?.documentation_integrity || 0)} / 100
            </span>
            <span className={`text-[11px] font-mono ${selectedClaim.police_report_filed ? 'text-emerald-400' : 'text-rose-400'}`}>
              Police Report: {selectedClaim.police_report_filed ? 'Yes' : 'No'}
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-rose-500 rounded-full" 
              style={{ width: `${Math.min(100, selectedClaim.risk_factor_scores?.documentation_integrity || 0)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Presence of official accident blotters, independent witnesses, and prompt reporting.
          </p>
        </div>

        {/* Pillar 4 */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">4. ML Isolation Forest</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
              Weight: 25%
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-xl font-black font-mono text-slate-100">
              {Math.round(selectedClaim.isolation_forest_anomaly_score || 0)} / 100
            </span>
            <span className="text-[11px] font-mono text-purple-300">
              9-D Outlier Tree
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-purple-500 rounded-full" 
              style={{ width: `${Math.min(100, selectedClaim.isolation_forest_anomaly_score || 0)}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Unsupervised machine learning identifying anomalous joint multivariate patterns.
          </p>
        </div>
      </div>

      {/* 2-Column: SHAP Feature Attribution Waterfall + Interactive What-If Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: SHAP Waterfall Drivers (7 cols) */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
                SHAP-Style Feature Attribution Waterfall
              </h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Additive Risk Contribution</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Starting from a population baseline risk of 25.0 points, the model computes the exact quantitative contribution of each claim circumstance:
          </p>

          <div className="space-y-3 pt-1">
            {waterfall.map((item, idx) => {
              const isIncrease = item.type === 'risk_increase';
              const isDecrease = item.type === 'risk_decrease';
              const isBaseline = item.type === 'baseline';

              return (
                <div key={idx} className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-200 font-medium">
                      {item.feature}
                    </span>
                    <span className={`font-mono font-bold text-xs flex items-center space-x-0.5 ${
                      isIncrease ? 'text-rose-400' : isDecrease ? 'text-emerald-400' : 'text-slate-400'
                    }`}>
                      {isIncrease && <ArrowUpRight className="w-3.5 h-3.5 inline" />}
                      {isDecrease && <ArrowDownRight className="w-3.5 h-3.5 inline" />}
                      <span>{item.impact > 0 && !isBaseline ? `+${item.impact}` : item.impact} pts</span>
                    </span>
                  </div>

                  <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isIncrease ? 'bg-rose-500' : isDecrease ? 'bg-emerald-500' : 'bg-slate-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.abs(item.impact) * 3.5)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Interactive What-If Scenario Simulator (5 cols) */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-cyan-800/50 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Sliders className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
                What-If Risk Sensitivity Simulator
              </h3>
            </div>
            {isSimulationActive && (
              <button
                onClick={resetSimulation}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>

          <p className="text-xs text-slate-400">
            Adjust hypothetical variables in real-time to observe dynamic risk sensitivity and verify model fairness:
          </p>

          <div className="space-y-4 pt-1">
            {/* Variable 1: Police Report Filed */}
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Police Report Filed on Scene:</span>
                <span className={activePoliceReport ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {activePoliceReport ? 'Yes (Filed)' : 'No (Missing)'}
                </span>
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setSimPoliceReport(true)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border ${
                    activePoliceReport ? 'bg-emerald-950 text-emerald-300 border-emerald-600' : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  Yes (Filed)
                </button>
                <button
                  onClick={() => setSimPoliceReport(false)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold cursor-pointer border ${
                    !activePoliceReport ? 'bg-rose-950 text-rose-300 border-rose-600' : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  No (Missing)
                </button>
              </div>
            </div>

            {/* Variable 2: Inception Delta Slider */}
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Inception-to-Loss Days:</span>
                <span className="font-mono text-cyan-400 font-bold">{activeDaysInception} days</span>
              </div>
              <input
                type="range"
                min="1"
                max="180"
                value={activeDaysInception}
                onChange={(e) => setSimDaysSinceInception(parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>1d (Shock Loss)</span>
                <span>30d (Threshold)</span>
                <span>180d (Matured)</span>
              </div>
            </div>

            {/* Variable 3: Claim Amount Slider */}
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Simulated Claim Amount:</span>
                <span className="font-mono text-emerald-400 font-bold">
                  ${Math.round(activeAmount).toLocaleString()}
                </span>
              </div>
              <input
                type="range"
                min="2000"
                max="150000"
                step="2000"
                value={activeAmount}
                onChange={(e) => setSimClaimAmount(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* Simulation Result Callout */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">Simulated Result:</span>
                <span className="font-mono font-black text-base text-cyan-400">
                  {simulatedScore} / 100 [{simulatedLevel}]
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Original Baseline: {baseScore} ({selectedClaim.risk_level})</span>
                <span className={`font-mono font-bold ${simulatedScore < baseScore ? 'text-emerald-400' : simulatedScore > baseScore ? 'text-rose-400' : 'text-slate-400'}`}>
                  {simulatedScore - baseScore > 0 ? `+${(simulatedScore - baseScore).toFixed(1)}` : (simulatedScore - baseScore).toFixed(1)} pts
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Verifiable Factual Evidence & Source Grounding Cards */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <FileSearch className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Verifiable Factual Evidence Cards (Audit Grounding)
            </h3>
          </div>
          <span className="text-xs text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
            {citations.length} Grounded Citations
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Every risk indicator is anchored to raw database fields from the claim event and the COIL 2000 policyholder profile:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {citations.map((cite, idx) => {
            const isCrit = cite.severity === 'CRITICAL';
            const isHigh = cite.severity === 'HIGH';
            return (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border space-y-2 ${
                  isCrit
                    ? 'bg-rose-950/20 border-rose-800/80 hover:border-rose-600'
                    : isHigh
                    ? 'bg-orange-950/20 border-orange-800/80 hover:border-orange-600'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">{cite.indicator}</span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    isCrit ? 'bg-rose-900/80 text-rose-300' : isHigh ? 'bg-orange-900/80 text-orange-300' : 'bg-amber-900/80 text-amber-300'
                  }`}>
                    {cite.severity}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {cite.explanation}
                </p>
                <div className="flex items-center space-x-1.5 pt-1">
                  <Link2 className="w-3 h-3 text-cyan-400 shrink-0" />
                  <code className="text-[10px] font-mono text-cyan-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 truncate">
                    {cite.citation}
                  </code>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Data Lineage & COIL 2000 Demographic Traceability Matrix */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              Data Lineage &amp; Regulatory Audit Traceability Matrix
            </h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            Source Index: ticdata2000.txt [Row {selectedClaim.coil_row_id}]
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] text-slate-400 uppercase">
                <th className="py-2 px-3">Field Dimension</th>
                <th className="py-2 px-3">Raw Ground Truth Value</th>
                <th className="py-2 px-3">Transformed Feature</th>
                <th className="py-2 px-3">Risk Significance</th>
                <th className="py-2 px-3 text-right">Verification Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-cyan-300">Policy Inception Velocity</td>
                <td className="py-2.5 px-3">{selectedClaim.policy_inception_date} → {selectedClaim.incident_date}</td>
                <td className="py-2.5 px-3">{selectedClaim.days_since_inception} days delta</td>
                <td className="py-2.5 px-3 text-rose-400 font-sans">{selectedClaim.days_since_inception <= 30 ? 'High risk early inception shock loss' : 'Normal matured policy loss'}</td>
                <td className="py-2.5 px-3 text-right">
                  <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified 100%</span>
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-cyan-300">Claim Amount vs Income</td>
                <td className="py-2.5 px-3">${selectedClaim.claim_amount?.toLocaleString()} vs ~${prof.approx_income?.toLocaleString()}</td>
                <td className="py-2.5 px-3">{selectedClaim.amount_to_income_ratio}x ratio</td>
                <td className="py-2.5 px-3 text-amber-400 font-sans">{selectedClaim.amount_to_income_ratio > 1.2 ? 'Disproportionate claim-to-income' : 'Consistent with household income bracket'}</td>
                <td className="py-2.5 px-3 text-right">
                  <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified 100%</span>
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-cyan-300">Peer Amount Z-Score</td>
                <td className="py-2.5 px-3">Mean: $18,000 (Std: $14,000)</td>
                <td className="py-2.5 px-3">+{selectedClaim.amount_zscore}σ</td>
                <td className="py-2.5 px-3 text-slate-300 font-sans">{selectedClaim.amount_zscore > 1.5 ? 'Severe statistical loss outlier' : 'Normal loss distribution'}</td>
                <td className="py-2.5 px-3 text-right">
                  <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified 100%</span>
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-cyan-300">Official Police Blotter</td>
                <td className="py-2.5 px-3">police_report_filed = {String(selectedClaim.police_report_filed)}</td>
                <td className="py-2.5 px-3">{selectedClaim.police_report_filed ? 'Corroborated' : 'Uncorroborated'}</td>
                <td className="py-2.5 px-3 text-rose-400 font-sans">{!selectedClaim.police_report_filed ? 'High suspicion: major loss with no police documentation' : 'Law enforcement verified'}</td>
                <td className="py-2.5 px-3 text-right">
                  <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified 100%</span>
                  </span>
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-cyan-300">COIL Policy Portfolio</td>
                <td className="py-2.5 px-3">Car: {prof.car_policy_count}, Fire: {prof.fire_policy_count}, Boat: {prof.boat_policy_count}</td>
                <td className="py-2.5 px-3">{prof.subtype_label}</td>
                <td className="py-2.5 px-3 text-slate-300 font-sans">Coverage adequacy confirmed across lines</td>
                <td className="py-2.5 px-3 text-right">
                  <span className="inline-flex items-center space-x-1 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified 100%</span>
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
