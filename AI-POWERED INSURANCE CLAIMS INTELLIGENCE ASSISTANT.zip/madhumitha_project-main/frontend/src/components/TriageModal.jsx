import React, { useState } from 'react';
import { 
  X, 
  FileCheck2, 
  ShieldCheck, 
  AlertTriangle, 
  Send, 
  CheckCircle2, 
  HelpCircle,
  Flame,
  XCircle,
  Loader2
} from 'lucide-react';

export default function TriageModal({ claim, onClose, onSaveDecision }) {
  const [selectedAction, setSelectedAction] = useState(
    claim.risk_level === 'Critical' 
      ? 'Refer to SIU Investigation' 
      : claim.risk_level === 'Low' 
      ? 'Approve Fast-Track' 
      : 'Request Additional Evidence'
  );
  const [reviewerNotes, setReviewerNotes] = useState(
    claim.risk_level === 'Critical'
      ? 'Escalated to Special Investigation Unit due to rapid inception velocity (<15 days), missing police report, and high-confidence match to staged collision precedent.'
      : 'Claim documentation reviewed. Proceeding according to standard underwriting criteria.'
  );
  const [reviewerId, setReviewerId] = useState('REV-ADJUSTER-409');
  const [submitting, setSubmitting] = useState(false);

  if (!claim) return null;

  const actions = [
    {
      id: 'Approve Fast-Track',
      label: 'Approve Fast-Track',
      desc: 'Claim satisfies all straight-through criteria; release payment.',
      icon: CheckCircle2,
      color: 'text-emerald-400',
      border: 'border-emerald-800',
      bg: 'bg-emerald-950/40'
    },
    {
      id: 'Request Additional Evidence',
      label: 'Request Additional Evidence',
      desc: 'Require claimant to provide dashcam, repair invoices, or police blotter.',
      icon: HelpCircle,
      color: 'text-amber-400',
      border: 'border-amber-800',
      bg: 'bg-amber-950/40'
    },
    {
      id: 'Refer to SIU Investigation',
      label: 'Refer to SIU Investigation',
      desc: 'Formal escalation for forensic investigation, field interviews, and accident reconstruction.',
      icon: Flame,
      color: 'text-rose-400',
      border: 'border-rose-800',
      bg: 'bg-rose-950/40'
    },
    {
      id: 'Reject Claim',
      label: 'Reject Claim',
      desc: 'Deny coverage based on verified misrepresentation or exclusion.',
      icon: XCircle,
      color: 'text-slate-400',
      border: 'border-slate-700',
      bg: 'bg-slate-900'
    }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onSaveDecision(claim.claim_id, selectedAction, reviewerNotes, reviewerId);
      onClose();
    } catch (err) {
      alert(`Error saving adjudication: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileCheck2 className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-100 font-mono">
              Human-in-the-Loop Claim Adjudication: {claim.claim_id}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-slate-400 block text-[11px]">Active Claim Focus:</span>
              <span className="font-mono font-bold text-slate-200">{claim.claim_id} ({claim.claim_type})</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block text-[11px]">Composite Risk Score:</span>
              <span className="font-mono font-bold text-rose-400">{claim.composite_risk_score} / 100 [{claim.risk_level}]</span>
            </div>
          </div>

          {/* Action Options */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
              Select Adjudication Action:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {actions.map((act) => {
                const Icon = act.icon;
                const isSelected = selectedAction === act.id;
                return (
                  <div
                    key={act.id}
                    onClick={() => setSelectedAction(act.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? `${act.bg} ${act.border} ring-1 ring-cyan-500/50 shadow-md`
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Icon className={`w-4 h-4 ${act.color}`} />
                      <span className="font-bold text-slate-200 text-xs">{act.label}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 leading-snug">
                      {act.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reviewer Notes */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
              Adjuster Rationale & Audit Notes:
            </label>
            <textarea
              rows={3}
              value={reviewerNotes}
              onChange={(e) => setReviewerNotes(e.target.value)}
              className="w-full bg-slate-950 text-slate-200 border border-slate-700 rounded-xl p-2.5 text-xs focus:outline-none focus:border-cyan-500 font-sans"
              placeholder="Enter specific evidence notes, witness interview findings, or justification for decision..."
              required
            />
          </div>

          {/* Reviewer ID */}
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Reviewer Credentials: <strong className="text-slate-300 font-mono">{reviewerId}</strong></span>
            <span>Audit Signed: {new Date().toISOString().slice(0, 10)}</span>
          </div>

          {/* Submit Buttons */}
          <div className="pt-2 flex items-center justify-end space-x-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-semibold text-xs flex items-center space-x-1.5 cursor-pointer shadow-md disabled:opacity-50"
            >
              {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileCheck2 className="w-3.5 h-3.5" />}
              <span>Commit Adjudication</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
