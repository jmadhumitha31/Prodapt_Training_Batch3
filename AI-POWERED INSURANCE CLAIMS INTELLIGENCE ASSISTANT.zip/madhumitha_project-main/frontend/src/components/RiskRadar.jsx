import React from 'react';
import { 
  Radar, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  ShieldAlert, 
  ShieldCheck, 
  Layers,
  Database,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

export default function RiskRadar({ selectedClaim, riskData }) {
  if (!selectedClaim || !riskData) {
    return (
      <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl">
        <Radar className="w-10 h-10 text-slate-600 mx-auto mb-2" />
        <h3 className="text-sm font-semibold text-slate-300">No Claim Selected for Risk Diagnostics</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
          Select a claim to view multi-factor risk radar dimensions and explainable AI feature impact breakdown.
        </p>
      </div>
    );
  }

  const dimensions = riskData.radar_dimensions || [];
  const waterfall = riskData.shap_waterfall || [];
  const score = riskData.composite_risk_score || selectedClaim.composite_risk_score;
  const level = riskData.risk_level || selectedClaim.risk_level;

  // Compute SVG Polygon Points for 5-axis Radar
  // Center is at (150, 150), Radius is 100
  const centerX = 150;
  const centerY = 150;
  const maxRadius = 90;

  const totalAxes = dimensions.length || 5;
  const angleSlice = (Math.PI * 2) / totalAxes;

  // Grid background circles (25%, 50%, 75%, 100%)
  const gridRings = [0.25, 0.50, 0.75, 1.0];

  // Data polygon points
  const points = dimensions.map((d, i) => {
    const angle = i * angleSlice - Math.PI / 2;
    const valueRatio = Math.min(1.0, Math.max(0.05, (d.score || 0) / (d.max || 100)));
    const r = maxRadius * valueRatio;
    const x = centerX + r * Math.cos(angle);
    const y = centerY + r * Math.sin(angle);
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="space-y-6">
      {/* Top Risk Header & Composite Dial */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Score Meter Card */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-center space-x-5">
          <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
            {/* Circular SVG Gauge */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="10"
                className="text-slate-800"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                stroke="currentColor"
                strokeWidth="10"
                className={score >= 85 ? 'text-rose-500' : score >= 65 ? 'text-orange-500' : score >= 35 ? 'text-amber-400' : 'text-emerald-500'}
                strokeDasharray="251.2"
                strokeDashoffset={251.2 - (251.2 * score) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-black font-mono text-slate-100 tracking-tight">
                {score}
              </span>
              <span className="text-[10px] text-slate-400 font-semibold uppercase">
                / 100
              </span>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-xs font-mono text-slate-400">COMPOSITE RISK RATING</span>
            <div className="flex items-center space-x-2">
              <span className={`text-base font-black uppercase tracking-wider ${
                level === 'Critical' ? 'text-rose-400' : level === 'High' ? 'text-orange-400' : level === 'Medium' ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {level} Risk
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Action: <strong className="text-slate-200">{riskData.priority_action}</strong>
            </p>
          </div>
        </div>

        {/* Explainability Summary Card */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl md:col-span-2 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <span>Multi-Factor Risk Assessment Summary</span>
            </span>
            <span className="text-[10px] font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
              Target: {selectedClaim.claim_id}
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The composite risk score combines four calibrated risk pillars: <strong>Loss Outlier Magnitude (25%)</strong>, <strong>Inception & Velocity Timing (25%)</strong>, <strong>Documentation & Behavioral Integrity (25%)</strong>, and <strong>Multivariate ML Anomaly Detection (25%)</strong>.
          </p>
          <div className="flex flex-wrap gap-2 pt-1 text-[11px]">
            <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
              Amount Z-Score: <strong className="text-slate-200">+{selectedClaim.amount_zscore}σ</strong>
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
              Inception Delta: <strong className="text-slate-200">{selectedClaim.days_since_inception} days</strong>
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
              ML Outlier Score: <strong className="text-slate-200">{selectedClaim.isolation_forest_anomaly_score}/100</strong>
            </span>
          </div>
        </div>
      </div>

      {/* 2-Column: Radar Chart + SHAP Waterfall */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Radar Chart */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-1.5 uppercase tracking-wider">
              <Radar className="w-4 h-4 text-cyan-400" />
              <span>5-Axis Risk Topology Radar</span>
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Normalized 0 - 100</span>
          </div>

          <div className="flex items-center justify-center p-2">
            <svg className="w-72 h-72 overflow-visible" viewBox="0 0 300 300">
              {/* Background rings */}
              {gridRings.map((ring, idx) => (
                <circle
                  key={idx}
                  cx={centerX}
                  cy={centerY}
                  r={maxRadius * ring}
                  fill="transparent"
                  stroke="#334155"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                />
              ))}

              {/* Axis lines */}
              {dimensions.map((d, i) => {
                const angle = i * angleSlice - Math.PI / 2;
                const x2 = centerX + maxRadius * Math.cos(angle);
                const y2 = centerY + maxRadius * Math.sin(angle);
                return (
                  <line
                    key={i}
                    x1={centerX}
                    y1={centerY}
                    x2={x2}
                    y2={y2}
                    stroke="#475569"
                    strokeWidth="1"
                  />
                );
              })}

              {/* Data Polygon */}
              <polygon
                points={points}
                fill={score >= 70 ? 'rgba(244, 63, 94, 0.25)' : 'rgba(56, 189, 248, 0.25)'}
                stroke={score >= 70 ? '#f43f5e' : '#38bdf8'}
                strokeWidth="2.5"
              />

              {/* Axis Labels & Values */}
              {dimensions.map((d, i) => {
                const angle = i * angleSlice - Math.PI / 2;
                const labelRadius = maxRadius + 28;
                const lx = centerX + labelRadius * Math.cos(angle);
                const ly = centerY + labelRadius * Math.sin(angle);
                return (
                  <text
                    key={i}
                    x={lx}
                    y={ly}
                    textAnchor="middle"
                    dominantBaseline="central"
                    className="text-[10px] font-mono fill-slate-300 font-medium"
                  >
                    {d.dimension} ({Math.round(d.score)})
                  </text>
                );
              })}
            </svg>
          </div>
        </div>

        {/* SHAP-style Feature Impact Waterfall */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-100 flex items-center space-x-1.5 uppercase tracking-wider">
              <Layers className="w-4 h-4 text-indigo-400" />
              <span>Explainable AI Risk Feature Waterfall (SHAP-style)</span>
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">Risk Contribution</span>
          </div>

          <div className="space-y-3">
            {waterfall.map((item, idx) => {
              const isIncrease = item.type === 'risk_increase';
              const isDecrease = item.type === 'risk_decrease';
              const isBaseline = item.type === 'baseline';

              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium truncate max-w-[280px]">
                      {item.feature}
                    </span>
                    <span className={`font-mono font-bold text-xs flex items-center space-x-0.5 ${
                      isIncrease ? 'text-rose-400' : isDecrease ? 'text-emerald-400' : 'text-slate-400'
                    }`}>
                      {isIncrease && <ArrowUpRight className="w-3.5 h-3.5 inline" />}
                      {isDecrease && <ArrowDownRight className="w-3.5 h-3.5 inline" />}
                      <span>{item.impact > 0 && !isBaseline ? `+${item.impact}` : item.impact} pts</span>
                    </span>
                  </div>

                  <div className="h-2 w-full bg-slate-800/80 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isIncrease ? 'bg-rose-500' : isDecrease ? 'bg-emerald-500' : 'bg-slate-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.abs(item.impact) * 3)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
