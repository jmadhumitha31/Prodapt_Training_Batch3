import React from 'react';
import { 
  Search, 
  ChevronRight, 
  RefreshCw,
  Sparkles,
  SlidersHorizontal,
  Layers
} from 'lucide-react';

export default function ClaimsTable({ 
  claims, 
  selectedClaim, 
  onSelectClaim, 
  searchQuery, 
  setSearchQuery, 
  riskFilter, 
  setRiskFilter,
  typeFilter,
  setTypeFilter,
  onSearch,
  onResetFilters
}) {
  const getRiskBadge = (level, score) => {
    switch (level) {
      case 'Critical':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/25">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            <span className="font-mono">{score}</span>
            <span className="text-[10px] text-rose-400/80 font-normal">Crit</span>
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-orange-500/10 text-orange-400 border border-orange-500/25">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
            <span className="font-mono">{score}</span>
            <span className="text-[10px] text-orange-400/80 font-normal">High</span>
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/25">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <span className="font-mono">{score}</span>
            <span className="text-[10px] text-amber-400/80 font-normal">Med</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span className="font-mono">{score}</span>
            <span className="text-[10px] text-emerald-400/80 font-normal">Low</span>
          </span>
        );
    }
  };

  const criticalCount = claims.filter(c => c.risk_level === 'Critical').length;

  return (
    <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800/80 rounded-2xl shadow-sm flex flex-col h-full min-h-0 overflow-hidden">
      {/* Header Bar */}
      <div className="p-3.5 border-b border-slate-800/80 bg-slate-950/40 shrink-0 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-cyan-400/80" />
            <h2 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Claims Queue
            </h2>
          </div>
          <div className="flex items-center space-x-2 text-[11px]">
            <span className="text-slate-400">
              <strong className="text-slate-200 font-mono font-medium">{claims.length}</strong> loaded
            </span>
            {criticalCount > 0 && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-rose-500/10 text-rose-400 border border-rose-500/20">
                {criticalCount} critical
              </span>
            )}
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex gap-1.5">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && onSearch()}
              placeholder="Search claims, IDs, or semantic symptoms..."
              className="w-full bg-slate-900/90 text-slate-200 placeholder-slate-500 pl-8 pr-16 py-1.5 rounded-lg border border-slate-700/60 text-xs focus:outline-none focus:border-cyan-500/80 focus:ring-1 focus:ring-cyan-500/40 transition-all"
            />
            <button
              onClick={onSearch}
              className="absolute right-1 top-1/2 -translate-y-1/2 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium flex items-center space-x-1 cursor-pointer transition-all border border-slate-700/60"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Query</span>
            </button>
          </div>

          {(searchQuery || riskFilter || typeFilter) && (
            <button
              onClick={onResetFilters}
              title="Reset all filters"
              className="px-2 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-lg text-xs flex items-center justify-center cursor-pointer transition-all border border-slate-700/60"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Filter Row: Risk Pills & Type Selector */}
        <div className="flex items-center justify-between gap-1.5 pt-0.5">
          <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar">
            {['All', 'Critical', 'High', 'Medium', 'Low'].map((level) => {
              const isSelected = (riskFilter === '' && level === 'All') || riskFilter === level;
              return (
                <button
                  key={level}
                  onClick={() => setRiskFilter(level === 'All' ? '' : level)}
                  className={`px-2 py-0.5 rounded-md text-[11px] transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'bg-slate-800 text-slate-100 font-semibold border border-slate-700 shadow-sm'
                      : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  {level}
                </button>
              );
            })}
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-900 text-slate-300 border border-slate-700/60 rounded-md px-2 py-0.5 text-[11px] focus:outline-none focus:border-cyan-500/70 font-normal cursor-pointer"
          >
            <option value="">All Lines</option>
            <option value="Auto Collision">Auto</option>
            <option value="Property Fire">Property</option>
            <option value="Bodily Injury">Injury</option>
            <option value="Comprehensive">Comprehensive</option>
            <option value="Marine/Boat">Marine</option>
          </select>
        </div>
      </div>

      {/* Scrollable Claims Queue List */}
      <div className="flex-1 min-h-0 overflow-y-auto p-2.5 space-y-1.5">
        {claims.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs space-y-2">
            <SlidersHorizontal className="w-6 h-6 text-slate-600 mx-auto" />
            <p className="font-medium text-slate-400">No matching claims found</p>
            <p className="text-[11px]">Adjust your search query or reset active filters.</p>
            <button
              onClick={onResetFilters}
              className="mt-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-md text-xs cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          claims.map((claim) => {
            const isSelected = selectedClaim?.claim_id === claim.claim_id;
            const isEarlyLoss = claim.days_since_inception <= 30;

            return (
              <div
                key={claim.claim_id}
                onClick={() => onSelectClaim(claim)}
                className={`p-2.5 rounded-xl transition-all duration-150 cursor-pointer border relative ${
                  isSelected
                    ? 'bg-slate-800/90 border-slate-700 shadow-sm ring-1 ring-cyan-500/20'
                    : 'bg-slate-950/30 border-slate-800/60 hover:bg-slate-800/40 hover:border-slate-700/60'
                }`}
              >
                {/* Active Indicator Strip */}
                {isSelected && (
                  <div className="absolute left-0 top-2.5 bottom-2.5 w-1 bg-cyan-400 rounded-r" />
                )}

                {/* Card Header: ID, Amount, Risk Score */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs font-semibold text-slate-200">
                      {claim.claim_id}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      ${claim.claim_amount.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                    </span>
                  </div>
                  <div className="shrink-0">
                    {getRiskBadge(claim.risk_level, claim.composite_risk_score)}
                  </div>
                </div>

                {/* Card Metadata Row: Type, Inception Delta, Status */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1.5">
                  <div className="flex items-center space-x-1.5 truncate">
                    <span>{claim.claim_type}</span>
                    <span className="text-slate-600">•</span>
                    <span className={isEarlyLoss ? 'text-rose-400/90 font-medium' : 'text-slate-500'}>
                      {claim.days_since_inception}d incept
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-slate-500">{claim.claim_status}</span>
                  </div>

                  <ChevronRight
                    className={`w-3.5 h-3.5 shrink-0 transition-transform ${
                      isSelected
                        ? 'text-cyan-400 translate-x-0.5'
                        : 'text-slate-600'
                    }`}
                  />
                </div>

                {/* Narrative Excerpt */}
                <p className="text-[11px] text-slate-400/80 line-clamp-1 mt-1 font-sans">
                  {claim.claim_description}
                </p>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Status */}
      <div className="p-2 border-t border-slate-800/80 bg-slate-950/50 shrink-0 flex items-center justify-between text-[11px] text-slate-500 px-3 font-mono">
        <span>{claims.length} claims</span>
        <span className="text-[10px]">Scroll for more ↓</span>
      </div>
    </div>
  );
}
