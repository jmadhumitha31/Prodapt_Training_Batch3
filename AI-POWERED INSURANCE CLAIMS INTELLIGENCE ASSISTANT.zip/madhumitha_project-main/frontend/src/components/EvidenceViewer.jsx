import React from 'react';
import { 
  FileSearch,
  Database,
  Link2
} from 'lucide-react';

export default function EvidenceViewer({ selectedClaim }) {
  if (!selectedClaim) return null;

  const citations = selectedClaim.evidence_citations || [];

  return (
    <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 shadow-sm space-y-3.5">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
        <div className="flex items-center space-x-2">
          <FileSearch className="w-4 h-4 text-cyan-400/80" />
          <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            Supporting Evidence & Factual Grounding (Traceable Audit Trail)
          </h3>
        </div>
        <div className="flex items-center space-x-1.5 text-[11px] text-slate-400 bg-slate-800/80 px-2.5 py-0.5 rounded-md border border-slate-700/60 font-mono">
          <Database className="w-3 h-3 text-emerald-400" />
          <span>COIL 2000 Grounded (Row #{selectedClaim.coil_row_id})</span>
        </div>
      </div>

      <p className="text-xs text-slate-400">
        Every risk indicator is grounded in verified factual attributes from the insurance knowledge base and COIL 2000 demographic records, eliminating unexplained black-box scores.
      </p>

      {/* Citations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {citations.map((cite, idx) => {
          const isCritical = cite.severity === 'CRITICAL';
          const isHigh = cite.severity === 'HIGH';
          return (
            <div
              key={idx}
              className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/70 space-y-1.5 hover:border-slate-700/80 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-200">
                  {cite.indicator}
                </span>
                <span className={`text-[10px] font-mono font-medium px-1.5 py-0.2 rounded ${
                  isCritical 
                    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    : isHigh 
                    ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}>
                  {cite.severity}
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                {cite.explanation}
              </p>

              {/* Exact Traceability Citation Tag */}
              <div className="flex items-center space-x-1.5 pt-0.5">
                <Link2 className="w-3 h-3 text-cyan-400/70 shrink-0" />
                <code className="text-[10px] font-mono text-cyan-300/90 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800/80 truncate">
                  {cite.citation}
                </code>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
