import React, { useState } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  HelpCircle, 
  Layers, 
  FileText, 
  ExternalLink,
  Loader2,
  CheckCircle2,
  Clock
} from 'lucide-react';

export default function AICopilot({ selectedClaim, onSelectClaim }) {
  const [messages, setMessages] = useState([
    {
      sender: 'copilot',
      text: 'Hello, I am your AI Claims Intelligence Assistant powered by NVIDIA NIM. I analyze claims patterns, anomalous losses, historical precedent similarities, and explainable risk factors.\n\nYou can ask any question about the claims portfolio or click one of the recommended investigative queries below.',
      timestamp: '12:00:00'
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);

  const samplePrompts = [
    "Which claims require further investigation?",
    "Identify claims with unusual claim amounts or patterns.",
    "Which claims have characteristics similar to previously investigated claims?",
    "What information supports the risk assessment for this claim?",
    "Summarize the key details of this claim for an insurance reviewer.",
    "Which claims should be prioritized for manual review?"
  ];

  const handleSend = async (queryText) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString()
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const resp = await fetch('/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSend,
          selected_claim_id: selectedClaim?.claim_id || null
        })
      });
      const data = await resp.json();

      const botMsg = {
        sender: 'copilot',
        text: data.answer,
        relevantClaims: data.relevant_claims || [],
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'copilot',
          text: `Error processing query: ${err.message}. Please verify the backend microservice is active.`,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl flex flex-col overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-md shadow-cyan-500/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <span>Natural-Language Claims Intelligence Copilot</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                NVIDIA Llama-3.2-11B
              </span>
            </h2>
            <p className="text-[11px] text-slate-400">
              {selectedClaim ? `Context Focus: ${selectedClaim.claim_id} (${selectedClaim.claim_type})` : 'Context Focus: Entire Claims Portfolio'}
            </p>
          </div>
        </div>
      </div>

      {/* Suggested Prompt Chips */}
      <div className="p-3 bg-slate-950/40 border-b border-slate-800 flex items-center space-x-2 overflow-x-auto no-scrollbar">
        <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider shrink-0 flex items-center">
          <HelpCircle className="w-3 h-3 mr-1 text-slate-500" /> Prompts:
        </span>
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p)}
            className="text-[11px] px-2.5 py-1 whitespace-nowrap rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 transition-all cursor-pointer"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, idx) => {
          const isUser = m.sender === 'user';
          return (
            <div
              key={idx}
              className={`flex items-start space-x-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4 text-cyan-400" />
                </div>
              )}

              <div className={`max-w-2xl rounded-2xl p-4 text-xs space-y-2 leading-relaxed ${
                isUser 
                  ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-none' 
                  : 'bg-slate-950/80 border border-slate-800/80 text-slate-200 rounded-tl-none shadow-md'
              }`}>
                <div className="whitespace-pre-line font-sans">
                  {m.text}
                </div>

                {/* Clickable Claim Cards if returned */}
                {m.relevantClaims && m.relevantClaims.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                      Directly Referenced Claims:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {m.relevantClaims.map((c) => (
                        <div
                          key={c.claim_id}
                          onClick={() => onSelectClaim(c)}
                          className="p-2 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/60 transition-all cursor-pointer flex items-center justify-between"
                        >
                          <div>
                            <div className="font-mono font-bold text-cyan-300 text-[11px]">
                              {c.claim_id}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {c.claim_type} • ${c.claim_amount?.toLocaleString()}
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            c.risk_level === 'Critical' ? 'bg-rose-950 text-rose-300' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {c.risk_level}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="text-[10px] text-slate-400 text-right">
                  {m.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center space-x-2 text-xs text-cyan-400 p-2 animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Analyzing claims repository and synthesizing evidence...</span>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center space-x-2">
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask any question about claims, anomalies, or risk patterns..."
          className="flex-1 bg-slate-900 text-slate-200 placeholder-slate-500 px-4 py-2.5 rounded-xl border border-slate-700/80 text-xs focus:outline-none focus:border-cyan-500"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading || !inputQuery.trim()}
          className="p-2.5 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl cursor-pointer disabled:opacity-40 transition-all"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
