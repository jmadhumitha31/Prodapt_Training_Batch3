import React, { useState } from 'react';
import { 
  UserCheck, 
  Calendar, 
  DollarSign, 
  FileText, 
  ExternalLink,
  Bot,
  GitFork,
  FileCheck,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ShieldAlert,
  Lightbulb,
  FileSearch,
  Link2,
  CloudRain,
  History
} from 'lucide-react';

export default function ClaimDossier({ 
  claim, 
  onRunInvestigation, 
  onFindSimilar, 
  onViewRiskRadar,
  onViewExplainability,
  onOpenReport,
  onOpenTriageModal
}) {
  const [dossierTab, setDossierTab] = useState('overview'); // 'overview' | 'evidence' | 'demographics'

  if (!claim) {
    return (
      <div className="h-full bg-slate-900/60 backdrop-blur-md border border-slate-800/80 rounded-2xl flex items-center justify-center p-8 text-center">
        <div className="space-y-2 max-w-sm">
          <FileText className="w-8 h-8 text-slate-600 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-300">No Claim Selected</h3>
          <p className="text-xs text-slate-500">
            Select a claim from the queue to inspect its 360° intelligence dossier.
          </p>
        </div>
      </div>
    );
  }

  const prof = claim.customer_profile || {};
  const citations = claim.evidence_citations || [];

  return (
    <div className="h-full min-h-0 bg-slate-900/60 backdrop-blur-md border border-slate-800/80 rounded-2xl shadow-sm flex flex-col overflow-hidden">
      {/* Top Banner & Structured Action Bar */}
      <div className="p-3.5 border-b border-slate-800/80 bg-slate-950/40 shrink-0 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-bold font-mono text-slate-100">
              {claim.claim_id}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              ({claim.policy_id})
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700/60">
              {claim.claim_type}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 pt-0.5">
            COIL Grounding: <strong className="text-slate-300 font-medium">Row #{claim.coil_row_id}</strong> ({prof.subtype_label})
          </p>
        </div>

        {/* Clear Action Hierarchy: 1 Primary CTA + Unified Secondary Actions */}
        <div className="flex items-center space-x-1.5">
          <button
            onClick={() => onRunInvestigation(claim)}
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-medium flex items-center space-x-1.5 cursor-pointer transition-all shadow-sm"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Investigate (5 Agents)</span>
          </button>

          <button
            onClick={() => onFindSimilar(claim.claim_id)}
            className="px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 rounded-lg text-xs font-medium flex items-center space-x-1 cursor-pointer transition-all border border-slate-700/60"
          >
            <GitFork className="w-3.5 h-3.5 text-slate-400" />
            <span>Precedents</span>
          </button>

          {onViewExplainability && (
            <button
              onClick={onViewExplainability}
              className="px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 rounded-lg text-xs font-medium flex items-center space-x-1 cursor-pointer transition-all border border-slate-700/60"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400/80" />
              <span>XAI</span>
            </button>
          )}

          <button
            onClick={() => onOpenTriageModal(claim)}
            className="px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 rounded-lg text-xs font-medium flex items-center space-x-1 cursor-pointer transition-all border border-slate-700/60"
          >
            <FileCheck className="w-3.5 h-3.5 text-emerald-400/80" />
            <span>Adjudicate</span>
          </button>

          <button
            onClick={() => onOpenReport(claim.claim_id)}
            className="p-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-400 hover:text-slate-200 rounded-lg text-xs cursor-pointer border border-slate-700/60"
            title="Export Dossier Report"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Clean Sub-Nav Tabs */}
      <div className="flex items-center space-x-1 px-3 py-1.5 border-b border-slate-800/70 bg-slate-950/20 shrink-0">
        <button
          onClick={() => setDossierTab('overview')}
          className={`px-3 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
            dossierTab === 'overview'
              ? 'bg-slate-800 text-slate-100 border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/40'
          }`}
        >
          360° Overview
        </button>

        <button
          onClick={() => setDossierTab('evidence')}
          className={`px-3 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
            dossierTab === 'evidence'
              ? 'bg-slate-800 text-slate-100 border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/40'
          }`}
        >
          Audit Citations ({citations.length})
        </button>

        <button
          onClick={() => setDossierTab('demographics')}
          className={`px-3 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
            dossierTab === 'demographics'
              ? 'bg-slate-800 text-slate-100 border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800/40'
          }`}
        >
          COIL Demographics
        </button>
      </div>

      {/* Main Content Pane */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: OVERVIEW */}
        {dossierTab === 'overview' && (
          <div className="space-y-3.5">
            {/* Refined Risk Classification Banner */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/80 flex items-start space-x-3">
              <div className="mt-0.5">
                <span className={`w-2.5 h-2.5 rounded-full inline-block ${
                  claim.risk_level === 'Critical' ? 'bg-rose-500' :
                  claim.risk_level === 'High' ? 'bg-orange-500' :
                  claim.risk_level === 'Medium' ? 'bg-amber-500' : 'bg-emerald-500'
                }`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-xs text-slate-200">
                      Risk Rating: {claim.risk_level} ({claim.composite_risk_score}/100)
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono px-1.5 py-0.2 rounded bg-slate-800/80 border border-slate-700/60">
                      {claim.priority_action}
                    </span>
                  </div>
                  {onViewExplainability && (
                    <button
                      onClick={onViewExplainability}
                      className="text-[11px] text-slate-400 hover:text-cyan-400 transition-colors flex items-center space-x-1 cursor-pointer"
                    >
                      <span>Explain Breakdown →</span>
                    </button>
                  )}
                </div>
                <p className="text-xs mt-1 text-slate-400 leading-relaxed font-sans">
                  {claim.risk_level === 'Critical' || claim.risk_level === 'High'
                    ? `Rapid inception-to-loss velocity (${claim.days_since_inception} days) with loss amount ${claim.amount_to_income_ratio}x annual income and missing corroborating police documentation.`
                    : 'Standard risk profile within regular underwriting loss distributions and verified documentation standards.'}
                </p>
              </div>
            </div>

            {/* 2-Column Grid: Timeline & Financials */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Timeline */}
              <div className="p-3.5 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-medium text-slate-300 border-b border-slate-800/60 pb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timeline & Velocity</span>
                </div>
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Policy Inception:</span>
                    <span className="text-slate-300">{claim.policy_inception_date}</span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Incident Date:</span>
                    <span className="text-slate-300">{claim.incident_date}</span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Date Reported:</span>
                    <span className="text-slate-300">{claim.report_date}</span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Inception Delta:</span>
                    <span className={claim.days_since_inception <= 30 ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
                      {claim.days_since_inception} days {claim.days_since_inception <= 30 && '(Early Loss)'}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span className="text-slate-400 font-sans">Reporting Latency:</span>
                    <span className="text-slate-300">{claim.days_to_report} days</span>
                  </div>
                </div>
              </div>

              {/* Financials */}
              <div className="p-3.5 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-medium text-slate-300 border-b border-slate-800/60 pb-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                  <span>Financials & Coverage</span>
                </div>
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Claimed Amount:</span>
                    <span className="text-slate-100 font-semibold">
                      ${claim.claim_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Estimated Loss:</span>
                    <span className="text-slate-300">
                      ${claim.estimated_loss.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Policy Limit / Ded:</span>
                    <span className="text-slate-300">
                      ${claim.policy_limit.toLocaleString()} / ${claim.deductible}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-400 font-sans">Peer Z-Score:</span>
                    <span className="text-slate-300 font-semibold">+{claim.amount_zscore}σ</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span className="text-slate-400 font-sans">Amount-to-Income:</span>
                    <span className="text-slate-300">{claim.amount_to_income_ratio}x</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Narrative */}
            <div className="p-3.5 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-medium text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <FileText className="w-3.5 h-3.5 text-slate-400" />
                  <span>Incident Statement & Notes</span>
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {claim.incident_city}, {claim.incident_state}
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed font-sans pt-0.5">
                "{claim.claim_description}"
              </p>
            </div>

            {/* Corroborating Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-950/30 border border-slate-800/60 flex items-center space-x-2 text-slate-300">
                {claim.police_report_filed ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                )}
                <span className="text-[11px]">Police: {claim.police_report_filed ? 'Filed' : 'Missing'}</span>
              </div>

              <div className="p-2 rounded-lg bg-slate-950/30 border border-slate-800/60 flex items-center space-x-2 text-slate-300">
                {claim.witness_present ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <HelpCircle className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                )}
                <span className="text-[11px]">Witness: {claim.witness_present ? 'Confirmed' : 'None'}</span>
              </div>

              <div className="p-2 rounded-lg bg-slate-950/30 border border-slate-800/60 flex items-center space-x-2 text-slate-300">
                <History className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="text-[11px]">Priors: {claim.prior_claims_count}</span>
              </div>

              <div className="p-2 rounded-lg bg-slate-950/30 border border-slate-800/60 flex items-center space-x-2 text-slate-300">
                <CloudRain className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="text-[11px] truncate">Weather: {claim.weather_condition || 'Clear'}</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EVIDENCE TRAIL */}
        {dossierTab === 'evidence' && (
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/70 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                  Verifiable Audit Citations ({citations.length} Grounded Points)
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Raw telemetry indicators mapped to benchmark truth.
                </p>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono text-emerald-400/90 bg-emerald-500/10 border border-emerald-500/20">
                100% Traceable
              </span>
            </div>

            <div className="space-y-2">
              {citations.map((cite, idx) => {
                const isCrit = cite.severity === 'CRITICAL';
                const isHigh = cite.severity === 'HIGH';

                return (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-200">{cite.indicator}</span>
                      <span className={`text-[10px] font-mono font-medium px-1.5 py-0.2 rounded ${
                        isCrit ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                        isHigh ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {cite.severity}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      {cite.explanation}
                    </p>
                    <div className="flex items-center space-x-1.5 pt-0.5">
                      <Link2 className="w-3 h-3 text-cyan-400/70 shrink-0" />
                      <code className="text-[10px] font-mono text-cyan-300/90 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                        {cite.citation}
                      </code>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: DEMOGRAPHICS */}
        {dossierTab === 'demographics' && (
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/70 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                  COIL 2000 Demographic Profile
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Benchmark record linked to UCI repository row #{claim.coil_row_id}.
                </p>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono text-slate-300 bg-slate-800 border border-slate-700">
                Row #{claim.coil_row_id}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Customer Subtype</span>
                <span className="text-slate-200 font-semibold block">{prof.subtype_label}</span>
                <span className="text-[10px] text-slate-500">Demographic cluster classification</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Household Income</span>
                <span className="text-slate-200 font-semibold block">{prof.income_category}</span>
                <span className="text-[10px] text-slate-500">Estimated approx: ~${prof.approx_income?.toLocaleString()}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Age & Household</span>
                <span className="text-slate-200 font-semibold block">{prof.age_category}</span>
                <span className="text-[10px] text-slate-500">{prof.household_size} Household members</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/30 border border-slate-800/70 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Policy Portfolio Holdings</span>
                <span className="text-slate-200 font-semibold block">
                  {prof.car_policy_count} Auto • {prof.fire_policy_count} Fire • {prof.boat_policy_count} Boat
                </span>
                <span className="text-[10px] text-slate-500">Cross-line insurance coverage footprint</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
