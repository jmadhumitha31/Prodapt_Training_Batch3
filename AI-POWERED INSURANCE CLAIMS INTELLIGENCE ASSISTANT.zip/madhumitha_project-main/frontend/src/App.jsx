import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import KPICards from './components/KPICards';
import ClaimsTable from './components/ClaimsTable';
import ClaimDossier from './components/ClaimDossier';
import SimilarityExplorer from './components/SimilarityExplorer';
import RiskRadar from './components/RiskRadar';
import EvidenceViewer from './components/EvidenceViewer';
import MultiAgentConsole from './components/MultiAgentConsole';
import AICopilot from './components/AICopilot';
import EvaluationDashboard from './components/EvaluationDashboard';
import ReportModal from './components/ReportModal';
import TriageModal from './components/TriageModal';
import ExplainabilityScreen from './components/ExplainabilityScreen';

export default function App() {
  const [activeTab, setActiveTab] = useState('workbench');
  const [stats, setStats] = useState(null);
  const [claims, setClaims] = useState([]);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [similarityData, setSimilarityData] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [investigationResult, setInvestigationResult] = useState(null);
  const [evaluationData, setEvaluationData] = useState(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  // Loading States
  const [loadingClaims, setLoadingClaims] = useState(false);
  const [loadingSimilarity, setLoadingSimilarity] = useState(false);
  const [loadingInvestigation, setLoadingInvestigation] = useState(false);
  const [loadingEvaluation, setLoadingEvaluation] = useState(false);

  // Modals
  const [reportModalContent, setReportModalContent] = useState(null);
  const [reportModalClaimId, setReportModalClaimId] = useState(null);
  const [triageModalClaim, setTriageModalClaim] = useState(null);

  // Initial Data Fetch
  useEffect(() => {
    fetchStats();
    fetchClaims();
    fetchEvaluation();
  }, []);

  // Fetch aggregate stats
  const fetchStats = async () => {
    try {
      const resp = await fetch('/api/stats');
      if (resp.ok) {
        const data = await resp.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Error fetching stats:', e);
    }
  };

  // Fetch claims with current filters
  const fetchClaims = async (customSearch = null) => {
    setLoadingClaims(true);
    try {
      const params = new URLSearchParams();
      const q = customSearch !== null ? customSearch : searchQuery;
      if (q) params.append('search', q);
      if (riskFilter) params.append('risk_level', riskFilter);
      if (typeFilter) params.append('claim_type', typeFilter);

      const resp = await fetch(`/api/claims?${params.toString()}`);
      if (resp.ok) {
        const data = await resp.json();
        setClaims(data.claims || []);
        // Auto-select first claim if none selected
        if (!selectedClaim && data.claims && data.claims.length > 0) {
          handleSelectClaim(data.claims[0]);
        }
      }
    } catch (e) {
      console.error('Error fetching claims:', e);
    } finally {
      setLoadingClaims(false);
    }
  };

  // Fetch Evaluation Benchmarks
  const fetchEvaluation = async () => {
    setLoadingEvaluation(true);
    try {
      const resp = await fetch('/api/evaluation');
      if (resp.ok) {
        const data = await resp.json();
        setEvaluationData(data);
      }
    } catch (e) {
      console.error('Error fetching evaluation:', e);
    } finally {
      setLoadingEvaluation(false);
    }
  };

  // Handle selecting a claim
  const handleSelectClaim = async (claim) => {
    setSelectedClaim(claim);
    // Load similarity and risk diagnostics in parallel
    fetchSimilarity(claim.claim_id);
    fetchRiskDiagnostics(claim.claim_id);
  };

  // Fetch similar claims
  const fetchSimilarity = async (claimId) => {
    setLoadingSimilarity(true);
    try {
      const resp = await fetch(`/api/claims/${claimId}/similar?top_k=4`);
      if (resp.ok) {
        const data = await resp.json();
        setSimilarityData(data);
      }
    } catch (e) {
      console.error('Error fetching similarity:', e);
    } finally {
      setLoadingSimilarity(false);
    }
  };

  // Fetch risk diagnostics
  const fetchRiskDiagnostics = async (claimId) => {
    try {
      const resp = await fetch(`/api/claims/${claimId}/risk`);
      if (resp.ok) {
        const data = await resp.json();
        setRiskData(data);
      }
    } catch (e) {
      console.error('Error fetching risk diagnostics:', e);
    }
  };

  // Run Multi-Agent Investigation
  const handleRunInvestigation = async (claim) => {
    setLoadingInvestigation(true);
    setActiveTab('multi_agent');
    try {
      const resp = await fetch(`/api/claims/${claim.claim_id}/investigate`, {
        method: 'POST'
      });
      if (resp.ok) {
        const data = await resp.json();
        setInvestigationResult(data);
      }
    } catch (e) {
      console.error('Error running investigation:', e);
    } finally {
      setLoadingInvestigation(false);
    }
  };

  // Open Report Modal
  const handleOpenReport = async (claimId) => {
    try {
      const resp = await fetch(`/api/reports/${claimId}`);
      if (resp.ok) {
        const data = await resp.json();
        setReportModalContent(data.report_content);
        setReportModalClaimId(claimId);
      }
    } catch (e) {
      console.error('Error fetching report:', e);
    }
  };

  // Submit Triage Adjudication
  const handleSaveTriage = async (claimId, action, notes, reviewerId) => {
    const resp = await fetch(`/api/claims/${claimId}/triage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        reviewer_notes: notes,
        reviewer_id: reviewerId
      })
    });
    if (!resp.ok) throw new Error('Failed to save triage action');

    const result = await resp.json();
    // Update local claims state
    setClaims((prev) =>
      prev.map((c) => (c.claim_id === claimId ? { ...c, claim_status: result.new_status } : c))
    );
    if (selectedClaim && selectedClaim.claim_id === claimId) {
      setSelectedClaim((prev) => ({ ...prev, claim_status: result.new_status }));
    }
    fetchStats();
  };

  // Search trigger
  const handleSearch = () => {
    fetchClaims(searchQuery);
  };

  // Reset filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setRiskFilter('');
    setTypeFilter('');
    fetchClaims('');
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-black">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        stats={stats}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-4 lg:p-6 space-y-6">
        {/* Top Executive KPI Cards */}
        <KPICards stats={stats} />

        {/* View 1: Claims Workbench (Triage Queue + 360° Dossier + Evidence) */}
        {activeTab === 'workbench' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:h-[760px] min-h-0">
              {/* Left Column: Triage Claims Table / Queue (5 cols) */}
              <div className="lg:col-span-5 h-[620px] lg:h-full min-h-0 flex flex-col overflow-hidden">
                <ClaimsTable
                  claims={claims}
                  selectedClaim={selectedClaim}
                  onSelectClaim={handleSelectClaim}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  riskFilter={riskFilter}
                  setRiskFilter={(val) => { setRiskFilter(val); setTimeout(() => fetchClaims(), 50); }}
                  typeFilter={typeFilter}
                  setTypeFilter={(val) => { setTypeFilter(val); setTimeout(() => fetchClaims(), 50); }}
                  onSearch={handleSearch}
                  onResetFilters={handleResetFilters}
                />
              </div>

              {/* Right Column: 360° Claim Dossier (7 cols) */}
              <div className="lg:col-span-7 h-[700px] lg:h-full min-h-0 flex flex-col overflow-hidden">
                <ClaimDossier
                  claim={selectedClaim}
                  onRunInvestigation={handleRunInvestigation}
                  onFindSimilar={() => setActiveTab('similarity')}
                  onViewRiskRadar={() => setActiveTab('risk_radar')}
                  onViewExplainability={() => setActiveTab('explainability')}
                  onOpenReport={handleOpenReport}
                  onOpenTriageModal={setTriageModalClaim}
                />
              </div>
            </div>

            {/* Bottom Section: Verifiable Evidence Trail */}
            {selectedClaim && (
              <div className="relative w-full block pt-2 clear-both">
                <EvidenceViewer selectedClaim={selectedClaim} />
              </div>
            )}
          </div>
        )}

        {/* View 2: Dedicated Explainability & XAI Studio */}
        {activeTab === 'explainability' && (
          <ExplainabilityScreen
            selectedClaim={selectedClaim}
            claims={claims}
            riskData={riskData}
            onSelectClaim={handleSelectClaim}
          />
        )}

        {/* View 3: Similarity & Precedent Explorer */}
        {activeTab === 'similarity' && (
          <SimilarityExplorer
            selectedClaim={selectedClaim}
            similarityData={similarityData}
            loading={loadingSimilarity}
            onSelectClaim={handleSelectClaim}
          />
        )}

        {/* View 3: Risk & Anomaly Radar */}
        {activeTab === 'risk_radar' && (
          <div className="space-y-6">
            <RiskRadar
              selectedClaim={selectedClaim}
              riskData={riskData}
            />
            {selectedClaim && (
              <EvidenceViewer selectedClaim={selectedClaim} />
            )}
          </div>
        )}

        {/* View 4: Multi-Agent War Room */}
        {activeTab === 'multi_agent' && (
          <MultiAgentConsole
            selectedClaim={selectedClaim}
            investigationResult={investigationResult}
            loading={loadingInvestigation}
            onRunInvestigation={handleRunInvestigation}
            onOpenTriageModal={setTriageModalClaim}
          />
        )}

        {/* View 5: Conversational AI Copilot */}
        {activeTab === 'copilot' && (
          <div className="h-[740px]">
            <AICopilot
              selectedClaim={selectedClaim}
              onSelectClaim={handleSelectClaim}
            />
          </div>
        )}

        {/* View 6: Evaluation & Benchmarks Dashboard */}
        {activeTab === 'evaluation' && (
          <EvaluationDashboard
            evaluationData={evaluationData}
            loading={loadingEvaluation}
            onRunEvaluation={fetchEvaluation}
            onDatasetChanged={() => { fetchStats(); fetchClaims(); fetchEvaluation(); }}
          />
        )}
      </main>

      {/* Report Modal */}
      {reportModalContent && (
        <ReportModal
          claimId={reportModalClaimId}
          reportContent={reportModalContent}
          onClose={() => setReportModalContent(null)}
        />
      )}

      {/* Human-in-the-Loop Triage Decision Modal */}
      {triageModalClaim && (
        <TriageModal
          claim={triageModalClaim}
          onClose={() => setTriageModalClaim(null)}
          onSaveDecision={handleSaveTriage}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/60 py-4 px-6 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2 max-w-[1720px] mx-auto w-full">
        <div className="flex items-center space-x-2">
          <span className="font-mono font-bold text-slate-400">ClaimsIntel v2.0 PRO</span>
          <span>•</span>
          <span>NVIDIA NIM AI Catalog: meta/llama-3.2-11b-vision-instruct & nvidia/nemotron-3-embed-1b</span>
        </div>
        <div className="flex items-center space-x-2">
          <span>COIL 2000 Insurance Benchmark (UCI ML Repository)</span>
          <span>•</span>
          <span className="text-emerald-400 font-mono">100% Grounded Traceability</span>
        </div>
      </footer>
    </div>
  );
}
