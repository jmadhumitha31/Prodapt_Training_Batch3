# AI-POWERED INSURANCE CLAIMS INTELLIGENCE ASSISTANT
## Technical Architecture Specification

### High-Level System Architecture Diagram
A visual SVG diagram of the end-to-end architecture is available at [`docs/architecture_diagram.svg`](./architecture_diagram.svg).

```
+-------------------------------------------------------------------------------------------------------------------------+
|                                    AI-POWERED INSURANCE CLAIMS INTELLIGENCE ASSISTANT                                   |
|                                                  END-TO-END DATAFLOW                                                    |
+-------------------------------------------------------------------------------------------------------------------------+
|                                                                                                                         |
|  [COIL 2000 Benchmark] -----> [Data Engine] -----> [Analytics Engine] -----> [Multi-Agent System] ---> [UI Cockpit]   |
|   5,822 Policyholders           Features:            - Hybrid Retrieval       5 Autonomous Agents:       Workbench      |
|   86 Demographic Attributes     - Z-Scores           - Precedent Sim          1. Retrieval Agent         Similarity     |
|   Policy Contributions          - Velocity           - Isolation Forest       2. Risk Analysis Agent     Risk Radar     |
|                                 - Embeddings (NIM)   - SHAP Waterfall         3. Anomaly Agent           A2A Stream     |
|  [Claims Dossiers] ----------> [Knowledge Base]      - Citations Grounding    4. Summarization Agent     AI Copilot     |
|   120 Rich Cases                 JSON Store +                                 5. Investigation Lead      Benchmarking   |
|   100% Record Traceable          2048-d Numpy                                                            SIU Reports    |
|                                                                                                                         |
|                                                                                                                         |
|                                                                                             [Human Reviewer Gate]       |
|                                                                                             Fast-Track / SIU / Evidence |
+-------------------------------------------------------------------------------------------------------------------------+
```

---

## 1. Pipeline Stages

### Stage 1 – Claims Data & Ingestion (COIL 2000 Grounding)
The system is built upon the **Insurance Company Benchmark (COIL 2000)** from the UCI Machine Learning Repository:
- **5,822 policyholder records** containing 86 socio-demographic and insurance policy ownership attributes.
- **Attributes Captured:** Customer Subtype (`MOSTYPE`), Household Size (`MGEMOMV`), Age Group (`MGEMLEEF`), Customer Main Type (`MOSHOOFD`), Income Bracket (`MINKGEM`), Car Policy Ownership & Contributions (`PPERSAUT`, `APERSAUT`), Fire Policy Indicators (`PBRAND`, `ABRAND`), Marine/Boat Policies (`PPLEZIER`, `APLEZIER`), Life Insurance, and Private Accident coverage.
- **Claims Enrichment:** Real-world claim events are mapped directly to COIL policyholders with exact row index references (`coil_row_id`), ensuring 100% data traceability.
- **Claims Attributes:** Claim ID, Policy ID, Claim Line (Auto Collision, Property Fire, Bodily Injury, Comprehensive, Marine/Boat), Incident Date, Report Date, Policy Inception Date, Inception-to-Loss Days, Loss Amount, Estimated Reserves, Deductible, Policy Limit, Police Report Filed, Witness Present, Incident Location, Weather, and rich Adjuster Narrative statements.

### Stage 2 – Data Processing & Feature Engineering
- **Amount Z-Score (`amount_zscore`):** Peer group standardized score measuring standard deviations from the claim line mean.
- **Amount-to-Income Ratio (`amount_to_income_ratio`):** Normalized loss severity relative to the policyholder's estimated annual household income class.
- **Velocity Metrics:**
  - `days_since_inception`: Inception-to-incident delta. Losses occurring under 30 days are flagged as early shock losses.
  - `days_to_report`: Latency between incident occurrence and formal carrier notification.
  - `claims_in_past_24m`: Loss frequency velocity.
- **Dense Semantic Embeddings:** 2,048-dimensional high-fidelity vectors generated via **NVIDIA NIM** (`nvidia/nemotron-3-embed-1b`) encoding the incident descriptions and adjuster observations.
- **Storage:** Persisted in an indexed JSON claims database and memory-mapped NumPy vector repository.

### Stage 3 – Retrieval & Analytics Engine
- **Hybrid Semantic & Lexical Search:**
  \[
  \text{Score}_{\text{hybrid}} = 0.75 \times \text{CosineSim}(v_q, v_d) + 0.25 \times \text{BM25}(q, d)
  \]
  Guarantees both deep conceptual understanding and exact keyword/token matching.
- **Multi-Dimensional Precedent Similarity:**
  \[
  \text{Sim}_{\text{composite}} = 0.50 \times \text{Sim}_{\text{semantic}} + 0.30 \times \text{Sim}_{\text{loss\_profile}} + 0.20 \times \text{Sim}_{\text{demographic}}
  \]
  Finds historical claims matching across narrative circumstances, loss severity, and socioeconomic policyholder profile.

### Stage 4 – Risk & Anomaly Detection
- **Unsupervised Machine Learning:** Scikit-Learn `IsolationForest` (100 estimators) trained across a 9-dimensional multivariate feature space, generating an outlier score from 0 to 100.
- **4-Pillar Calibrated Composite Risk Score:**
  1. *Loss Magnitude & Peer Severity* (25%)
  2. *Velocity & Inception Timing* (25%)
  3. *Documentation & Behavioral Integrity* (25%)
  4. *Multivariate ML Anomaly Score* (25%)
- **Priority Tiers:** LOW (0–35), MEDIUM (36–65), HIGH (66–84), CRITICAL (85–100).
- **Explainable AI (XAI):** SHAP-style feature impact waterfall and concrete verifiable evidence citations (`[Ref: days_since_inception=12]`, `[Ref: amount_zscore=+2.8σ]`).

### Stage 5 – Multi-Agent Claims Intelligence System
Five autonomous agents collaborate via structured Agent-to-Agent (A2A) messaging and escalation handoffs:
1. **Claims Retrieval Agent:** Extracts historical precedents and prior fraud resolutions.
2. **Claims Risk Analysis Agent:** Assesses policyholder risk propensity and coverage adequacy from COIL 2000 attributes.
3. **Anomaly Detection Agent:** Audits early inception shock loss, reporting latency, and statistical anomalies.
4. **Claims Summarization Agent:** Synthesizes a 3-bullet executive briefing with evidence grounding.
5. **Investigation Support Agent (SIU Lead):** Consolidates findings, triggers formal **Agent Handoffs** for claims with Risk $\ge 65$, drafts targeted claimant interview questions, and recommends next evidence steps.

### Stage 6 & 7 – Claims Insights & Human Reviewer Gate
- **High-End Intelligence Cockpit:** Built with React 19, Vite 8, and Tailwind CSS v4, drawing inspiration from Palantir Foundry and Shift Technology.
- **Interactive Capabilities:** Split-screen 360° dossier, 5-axis SVG risk radar topology, side-by-side precedent diff comparison, live A2A event stream, conversational AI copilot, and automated evaluation benchmark suite.
- **Human-in-the-Loop Adjudication:** Reviewers execute binding decisions (*Approve Fast-Track*, *Request Evidence*, *Refer to SIU*, *Reject*) with recorded notes and audit timestamps.
