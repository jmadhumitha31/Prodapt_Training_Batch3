"""
Claims Dataset Generation Script
Uses UCIMLRepo to fetch Insurance Company Benchmark (COIL 2000) (id=125),
extracts features (X) and targets (y), and builds the ground-truth claims knowledge base
complete with multi-pillar calibrated risk scores, 9-D Isolation Forest anomaly scores,
and 2048-dim NVIDIA NIM vector embeddings.
"""

import os
import sys
import json
import logging
from pathlib import Path
import numpy as np
import pandas as pd

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
CACHE_FILE = DATA_DIR / "insurance_claims_kb.json"
EMBEDDINGS_FILE = DATA_DIR / "claims_embeddings.npy"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("DatasetGenerator")

def fetch_uci_coil_2000():
    """
    Fetch Insurance Company Benchmark (COIL 2000) using ucimlrepo.
    Uses the exact UCIMLRepo specification: id=125.
    """
    logger.info("Attempting to fetch dataset from UCIMLRepo (id=125)...")
    try:
        from ucimlrepo import fetch_ucirepo 

        # fetch dataset 
        insurance_company_benchmark_coil_2000 = fetch_ucirepo(id=125) 
          
        # data (as pandas dataframes) 
        X = insurance_company_benchmark_coil_2000.data.features 
        y = insurance_company_benchmark_coil_2000.data.targets 
        
        logger.info(f"Successfully retrieved from ucimlrepo: Features shape: {X.shape}, Targets shape: {y.shape}")
        return X, y
    except Exception as e:
        logger.warning(f"ucimlrepo remote fetch notice: {e}")
        logger.info("Utilizing verified local COIL 2000 benchmark file (ticdata2000.txt)...")
        local_file = BASE_DIR / "ticdata2000.txt"
        if not local_file.exists():
            raise FileNotFoundError(f"Neither remote ucimlrepo nor local benchmark {local_file} available.")
        
        df = pd.read_csv(local_file, sep="\t", header=None)
        X = df.iloc[:, :-1]
        y = df.iloc[:, -1:]
        logger.info(f"Successfully loaded local COIL 2000: Features shape: {X.shape}, Targets shape: {y.shape}")
        return X, y

def generate_claims_knowledge_base(force: bool = False, count: int = 120):
    """
    Builds the complete synthetic claims dataset grounded in real COIL 2000 policyholder features.
    Computes statistical Z-scores, 9-D Isolation Forest anomaly scores, 4-pillar risk calibration,
    verifiable citations, and NVIDIA NIM vector embeddings.
    """
    if not force and CACHE_FILE.exists() and EMBEDDINGS_FILE.exists():
        logger.info(f"Dataset already exists at {CACHE_FILE}. Skipping generation.")
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            claims = json.load(f)
        logger.info(f"Loaded existing {len(claims)} claims from cache.")
        return claims

    # 1. Fetch COIL 2000 features & targets
    X, y = fetch_uci_coil_2000()

    # 2. Use backend data_engine to construct and score claims
    from backend.data_engine import data_engine
    data_engine.coil_df = pd.concat([X, y], axis=1)

    logger.info(f"Generating {count} multi-scenario claims grounded in COIL 2000 demographic records...")
    data_engine._generate_claims_dataset(num_claims=count)

    logger.info("Calculating 9-D Isolation Forest anomaly scores and 4-pillar calibrated risk scores...")
    data_engine._calculate_analytical_features()

    logger.info("Computing 2048-dimensional NVIDIA NIM vector embeddings...")
    data_engine._compute_and_cache_embeddings()

    # 3. Cache results to disk
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(data_engine.claims, f, indent=2)
    if data_engine.embeddings is not None:
        np.save(EMBEDDINGS_FILE, data_engine.embeddings)

    total_exposure = sum(c["claim_amount"] for c in data_engine.claims)
    high_critical = [c for c in data_engine.claims if c["risk_level"] in ["Critical", "High"]]

    logger.info("================================================================================")
    logger.info("CLAIMS INTELLIGENCE KNOWLEDGE BASE GENERATION SUCCESSFUL")
    logger.info(f"- Total Claims Generated:       {len(data_engine.claims)}")
    logger.info(f"- Total Financial Exposure:     ${total_exposure:,.2f}")
    logger.info(f"- High/Critical Risk Claims:    {len(high_critical)} ({len(high_critical)/len(data_engine.claims)*100:.1f}%)")
    logger.info(f"- Saved Knowledge Base File:    {CACHE_FILE}")
    logger.info(f"- Saved Vector Index:           {EMBEDDINGS_FILE}")
    logger.info("================================================================================")
    return data_engine.claims

if __name__ == "__main__":
    force_run = "--force" in sys.argv
    generate_claims_knowledge_base(force=force_run)
